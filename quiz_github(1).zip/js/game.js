// ─── game.js — Moteur de jeu, state, scoring, modes ───
function lsGet(k,d){try{var v=localStorage.getItem(k);return v!==null?JSON.parse(v):d;}catch(e){return d;}}
function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));if(window._fbUser&&window.fbSaveUserData){clearTimeout(window._fbSaveTimer);window._fbSaveTimer=setTimeout(window.fbSaveUserData,2000);}}catch(e){}}
var hsD=lsGet('tssr5_hs',{}),stD=lsGet('tssr5_stats',{}),xpD=lsGet('tssr5_xp',{total:0,level:1}),bdD=lsGet('tssr5_badges',[]);
var streakD=lsGet('tssr5_streak',{current:0,best:0,lastDate:''});
var savedVT=lsGet('tssr5_vt','vt-dark');
var savedSound=lsGet('tssr5_sound',false);
var savedJokers=lsGet('tssr5_jokers',true);
var selQCount=lsGet('tssr5_qcount',10);

function el(id){return document.getElementById(id);}
// Audio
var audioCtx=null;
function getAC(){if(!audioCtx)audioCtx=new(window.AudioContext||window.webkitAudioContext)();return audioCtx;}
function beep(f,d,t,v){if(!soundOn)return;try{var ac=getAC();var o=ac.createOscillator();var g=ac.createGain();o.connect(g);g.connect(ac.destination);o.type=t||'square';o.frequency.value=f;g.gain.setValueAtTime(v||0.15,ac.currentTime);g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+d);o.start(ac.currentTime);o.stop(ac.currentTime+d);}catch(e){}}
function playOk(){beep(523,.05);setTimeout(function(){beep(659,.05);},60);setTimeout(function(){beep(784,.12);},120);}
function playErr(){beep(200,.08,'sawtooth',.12);setTimeout(function(){beep(150,.12,'sawtooth',.1);},80);}
function playNext(){beep(440,.04,'sine',.07);}
function playBonus(){beep(880,.06);setTimeout(function(){beep(1100,.06);},70);setTimeout(function(){beep(1320,.15);},140);}
function playRankSound(rank){
  if(!soundOn)return;
  if(rank==='S'){// fanfare montante
    [523,659,784,1047,1319].forEach(function(f,i){setTimeout(function(){beep(f,.1,'sine',.2);},i*70);});
    setTimeout(function(){beep(1568,.4,'sine',.25);},400);
  } else if(rank==='A'){
    [523,659,784,1047].forEach(function(f,i){setTimeout(function(){beep(f,.1,'sine',.18);},i*70);});
  } else if(rank==='B'){
    beep(523,.08,'sine',.15);setTimeout(function(){beep(659,.15,'sine',.15);},100);
  } else if(rank==='C'){
    beep(440,.1,'triangle',.12);setTimeout(function(){beep(392,.15,'triangle',.1);},120);
  } else { // D — son triste
    [330,311,294,277].forEach(function(f,i){setTimeout(function(){beep(f,.12,'sawtooth',.1);},i*100);});
  }
}

// ====== STREAK ======
function updateStreak(){
  var today=new Date().toDateString();
  if(streakD.lastDate===today){
    // already played today, no change
  } else if(streakD.lastDate===new Date(Date.now()-86400000).toDateString()){
    // played yesterday → increment
    streakD.current++;
    if(streakD.current>streakD.best)streakD.best=streakD.current;
  } else if(streakD.lastDate!==today){
    // missed days → reset
    streakD.current=1;
  }
  streakD.lastDate=today;
  lsSet('tssr5_streak',streakD);
}

function applyBody(){
  var catCls=CATS[selCat]?CATS[selCat].cat:'cat-mix';
  document.body.className=vTheme+' '+catCls;
  // Override --acc avec la couleur du mode si en jeu
  var modeCol=selMode&&MODE_COLORS[selMode]?MODE_COLORS[selMode]:null;
  if(modeCol&&document.getElementById('screen-game')&&document.getElementById('screen-game').classList.contains('active')){
    document.documentElement.style.setProperty('--acc',modeCol);
    var a2=modeCol+'20'; document.documentElement.style.setProperty('--a2',a2);
  } else {
    document.documentElement.style.removeProperty('--acc');
    document.documentElement.style.removeProperty('--a2');
  }
}

function buildCatGrid(){
  var g=el('cat-grid');if(!g)return;g.innerHTML='';
  Object.keys(CATS).forEach(function(id){
    var c=CATS[id];var hs=hsD[id]||0;var st=stD[id]||{played:0,correct:0};
    var pct=st.played>0?Math.round(st.correct/st.played*100):0;
    var d=document.createElement('div');d.className='ccard'+(id===selCat?' sel':'');
    d.innerHTML='<span class="cqc">'+c.qs.length+'Q</span><span class="cicon">'+c.icon+'</span><span class="cname">'+c.label+'</span><div class="cdesc">'+c.desc+'</div><div class="cstat"><div class="cstat-fill" style="width:'+pct+'%"></div></div><div class="cstat-lbl">'+(st.played>0?pct+'% · Best '+hs+'/10':'Pas encore joué')+'</div>';
    (function(catId,card){card.onclick=function(){document.querySelectorAll('.ccard').forEach(function(x){x.classList.remove('sel');});card.classList.add('sel');selCat=catId;applyBody();};})(id,d);
    g.appendChild(d);
  });
}

function buildBadges(){
  var row=el('badges-row');if(!row)return;row.innerHTML='';
  if(bdD.length===0){row.innerHTML='<div style="font-size:9px;color:var(--dim)">Joue pour débloquer des badges…</div>';return;}
  BDEFS.forEach(function(b){var u=bdD.indexOf(b.id)>=0;var d=document.createElement('div');d.className='bdg'+(u?'':' locked');d.title=b.desc;d.innerHTML='<span>'+b.icon+'</span><span class="bl">'+b.name+'</span>';row.appendChild(d);});
}

function initMenu(){
  vTheme=lsGet('tssr5_vt','vt-dark');
  soundOn=lsGet('tssr5_sound',false);
  jokersEnabled=lsGet('tssr5_jokers',true);
  selQCount=lsGet('tssr5_qcount',10);
  currentUI=lsGet('tssr5_ui','ui-arcade');

  // Streak
  var sn=el('streak-num'); if(sn) sn.textContent=streakD.current+' jour'+(streakD.current!==1?'s':'');
  var sb=el('streak-best'); if(sb) sb.textContent='Best: '+streakD.best;

  // Sync sound toggles
  var stm=document.getElementById('stoggle-menu'); if(stm) stm.classList.toggle('on',soundOn);
  var st=el('stoggle'); if(st) st.classList.toggle('on',soundOn);

  // Build UI
  buildBadges();
  applyBody();
  applyUI(); // applique le thème UI (arcade/paper/terminal/minimal)
  buildDailyWidget();
  buildQuickStats();
}

function pickVT(e){document.querySelectorAll('.vtbtn').forEach(function(x){x.classList.remove('sel');});e.classList.add('sel');vTheme=e.getAttribute('data-vt');lsSet('tssr5_vt',vTheme);applyBody();}
function pickDiff(e){document.querySelectorAll('.diffbtn').forEach(function(x){x.classList.remove('sel');});e.classList.add('sel');selDiff=e.getAttribute('data-diff');}
function pickMode(e){document.querySelectorAll('.mcard').forEach(function(x){x.classList.remove('sel');});e.classList.add('sel');selMode=e.getAttribute('data-mode');}
function toggleSound(){
  soundOn=!soundOn;
  lsSet('tssr5_sound',soundOn);
  var t1=document.getElementById('stoggle'); if(t1) t1.classList.toggle('on',soundOn);
  var t2=document.getElementById('stoggle-menu'); if(t2) t2.classList.toggle('on',soundOn);
}
function toggleJokers(){jokersEnabled=!jokersEnabled;el('jtoggle').classList.toggle('on',jokersEnabled);lsSet('tssr5_jokers',jokersEnabled);}
function pickQCount(e){selQCount=parseInt(e.getAttribute('data-n'));lsSet('tssr5_qcount',selQCount);document.querySelectorAll('.qcbtn').forEach(function(b){b.classList.remove('sel');});e.classList.add('sel');}
function showScreen(n){document.querySelectorAll('.screen').forEach(function(s){s.classList.remove('active');});el('screen-'+n).classList.add('active');}
function goMenu(){
  clearInterval(timerInt);paused=false;el('povl').classList.remove('show');
  var sh=el('score-hud'); if(sh) sh.style.display='grid';
  var jr=el('jokers-row'); if(jr) jr.style.display='none';
  betOn=false;stopChaosMode&&stopChaosMode();dismissEvent&&dismissEvent();
  document.documentElement.style.removeProperty('--acc');
  document.documentElement.style.removeProperty('--a2');
  // Hide RPG overlay if open
  var rpgOvl=document.getElementById('rpg-overlay');if(rpgOvl)rpgOvl.classList.remove('show');
  initMenu();showScreen('menu');
}
function shuffle(a){
  var b=a.slice();
  // Use crypto.getRandomValues for better randomness
  var arr=new Uint32Array(b.length);
  (window.crypto||window.msCrypto).getRandomValues(arr);
  for(var i=b.length-1;i>0;i--){
    var j=arr[i]%(i+1);
    var t=b[i];b[i]=b[j];b[j]=t;
  }
  return b;
}
// Track shown questions to avoid repetition within a session
var _shownQids={};
// Variables globales nouvelles features
var rpgPoints=0,qTimes=[],matchMatched=[],lofiOn=false,lofiNodes=[],srElapsed=0,betOn=false;
function freshShuffle(pool){
  // Prefer questions not seen recently
  var unseen=pool.filter(function(q){return !_shownQids[q.q];});
  var seen=pool.filter(function(q){return !!_shownQids[q.q];});
  // shuffle each group separately
  var mixed=shuffle(unseen).concat(shuffle(seen));
  return mixed;
}
function markShown(session){
  session.forEach(function(q){_shownQids[q.q]=1;});
  // cap at 500 entries
  var keys=Object.keys(_shownQids);
  if(keys.length>500){var del=keys.slice(0,keys.length-500);del.forEach(function(k){delete _shownQids[k];});}
}




function skipQuestion(){
  if(answered) return;
  clearInterval(timerInt);
  answered = true;
  updDot(idx, 'pdot');
  var fbk = el('fbk');
  fbk.className = 'fbk show';
  fbk.style.cssText = 'border:1.5px solid #ff9800;background:rgba(255,152,0,.08);color:#cc7700;display:block;';
  fbk.innerHTML = '⏭ Question passée.';
  el('nextbtn').className = 'next-btn show';
}

// ============================================================
// TIMER ADAPTATIF
// ============================================================
var MECH_TIMERS={qcm:1.0,tf:0.6,fill:1.0,calc:1.5,debug:1.2,type:1.2,slider:1.0,word:1.8,scramble:2.0,order:3.5,match:3.0,multiblank:2.5,categorize:3.0,hotspot:4.0};
var MECH_MIN_TIMER={order:30,match:25,categorize:30,hotspot:40,multiblank:20,word:18,scramble:15,calc:12,debug:12,type:12};
function getQTimer(q,baseTimer){
  if(!baseTimer||baseTimer===0) return 0;
  var mult=MECH_TIMERS[q.t]||1.0;
  var minT=MECH_MIN_TIMER[q.t]||0;
  return Math.max(Math.round(baseTimer*mult),minT,baseTimer);
}

// ============================================================
// RÉGLAGES
// ============================================================
function openSettingsScreen(){
  showScreen('settings');
  var ss=document.getElementById('stoggle-settings'); if(ss) ss.classList.toggle('on',soundOn);
  var ls=document.getElementById('lofi-btn-settings'); if(ls) ls.textContent=lofiOn?'ON':'OFF';
  document.querySelectorAll('.settings-theme-btn').forEach(function(b){
    b.classList.toggle('sel', b.getAttribute('data-vt')===vTheme);
  });
  var em=document.getElementById('settings-email-display');
  if(em&&window._fbUser) em.textContent=window._fbUser.email||'—';
}

function pickVTSettings(btn){
  if(typeof playThemeChange==='function') playThemeChange();
  document.querySelectorAll('.settings-theme-btn').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  vTheme=btn.getAttribute('data-vt');
  lsSet('tssr5_vt',vTheme);
  applyBody();
  if(window.fbSaveUserData) setTimeout(window.fbSaveUserData,500);
}

function toggleSound(){
  soundOn=!soundOn;
  lsSet('tssr5_sound',soundOn);
  ['stoggle','stoggle-menu','stoggle-settings'].forEach(function(id){
    var t=document.getElementById(id); if(t) t.classList.toggle('on',soundOn);
  });
  if(window.fbSaveUserData) setTimeout(window.fbSaveUserData,500);
}

// ============================================================
// PROFIL
// ============================================================
var AVATARS=['😊','😎','🤓','🧑‍💻','👨‍💻','👩‍💻','🦊','🐺','🐸','🤖','👾','🎯','🔥','⚡','🌙','🎮','📡','🛡️','🗺️','💡','🔑','🏆','💎','⚙️','🧠','🦁','🐉','🦅','🌊','🚀','🎭','🎲','🧩','📚','🖥️'];
var PROFILE_TITLES=[
  {min:0,   label:'DÉBUTANT',      cls:'title-debutant'},
  {min:10,  label:'TECHNICIEN',    cls:'title-technicien'},
  {min:30,  label:'INTERMÉDIAIRE', cls:'title-intermediaire'},
  {min:60,  label:'EXPERT',        cls:'title-expert'},
  {min:100, label:'TSSR CERTIFIÉ', cls:'title-tssr'},
];
var PROFILE_THEMES=[
  {id:'vt-dark',    dot:'#5b8fff',label:'DARK'},
  {id:'vt-light',   dot:'#0070b0',label:'LIGHT'},
  {id:'vt-slate',   dot:'#4488ff',label:'SLATE'},
  {id:'vt-paper',   dot:'#a07000',label:'PAPER'},
  {id:'vt-midnight',dot:'#8866ff',label:'NIGHT'},
  {id:'vt-warm',    dot:'#ff8860',label:'WARM'},
];

function getProfileTitle(n){
  var t=PROFILE_TITLES[0];
  for(var i=PROFILE_TITLES.length-1;i>=0;i--){ if(n>=PROFILE_TITLES[i].min){t=PROFILE_TITLES[i];break;} }
  return t;
}
function getMasteredCount(){
  if(typeof loadQDB==='function') loadQDB();
  var now=Date.now(),count=0;
  Object.keys(CATS).forEach(function(k){
    if(k==='mix') return;
    CATS[k].qs.forEach(function(q){
      var r=typeof getQRecord==='function'?getQRecord(q):{seen:0,streak:0,nextReview:0};
      if(r.seen>0&&r.streak>=3&&now<r.nextReview) count++;
    });
  });
  return count;
}
function loadProfileData(){ return lsGet('tssr5_profile',{avatar:'😊',pseudo:'',promo:''}); }

function updateMenuProfile(){
  var data=loadProfileData();
  var mastered=getMasteredCount();
  var title=getProfileTitle(mastered);
  var ma=document.getElementById('menu-avatar');
  var mp=document.getElementById('menu-pseudo');
  var mt=document.getElementById('menu-title-badge');
  if(ma) ma.textContent=data.avatar||'😊';
  if(mp) mp.textContent=data.pseudo||(window._fbUser?(window._fbUser.displayName||window._fbUser.email.split('@')[0]):'');
  if(mt){mt.textContent=title.label;mt.className=title.cls;}
}

function loadProfileScreen(){
  var data=loadProfileData();
  var mastered=getMasteredCount();
  var title=getProfileTitle(mastered);
  var av=document.getElementById('profile-avatar-display'); if(av) av.textContent=data.avatar||'😊';
  var nm=document.getElementById('profile-name-display'); if(nm) nm.textContent=data.pseudo||(window._fbUser?(window._fbUser.displayName||window._fbUser.email):'—');
  var tb=document.getElementById('profile-title-display'); if(tb){tb.textContent=title.label;tb.className='profile-title-badge '+title.cls;}
  var pr=document.getElementById('profile-promo-display'); if(pr) pr.textContent=data.promo||'';
  var badges=lsGet('tssr5_badges',[]);
  var pm=document.getElementById('prof-mastered'); if(pm) pm.textContent=mastered;
  var ps=document.getElementById('prof-streak'); if(ps) ps.textContent=streakD.current||0;
  var pb=document.getElementById('prof-badges'); if(pb) pb.textContent=badges.length;
  var pi=document.getElementById('prof-pseudo-input'); if(pi) pi.value=data.pseudo||'';
  var ri=document.getElementById('prof-promo-input'); if(ri) ri.value=data.promo||'';
  buildProfileThemeRow();
}

function buildProfileThemeRow(){
  var row=document.getElementById('prof-theme-row'); if(!row) return;
  row.innerHTML='';
  PROFILE_THEMES.forEach(function(t){
    var btn=document.createElement('button');
    var isSel=(vTheme===t.id);
    btn.style.cssText='display:flex;align-items:center;gap:5px;padding:6px 10px;border-radius:5px;cursor:pointer;font-family:monospace;font-size:7px;letter-spacing:1px;border:1.5px solid '+(isSel?'var(--acc)':'var(--border2)')+';background:'+(isSel?'var(--a2)':'var(--panel)')+';color:'+(isSel?'var(--acc)':'var(--text2)')+';transition:all .12s;';
    btn.innerHTML='<span style="width:8px;height:8px;border-radius:50%;background:'+t.dot+';display:inline-block;"></span>'+t.label;
    (function(tid){btn.onclick=function(){vTheme=tid;lsSet('tssr5_vt',vTheme);applyBody();buildProfileThemeRow();if(window.fbSaveUserData)setTimeout(window.fbSaveUserData,500);};})(t.id);
    row.appendChild(btn);
  });
}

function saveProfile(){
  var pseudo=(document.getElementById('prof-pseudo-input').value||'').trim();
  var promo=(document.getElementById('prof-promo-input').value||'').trim();
  var data=loadProfileData();
  if(pseudo) data.pseudo=pseudo;
  data.promo=promo;
  lsSet('tssr5_profile',data);
  if(window.fbSaveUserData) window.fbSaveUserData();
  updateMenuProfile();
  var msg=document.getElementById('prof-save-msg');
  if(msg){msg.style.display='block';setTimeout(function(){msg.style.display='none';},2500);}
}

function openAvatarPicker(){
  var data=loadProfileData();
  var grid=document.getElementById('avatar-grid'); if(!grid) return;
  grid.innerHTML='';
  AVATARS.forEach(function(a){
    var d=document.createElement('div');
    d.className='avatar-opt'+(a===(data.avatar||'😊')?' selected':'');
    d.textContent=a;
    d.onclick=function(){
      var profile=loadProfileData(); profile.avatar=a;
      lsSet('tssr5_profile',profile);
      var av=document.getElementById('profile-avatar-display'); if(av) av.textContent=a;
      updateMenuProfile();
      if(window.fbSaveUserData) window.fbSaveUserData();
      setTimeout(closeAvatarPicker,400);
    };
    grid.appendChild(d);
  });
  document.getElementById('avatar-picker').classList.add('show');
}
function closeAvatarPicker(){ document.getElementById('avatar-picker').classList.remove('show'); }

// ============================================================
// LEADERBOARD
// ============================================================
var _lbData=[], _lbTab='mastered';

async function loadLeaderboard(){
  if(!window._fbGetDocs||!window._fbCollection){
    document.getElementById('lb-list').innerHTML='<div style="text-align:center;padding:24px;font-family:monospace;font-size:9px;color:var(--text2);">⚠️ Firebase non connecté</div>';
    return;
  }
  document.getElementById('lb-list').innerHTML='<div style="text-align:center;padding:24px;font-family:monospace;font-size:9px;color:var(--text2);">⏳ Chargement...</div>';
  try{
    var snap=await window._fbGetDocs(window._fbQuery(window._fbCollection(window._fbDb,'leaderboard'),window._fbLimit(50)));
    _lbData=[];
    snap.forEach(function(d){ _lbData.push(Object.assign({uid:d.id},d.data())); });
    renderLeaderboard();
  }catch(err){
    document.getElementById('lb-list').innerHTML='<div style="text-align:center;padding:24px;font-family:monospace;font-size:9px;color:#dc2626;">❌ '+err.message+'</div>';
  }
}

function lbSwitchTab(tab){
  _lbTab=tab;
  document.querySelectorAll('.lb-tab').forEach(function(b){b.classList.remove('active');});
  var btn=document.getElementById('lb-tab-'+tab); if(btn) btn.classList.add('active');
  renderLeaderboard();
}

function renderLeaderboard(){
  var myUid=window._fbUser?window._fbUser.uid:null;
  var sorted=_lbData.slice().sort(function(a,b){return (b[_lbTab]||0)-(a[_lbTab]||0);});
  var rankIcons={1:'🥇',2:'🥈',3:'🥉'};
  var scoreLabels={mastered:'maîtrisés',streak:'j. streak',badges:'badges'};
  var myRank=sorted.findIndex(function(x){return x.uid===myUid;})+1;
  var bannerEl=document.getElementById('lb-my-rank-banner');
  if(bannerEl) bannerEl.innerHTML=myRank>0?'<div class="lb-my-rank">Tu es #'+myRank+' sur '+sorted.length+' joueurs — '+(sorted[myRank-1][_lbTab]||0)+' '+scoreLabels[_lbTab]+'</div>':'';
  var list=document.getElementById('lb-list');
  if(!sorted.length){list.innerHTML='<div style="text-align:center;padding:24px;font-family:monospace;font-size:9px;color:var(--text2);">Aucun joueur pour l\'instant</div>';return;}
  list.innerHTML=sorted.map(function(user,i){
    var rank=i+1,isMe=user.uid===myUid;
    var rankDisp=rankIcons[rank]||('<span style="font-size:11px;color:var(--dim);">#'+rank+'</span>');
    return '<div class="lb-row'+(isMe?' lb-me':'')+'">'+
      '<div class="lb-rank">'+(rankDisp)+'</div>'+
      '<div class="lb-avatar">'+(user.avatar||'😊')+'</div>'+
      '<div class="lb-info"><div class="lb-pseudo">'+(user.pseudo||'Anonyme')+(isMe?' <span style="font-size:8px;color:var(--acc);">← toi</span>':'')+
      '</div><div style="font-size:9px;color:var(--text2);">'+(user.promo||'')+'</div>'+
      '<div style="font-family:monospace;font-size:7px;color:var(--dim);margin-top:2px;">'+(user.title||'')+'</div></div>'+
      '<div class="lb-score"><span class="lb-score-val">'+(user[_lbTab]||0)+'</span><span class="lb-score-lbl">'+scoreLabels[_lbTab]+'</span></div>'+
    '</div>';
  }).join('');
}

function showLeaderboard(){ showScreen('leaderboard'); loadLeaderboard(); }

// ============================================================
// OBJECTIFS
// ============================================================
function getQuestsData(){return lsGet('tssr5_quests',{daily:{date:'',played:0,correct:0,srs:0},weekly:{week:0,played:0,cats:[]}});}
function saveQuestsData(d){lsSet('tssr5_quests',d);}
function getWeekNum(){var d=new Date();var s=new Date(d.getFullYear(),0,1);return Math.ceil(((d-s)/86400000+s.getDay()+1)/7);}

function updateQuestProgress(type,amount){
  var d=getQuestsData();
  var today=new Date().toDateString(),week=getWeekNum();
  if(d.daily.date!==today) d.daily={date:today,played:0,correct:0,srs:0};
  if(d.weekly.week!==week) d.weekly={week:week,played:0,cats:[]};
  if(type==='played')   d.daily.played  +=(amount||1);
  if(type==='correct')  d.daily.correct +=(amount||1);
  if(type==='srs')      d.daily.srs     +=(amount||1);
  if(type==='weekly_played') d.weekly.played+=(amount||1);
  if(type==='weekly_cat'&&amount&&d.weekly.cats.indexOf(amount)<0) d.weekly.cats.push(amount);
  saveQuestsData(d);
}

function buildQuestsScreen(){
  var d=getQuestsData();
  var today=new Date().toDateString(),week=getWeekNum();
  if(d.daily.date!==today) d.daily={date:today,played:0,correct:0,srs:0};
  if(d.weekly.week!==week) d.weekly={week:week,played:0,cats:[]};
  var badges=lsGet('tssr5_badges',[]);
  var mastered=getMasteredCount();

  var DAILY=[
    {icon:'⚡',name:'Révision express',desc:'Joue 10 questions aujourd\'hui',reward:'+50 XP',prog:Math.min(d.daily.played,10),total:10,done:d.daily.played>=10},
    {icon:'🎯',name:'Révision ciblée',desc:'Réponds à 5 questions en révision ciblée',reward:'+30 XP',prog:Math.min(d.daily.srs,5),total:5,done:d.daily.srs>=5},
    {icon:'🔥',name:'Précision',desc:'Enchaîne 5 bonnes réponses',reward:'+40 XP',prog:Math.min(maxCombo||0,5),total:5,done:(maxCombo||0)>=5},
    {icon:'📅',name:'Streak',desc:'Maintiens ton streak quotidien',reward:'+20 XP',prog:Math.min(streakD.current||0,1),total:1,done:(streakD.current||0)>=1},
  ];
  var WEEKLY=[
    {icon:'📚',name:'Explorateur',desc:'Joue dans 4 catégories différentes',reward:'+200 XP',prog:Math.min(d.weekly.cats.length,4),total:4,done:d.weekly.cats.length>=4},
    {icon:'💪',name:'Persévérance',desc:'Joue 50 questions cette semaine',reward:'+150 XP',prog:Math.min(d.weekly.played,50),total:50,done:d.weekly.played>=50},
    {icon:'💎',name:'Maîtrise',desc:'Atteins 20 questions maîtrisées',reward:'+300 XP',prog:Math.min(mastered,20),total:20,done:mastered>=20},
    {icon:'🏅',name:'Collectionneur',desc:'Débloque 5 badges',reward:'+100 XP',prog:Math.min(badges.length,5),total:5,done:badges.length>=5},
  ];

  function renderQ(q){
    var pct=Math.round(q.prog/q.total*100);
    return '<div class="quest-card'+(q.done?' quest-done':'')+'">'+
      '<div class="quest-icon">'+q.icon+'</div>'+
      '<div class="quest-info"><div class="quest-name">'+q.name+'</div><div class="quest-desc">'+q.desc+'</div>'+
      '<div class="quest-prog-bar"><div class="quest-prog-fill" style="width:'+pct+'%"></div></div>'+
      '<div style="font-family:monospace;font-size:8px;color:var(--dim);margin-top:3px;">'+q.prog+' / '+q.total+'</div></div>'+
      (q.done?'<div style="font-size:18px;">✅</div>':'<div class="quest-reward">'+q.reward+'</div>')+
    '</div>';
  }

  var doneD=DAILY.filter(function(q){return q.done;}).length;
  var doneW=WEEKLY.filter(function(q){return q.done;}).length;
  var content=document.getElementById('quests-content');
  if(!content) return;
  content.innerHTML=
    '<div style="font-family:monospace;font-size:8px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;">📅 AUJOURD\'HUI ('+doneD+'/'+DAILY.length+')</div>'+
    DAILY.map(renderQ).join('')+
    '<div style="font-family:monospace;font-size:8px;color:var(--dim);letter-spacing:2px;text-transform:uppercase;margin:16px 0 8px;">📆 CETTE SEMAINE ('+doneW+'/'+WEEKLY.length+')</div>'+
    WEEKLY.map(renderQ).join('');
}
function showQuestsScreen(){buildQuestsScreen();showScreen('quests');}

function startGame(){
  if(selMode==='flash'){startFlash();return;}
  if(selMode==='duel'){showScreen('duel-setup');return;}
  if(selMode==='discussion'){showScreen('discussion');return;}
  if(selMode==='rpg'){startRPGNarrative();return;}
  if(selMode==='chaos'){startChaosMode();return;}
  updateStreak();
  if(selCat==='_multi'){return;} // pool already built by wizLaunch
  var cat=CATS[selCat]||CATS['mix'],cfg=MODES[selMode]||MODES['chill'];
  lives=cfg.lives===99?99:cfg.lives;
  correct=0;combo=1;maxCombo=1;errors=[];idx=0;paused=false;
  bonusStreak=0;isBonus=false;qTimes=[];rpgPoints=0;betOn=false;
  jokers=3;
  sStats={cat:selCat,mode:selMode,maxCombo:0,mechs:new Set(),streak:streakD.current};

  var pool;
  if(selMode==='erreurs'&&reviewBank.length>0){
    pool=reviewBank;
  } else {
    pool=selDiff==='all'?cat.qs:cat.qs.filter(function(q){return q.d===parseInt(selDiff);});
    if(pool.length===0)pool=cat.qs;
  }
  var count=selMode==='exam'?20:selMode==='marathon'?99999:Math.min(selQCount,9999);
  // Use freshShuffle to avoid showing same questions repeatedly
  var mixed=freshShuffle(pool);
  session=mixed.slice(0,Math.min(count,pool.length));
  markShown(session);

  applyBody();
  el('gbadge').textContent=cat.label.toUpperCase()+' · '+selMode.toUpperCase();
  // Chrono mode: 3-minute global countdown
  if(selMode==='chrono'){
    var cd=document.getElementById('chrono-display');
    if(cd) cd.style.display='block';
    var chronoLeft=180;
    var chronoInt=setInterval(function(){
      chronoLeft--;
      var m=Math.floor(chronoLeft/60), s=chronoLeft%60;
      var cd2=document.getElementById('chrono-display');
      if(cd2) cd2.textContent=m+':'+(s<10?'0':'')+s;
      if(chronoLeft<=30&&cd2) cd2.style.color='#dc2626';
      if(chronoLeft<=0){clearInterval(chronoInt);showResults();}
    },1000);
    // Store so we can clear it
    window._chronoInt=chronoInt;
  } else {
    var cd3=document.getElementById('chrono-display');
    if(cd3) cd3.style.display='none';
    if(window._chronoInt) clearInterval(window._chronoInt);
  }
  var shud=el('score-hud'); if(shud) shud.style.display=(selMode==='duel'||selMode==='flash'||selMode==='discussion')?'none':'grid';
  var srHud=document.getElementById('speedrun-hud'); if(srHud) srHud.style.display=selMode==='speedrun'?'flex':'none';
  var bossWrap=document.getElementById('boss-bar-wrap'); if(bossWrap) bossWrap.style.display=selMode==='boss'?'block':'none';
  if(selMode==='speedrun'){var srRec=document.getElementById('sr-record');var srB=lsGet('tssr5_sr_best',{});if(srRec)srRec.textContent=srB[selCat]?'Best: '+srB[selCat].toFixed(1)+'s':'';}
  dynDiffStreak=0;dynDiffLevel=0;
  el('hrecord').textContent=(hsD[selCat]||0)+'/'+count;
  el('htotal').textContent=session.length;
  // jokers
  el('jokers-row').style.display=jokersEnabled&&(selMode==='qcm'||true)?'flex':'none';
  el('jcount').textContent=jokers;
  el('joker-btn').disabled=false;
  // exam mode class
  var gameDiv=el('screen-game');
  if(selMode==='exam')gameDiv.classList.add('exam-mode');
  else gameDiv.classList.remove('exam-mode');
  // pause btn hide for blitz
  el('pause-btn').style.display=selMode==='blitz'?'none':'block';

  buildDots();showScreen('game');showQ();
}

function startReview(){
  selMode='erreurs';
  document.querySelectorAll('.mcard').forEach(function(x){x.classList.remove('sel');if(x.getAttribute('data-mode')==='erreurs')x.classList.add('sel');});
  startGame();
}

function buildDots(){
  var c=el('pdots');c.innerHTML='';
  for(var i=0;i<session.length;i++){var d=document.createElement('div');d.className='pdot'+(i===0?' dcur':'');d.id='dot'+i;c.appendChild(d);}
}
function updDot(i,s){var d=el('dot'+i);if(d){d.className='pdot '+s;}}
function updScore(){el('hcorrect').textContent=correct;el('hprog').textContent=(idx+1)+'/'+session.length;
  if(selMode==='boss') updateBossBar();
}

// ====== JOKER ======
function useJoker(){
  if(jokers<=0||answered)return;
  var q=session[idx];
  if(q.t!=='qcm'&&q.t!=='debug')return;
  jokers--;el('jcount').textContent=jokers;
  if(jokers===0){el('joker-btn').disabled=true;}
  // Eliminate 2 wrong answers
  var btns=Array.from(document.querySelectorAll('.opt:not(:disabled)'));
  var wrong=btns.filter(function(b){return +b.getAttribute('data-orig')!==q.a;});
  var toElim=shuffle(wrong).slice(0,2);
  toElim.forEach(function(b){b.classList.add('elim');b.disabled=true;});
}

// ====== SHOW Q ======
function showQ(){
  answered=false;orderItems=[];
  startQTimer();
  if(selMode==='speedrun'&&idx===0) initSpeedrun();
  if(selMode!=='exam'&&selMode!=='duel'){
    maybeFireEvent();
    maybeChaos();
    maybeShowBet();
  }
  var cfg=MODES[selMode],q=session[idx];
  var mi=MECH_INFO[q.t]||MECH_INFO.qcm;
  sStats.mechs.add(q.t);

  // bonus check — every 5 consecutive correct
  isBonus=(bonusStreak>0&&bonusStreak%5===0);
  if(isBonus)playBonus();

  el('fbk').className='fbk';el('nextbtn').className='next-btn';
  el('hint-txt').textContent=mi.hint;
  updScore();
  updLives();
  updDot(idx,'pdot dcur');

  var area=el('question-area');area.innerHTML='';

  // pill row
  var pillRow=document.createElement('div');pillRow.style.cssText='display:flex;align-items:center;gap:8px;margin-bottom:8px;';
  var pill=document.createElement('div');pill.className='mech-pill '+mi.cls;pill.textContent=mi.label;
  pillRow.appendChild(pill);
  if(isBonus){var bb=document.createElement('div');bb.className='bonus-badge';bb.textContent='⭐ BONUS QUESTION';pillRow.appendChild(bb);}
  area.appendChild(pillRow);

  // card
  var card=document.createElement('div');card.className='qcard'+(isBonus?' bonus-card':'');card.id='qcard';
  var qdiff=document.createElement('span');qdiff.className='qdiff';qdiff.textContent=DS[q.d]||'';
  var qnum=document.createElement('div');qnum.className='qnum';
  var srsHtml=getSRSLabel(q);
  qnum.innerHTML='Question '+(idx+1)+(isBonus?' ★':'')+'  '+srsHtml;
  var qtxt=document.createElement('div');qtxt.className='qtext';qtxt.innerHTML=q.q+(q._cat?'<span class="qcat-tag">['+q._cat+']</span>':'');
  card.appendChild(qdiff);card.appendChild(qnum);card.appendChild(qtxt);
  area.appendChild(card);

  // render mechanic
  // Mode inversé — on remplace le rendu normal
  if(selMode==='inverse'&&(q.t==='qcm'||q.t==='debug'||q.t==='fill'||q.t==='tf')){
    renderInverse(q,area);
  } else {
    switch(q.t){
      case 'qcm':    renderQCM(q,area);break;
      case 'tf':     renderTF(q,area);break;
      case 'fill':   renderFill(q,area);break;
      case 'order':  renderOrder(q,area);break;
      case 'calc':   renderCalc(q,area);break;
      case 'debug':  renderDebug(q,area);break;
      case 'word':   renderWord(q,area);break;
      case 'match':  renderMatch(q,area);break;
      case 'type':    renderType(q,area);break;
      case 'slider':  renderSlider(q,area);break;
      case 'scramble': renderScramble(q,area);break;
      case 'multiblank': renderMultiblank(q,area);break;
      case 'categorize': renderCategorize(q,area);break;
      case 'hotspot': renderHotspot(q,area);break;
      default:       renderQCM(q,area);
    }
  }

  // timer
  clearInterval(timerInt);var tb=el('tbar');
  if(cfg.timer===0){tb.style.width='100%';tb.style.background='#00d87a';}
  else{
    var adaptedTimer=(selMode==='chaos'&&window._chaosTimerOverride)?window._chaosTimerOverride:getQTimer(q,cfg.tmax);
    timeLeft=adaptedTimer;tb.style.width='100%';tb.style.background='#00d87a';
    timerInt=setInterval(function(){if(paused)return;timeLeft-=0.1;var p=(timeLeft/adaptedTimer)*100;
      tb.style.width=p+'%';if(p<50)tb.style.background='#ff9800';if(p<20)tb.style.background='#dc2626';
      updateTimerDrama(p,timeLeft);
      if(timeLeft<=0){clearInterval(timerInt);if(!answered)expireQ(q);}},100);}
}

// ====== MECHANICS ======
function renderQCM(q,area){
  var shuffled=shuffle(q.opts.map(function(t,i){return{t:t,i:i};}));
  var wrap=document.createElement('div');wrap.className='opts';
  ['A','B','C','D'].forEach(function(k,i){
    var b=document.createElement('button');b.className='opt';
    b.innerHTML='<span class="okey">'+k+'</span><span>'+shuffled[i].t+'</span>';
    b.setAttribute('data-orig',shuffled[i].i);
    b.onclick=function(){if(!answered)resolveQCM(shuffled[i].i,b,q,wrap);};
    wrap.appendChild(b);
  });
  area.appendChild(wrap);
}
function resolveQCM(origIdx,btn,q,wrap){
  clearInterval(timerInt);answered=true;
  wrap.querySelectorAll('.opt').forEach(function(b){b.disabled=true;});
  wrap.querySelectorAll('.opt').forEach(function(b){if(+b.getAttribute('data-orig')===q.a)b.classList.add('ok');});
  var ok=origIdx===q.a;
  btn.classList.add(ok?'ok':'err');
  if(!ok)errors.push({q:q.q,yours:q.opts[origIdx],correct:q.opts[q.a],x:q.x,orig:q,mech:q.t});
  resolveCommon(ok,q);
}

function renderTF(q,area){
  var row=document.createElement('div');row.className='tf-row';
  var bT=document.createElement('button');bT.className='tf-btn tf-true';bT.innerHTML='✅<span class="tf-lbl">VRAI</span>';
  var bF=document.createElement('button');bF.className='tf-btn tf-false';bF.innerHTML='❌<span class="tf-lbl">FAUX</span>';
  bT.onclick=function(){if(!answered)resolveTF(true,q,bT,bF);};
  bF.onclick=function(){if(!answered)resolveTF(false,q,bT,bF);};
  row.appendChild(bT);row.appendChild(bF);area.appendChild(row);
}
function resolveTF(val,q,bT,bF){
  clearInterval(timerInt);answered=true;bT.disabled=true;bF.disabled=true;
  var ok=val===q.a;
  (val?bT:bF).classList.add(ok?'ok':'err');
  if(!ok){(q.a?bT:bF).classList.add('ok');errors.push({q:q.q,yours:val?'VRAI':'FAUX',correct:q.a?'VRAI':'FAUX',x:q.x,orig:q,mech:q.t});}
  resolveCommon(ok,q);
}

function renderFill(q,area){
  var code=document.createElement('div');code.className='fill-code';
  code.innerHTML=q.code.replace(q.blank,'<span class="fill-blank" id="fill-blank">'+q.blank+'</span>');
  var opts=document.createElement('div');opts.className='fill-opts';
  var shuffled=shuffle(q.opts.map(function(t,i){return{t:t,i:i};}));
  shuffled.forEach(function(opt){
    var b=document.createElement('button');b.className='fill-opt';b.textContent=opt.t;b.setAttribute('data-orig',opt.i);
    b.onclick=function(){if(!answered)resolveFill(opt.i,opt.t,b,q,opts);};
    opts.appendChild(b);
  });
  area.appendChild(code);area.appendChild(opts);
}
function resolveFill(origIdx,val,btn,q,optsEl){
  clearInterval(timerInt);answered=true;
  optsEl.querySelectorAll('.fill-opt').forEach(function(b){b.disabled=true;});
  optsEl.querySelectorAll('.fill-opt').forEach(function(b){if(+b.getAttribute('data-orig')===q.a)b.classList.add('ok');});
  var ok=origIdx===q.a;btn.classList.add(ok?'ok':'err');
  var blank=document.getElementById('fill-blank');if(blank){blank.textContent=val;blank.classList.add(ok?'ok-fill':'err-fill');}
  if(!ok)errors.push({q:q.q,yours:q.opts[origIdx],correct:q.opts[q.a],x:q.x,orig:q,mech:q.t});
  resolveCommon(ok,q);
}

function renderOrder(q,area){
  orderItems=shuffle(q.items.slice());
  var intro=document.createElement('div');intro.className='order-intro';intro.textContent='Utilise ▲▼ ou glisse-dépose pour réordonner :';
  var list=document.createElement('div');list.className='order-items';list.id='order-list';
  renderOrderList(list,q);
  var vbtn=document.createElement('button');vbtn.className='validate-btn';vbtn.textContent='✓ VALIDER L\'ORDRE';vbtn.onclick=function(){validateOrder(q,list);};
  area.appendChild(intro);area.appendChild(list);area.appendChild(vbtn);
}
function renderOrderList(list,q){
  list.innerHTML='';
  orderItems.forEach(function(item,i){
    var d=document.createElement('div');d.className='order-item';d.setAttribute('data-idx',i);d.setAttribute('draggable','true');
    var num=document.createElement('span');num.className='order-num';num.textContent=(i+1)+'.';
    var txt=document.createElement('span');txt.textContent=item;txt.style.flex='1';
    var arrows=document.createElement('span');arrows.className='order-arrows';
    var up=document.createElement('button');up.className='oarrow';up.textContent='▲';up.type='button';
    var dn=document.createElement('button');dn.className='oarrow';dn.textContent='▼';dn.type='button';
    (function(idx){
      up.onclick=function(e){e.stopPropagation();if(idx>0){var t=orderItems[idx];orderItems[idx]=orderItems[idx-1];orderItems[idx-1]=t;renderOrderList(list,q);}};
      dn.onclick=function(e){e.stopPropagation();if(idx<orderItems.length-1){var t=orderItems[idx];orderItems[idx]=orderItems[idx+1];orderItems[idx+1]=t;renderOrderList(list,q);}};
    })(i);
    arrows.appendChild(up);arrows.appendChild(dn);
    d.appendChild(num);d.appendChild(txt);d.appendChild(arrows);
    d.addEventListener('dragstart',function(){this.classList.add('dragging');});
    d.addEventListener('dragend',function(){this.classList.remove('dragging');list.querySelectorAll('.order-item').forEach(function(x){x.classList.remove('over');});});
    d.addEventListener('dragover',function(e){e.preventDefault();list.querySelectorAll('.order-item').forEach(function(x){x.classList.remove('over');});this.classList.add('over');});
    d.addEventListener('drop',function(e){e.preventDefault();this.classList.remove('over');
      var from=parseInt(document.querySelector('.order-item.dragging').getAttribute('data-idx'));
      var to=parseInt(this.getAttribute('data-idx'));
      if(from!==to){var t=orderItems[from];orderItems[from]=orderItems[to];orderItems[to]=t;renderOrderList(list,q);}});
    list.appendChild(d);
  });
}
function validateOrder(q,list){
  if(answered)return;answered=true;clearInterval(timerInt);
  var ok=JSON.stringify(orderItems)===JSON.stringify(q.items);
  list.querySelectorAll('.order-item').forEach(function(d,i){
    d.style.cursor='default';d.setAttribute('draggable','false');
    d.querySelectorAll('.oarrow').forEach(function(b){b.disabled=true;b.style.opacity='.2';});
    d.classList.add(orderItems[i]===q.items[i]?'correct-pos':'wrong-pos');
  });
  if(!ok)errors.push({q:q.q,yours:'Ordre incorrect',correct:q.items.join(' → '),x:q.x,orig:q,mech:q.t});
  resolveCommon(ok,q);
}

function renderCalc(q,area){
  var setup=document.createElement('div');setup.className='calc-setup';setup.textContent=q.setup;
  var opts=document.createElement('div');opts.className='calc-opts';
  var shuffled=shuffle(q.opts.map(function(o,i){return{v:o.v,sub:o.sub,i:i};}));
  shuffled.forEach(function(opt){
    var b=document.createElement('button');b.className='calc-opt';
    b.innerHTML=opt.v+'<span class="calc-sub">'+opt.sub+'</span>';
    b.setAttribute('data-orig',opt.i);
    b.onclick=function(){if(!answered)resolveCalc(opt.i,b,q,opts);};
    opts.appendChild(b);
  });
  area.appendChild(setup);area.appendChild(opts);
}
function resolveCalc(origIdx,btn,q,optsEl){
  clearInterval(timerInt);answered=true;
  optsEl.querySelectorAll('.calc-opt').forEach(function(b){b.disabled=true;});
  optsEl.querySelectorAll('.calc-opt').forEach(function(b){if(+b.getAttribute('data-orig')===q.a)b.classList.add('ok');});
  var ok=origIdx===q.a;btn.classList.add(ok?'ok':'err');
  if(!ok)errors.push({q:q.q,yours:q.opts[origIdx].v,correct:q.opts[q.a].v,x:q.x,orig:q,mech:q.t});
  resolveCommon(ok,q);
}

function renderDebug(q,area){
  var code=document.createElement('div');code.className='debug-code';
  var html='';q.code.split('\n').forEach(function(l){html+=l===q.errorLine?'<span class="error-line">'+l+'</span>\n':l+'\n';});
  code.innerHTML=html;
  area.appendChild(code);
  renderQCM(q,area); // reuse QCM for options
}

function renderWord(q,area){
  var intro=document.createElement('div');intro.className='word-intro';intro.textContent='Clique sur les bons éléments (plusieurs réponses possibles), puis valide :';
  var cloud=document.createElement('div');cloud.className='word-cloud';cloud.id='word-cloud';
  var selected=[];
  var shuffledWords=shuffle(q.words.slice());
  shuffledWords.forEach(function(w){
    var chip=document.createElement('button');chip.className='word-chip';chip.textContent=w;
    chip.onclick=function(){
      if(answered)return;
      var idx2=selected.indexOf(w);
      if(idx2>-1){selected.splice(idx2,1);chip.classList.remove('selected');}
      else{selected.push(w);chip.classList.add('selected');}
    };
    cloud.appendChild(chip);
  });
  var vbtn=document.createElement('button');vbtn.className='validate-btn';vbtn.textContent='✓ VALIDER LA SÉLECTION';
  vbtn.onclick=function(){validateWord(q,cloud,selected);};
  area.appendChild(intro);area.appendChild(cloud);area.appendChild(vbtn);
}
function validateWord(q,cloud,selected){
  if(answered)return;answered=true;clearInterval(timerInt);
  var correct_set=q.correct.slice().sort().join('|');
  var user_set=selected.slice().sort().join('|');
  var ok=correct_set===user_set;
  cloud.querySelectorAll('.word-chip').forEach(function(chip){
    chip.disabled=true;
    var w=chip.textContent;
    var isCorrect=q.correct.indexOf(w)>-1;
    var isSelected=selected.indexOf(w)>-1;
    if(isCorrect&&isSelected)chip.classList.add('ok');
    else if(!isCorrect&&isSelected)chip.classList.add('err');
    else if(isCorrect&&!isSelected)chip.classList.add('missed');
    chip.classList.remove('selected');
  });
  if(!ok)errors.push({q:q.q,yours:selected.join(', ')||'(rien)',correct:q.correct.join(', '),x:q.x,orig:q,mech:q.t});
  resolveCommon(ok,q);
}

// ====== COMMON ======
function resolveCommon(ok,q){
  // Temps de réponse
  var qt=typeof qStartTime!=='undefined'&&qStartTime>0?(Date.now()-qStartTime)/1000:0;
  if(qt>0){qTimes.push(Math.round(qt*100)/100);qStartTime=0;}
  if(ok){
    correct++;bonusStreak++;
    combo++;if(combo>maxCombo){maxCombo=combo;sStats.maxCombo=combo;}
    flash('g');playOk();animCorrect();
    updDot(idx,'pdot dok');
    if(bonusStreak>0&&bonusStreak%5===0){showBonusToast();}
    checkEasterEgg(bonusStreak);
    updateQSRS(q, true); // SRS update
    updateQuestProgress('played'); updateQuestProgress('correct');
    updateQuestProgress('srs'); updateQuestProgress('weekly_played');
    if(selCat) updateQuestProgress('weekly_cat', selCat);
    if(selMode==='rpg'&&typeof resolveRPG==='function') resolveRPG(true);
    if(betOn&&typeof resolveBet==='function') resolveBet(true);
  } else {
    bonusStreak=0;combo=1;
    if(lives!==99)lives--;
    flash('r');playErr();animWrong();
    updDot(idx,'pdot derr');
    updateStreakFlame(0);
    updateQSRS(q, false); // SRS update
    updateQuestProgress('played'); updateQuestProgress('weekly_played');
    if(selCat) updateQuestProgress('weekly_cat', selCat);
    if(selMode==='rpg'&&typeof resolveRPG==='function') resolveRPG(false);
    if(betOn&&typeof resolveBet==='function') resolveBet(false);
  }
  el('hcombo').textContent='x'+combo;
  updateStreakFlame(bonusStreak);
  if(typeof updateDynDiff==='function') updateDynDiff(ok);
  updScore();updLives();
  // Feedback avec temps
  var timeBadge='';
  if(selMode!=='exam'&&qt>0){
    if(qt<5) timeBadge='<span class="time-badge time-fast">⚡ '+qt.toFixed(1)+'s</span>';
    else if(qt<12) timeBadge='<span class="time-badge time-ok">⏱ '+qt.toFixed(1)+'s</span>';
    else timeBadge='<span class="time-badge time-slow">🐢 '+qt.toFixed(1)+'s</span>';
  }
  showFB(ok,q,timeBadge);
  el('nextbtn').className='next-btn show';
  if(lives===0)setTimeout(gameOver,1600);
}

function updateStreakFlame(streak){
  var fl=document.getElementById('streak-flame');
  var em=document.getElementById('sf-emoji');
  var ct=document.getElementById('sf-count');
  if(!fl) return;
  if(streak<=0){fl.classList.remove('show','big','huge');return;}
  fl.classList.add('show');
  fl.classList.remove('big','huge');
  ct.textContent='x'+streak;
  if(streak>=15){em.textContent='🌋';fl.classList.add('huge');}
  else if(streak>=10){em.textContent='💥';fl.classList.add('huge');}
  else if(streak>=5){em.textContent='🔥';fl.classList.add('big');}
  else{em.textContent='🔥';}
  // hide after wrong answer
}
function showBonusToast(){
  var t=document.createElement('div');t.className='bonus-toast';t.textContent='🔥 '+bonusStreak+' bonnes réponses d\'affilée !';
  document.body.appendChild(t);setTimeout(function(){t.remove();},1500);
}

function expireQ(q){
  answered=true;bonusStreak=0;combo=1;if(lives!==99)lives--;
  flash('r');playErr();updDot(idx,'pdot derr');
  errors.push({q:q.q,yours:'(temps écoulé)',correct:q.opts?q.opts[q.a]:String(q.a),x:q.x,orig:q,mech:q.t});
  updScore();updLives();
  showFB(false,q,true);
  el('nextbtn').className='next-btn show';
  if(lives===0)setTimeout(gameOver,1600);
}

function showFB(ok,q,timeout,timeBadge){
  var fb=el('fbk');
  var ca=q.opts?q.opts[q.a]:(q.a===true?'VRAI':'FAUX');
  if(selMode==='exam')return; // no feedback in exam mode
  var lastT=qTimes.length>0?qTimes[qTimes.length-1]:0;
  var tb2=selMode!=='exam'?getTimeBadge(lastT):'';
  if(ok){fb.className='fbk show fok';fb.innerHTML='&#9989; Bonne réponse !'+tb2+'<div class="fexp">'+q.x+'</div>';}
  else if(timeout){fb.className='fbk show ferr';fb.innerHTML='&#9203; Temps écoulé !'+(timeBadge||'')+'<br><span class="fans">&#10003; '+ca+'</span><div class="fexp">'+q.x+'</div>';}
  else{fb.className='fbk show ferr';fb.innerHTML='&#10060; Mauvaise réponse !'+(timeBadge||'')+'<br><span class="fans">&#10003; '+ca+'</span><div class="fexp">'+q.x+'</div>';}
}

function updLives(){
  if(lives===99){el('hlives').textContent='∞';return;}
  var max=MODES[selMode].lives,l=Math.max(0,lives);
  el('hlives').textContent='❤'.repeat(l)+'🖤'.repeat(Math.max(0,max-l));
}

function flash(t){var e=el('flash');e.className='flash f'+t;e.style.opacity='1';setTimeout(function(){e.style.opacity='0';},140);}
function togglePause(){paused=!paused;el('povl').classList.toggle('show',paused);}

function next(){
  if(selMode==='duel'){showDuelQ();return;}
  if(lives===0)return;
  idx++;if(idx>=session.length)showResults();else{playNext();showQ();}
}

function gameOver(){
  clearInterval(timerInt);saveStats();
  el('go-score').textContent=correct+' / '+session.length;
  var goMsg = selMode==='mort' ? 'Mort subite. 1 erreur = terminé !' : 'Plus de vies — '+(Math.round(correct/session.length*100))+'% de réussite.';
  el('go-sub').textContent=goMsg;
  showScreen('gameover');
}

function saveStats(){
  var pct_h=session.length>0?Math.round(correct/session.length*100):0;
  var hs=hsD[selCat]||0;
  if(correct>hs){hsD[selCat]=correct;lsSet('tssr5_hs',hsD);}
  if(!stD[selCat])stD[selCat]={played:0,correct:0};
  stD[selCat].played+=session.length;stD[selCat].correct+=correct;
  lsSet('tssr5_stats',stD);
  reviewBank=errors.map(function(e){return e.orig;}).filter(Boolean);
  if(selMode!=='duel') saveToHistory(selCat,pct_h,correct,session.length);
  var nb=[];
  BDEFS.forEach(function(b){if(bdD.indexOf(b.id)<0&&b.chk(sStats,errors,correct,session.length,selMode)){bdD.push(b.id);nb.push(b);}});
  lsSet('tssr5_badges',bdD);
  return nb;
}

function showResults(){
  clearInterval(timerInt);
  if(selMode==='speedrun'){var newRec=stopSpeedrun();if(newRec){var el2=document.getElementById('sr-record');if(el2){el2.textContent='🏆 NOUVEAU RECORD !';el2.className='sr-new-record';}}}
  var nb=saveStats();showScreen('results');
  var pct=Math.round(correct/session.length*100);
  showTimeSummary();
  var rank,col,rfill;
  if(pct>=90){rank='S';col='#00a85a';rfill='#00a85a';}
  else if(pct>=75){rank='A';col='var(--acc)';rfill='var(--acc)';}
  else if(pct>=60){rank='B';col='#ff9800';rfill='#ff9800';}
  else if(pct>=40){rank='C';col='#ff9800';rfill='#ff9800';}
  else{rank='D';col='#dc2626';rfill='#dc2626';}
  setTimeout(function(){playRankSound(rank);},400);
  if(rank==='S') setTimeout(function(){launchConfetti();},600);
  el('resrank').textContent=rank;el('resrank').style.color=col;
  el('res-correct').textContent=correct;el('res-total').textContent=session.length;
  el('res-correct').style.color=col;
  setTimeout(function(){el('result-fill').style.width=pct+'%;background:'+rfill;},100);
  el('btnrev').style.display=errors.length>0?'inline-block':'none';

  // badges
  var rb=el('res-badges');rb.innerHTML='';
  nb.forEach(function(b){var d=document.createElement('div');d.className='bunlk';d.innerHTML='<span class="bui">'+b.icon+'</span><span class="bun">BADGE : '+b.name+'</span><div class="bud">'+b.desc+'</div>';rb.appendChild(d);});

  // exam mode: full reveal
  var examSum=el('exam-summary');
  if(selMode==='exam'){
    examSum.style.display='block';
    examSum.innerHTML='<div style="font-family:\'Press Start 2P\',monospace;font-size:9px;color:var(--text2);margin-bottom:12px">RÉSULTATS DÉTAILLÉS — EXAMEN</div>'+session.map(function(q,i){
      var err=errors.filter(function(x){return x.q===q.q;});var ok=err.length===0;
      var ca=q.opts?q.opts[q.a]:(q.a===true?'VRAI':'FAUX');
      return '<div class="exam-q-row"><span class="eq-icon">'+(ok?'✅':'❌')+'</span><div><div class="eq-q">Q'+(i+1)+'. '+q.q+'</div>'+(ok?'<div class="eq-ans eq-ok">✓ Bonne réponse : '+ca+'</div>':'<div class="eq-ans eq-err">✗ Ta réponse : '+(err[0]?err[0].yours:'?')+'</div><div class="eq-ans eq-ok">✓ Bonne réponse : '+ca+'</div>')+'<div class="eq-exp">'+q.x+'</div></div></div>';
    }).join('');
    el('res-tabs').style.display='none';
    el('tab-recap').style.display='none';
    el('tab-errors').style.display='none';
  } else {
    examSum.style.display='none';
    el('res-tabs').style.display='flex';
    el('tab-recap').style.display='';
    el('tab-errors').style.display='';
  }

  var ML={qcm:'QCM',tf:'V/F',fill:'Compléter',order:'Ordre',calc:'Calcul',debug:'Débug',word:'Sélection'};
  el('tab-recap').innerHTML=session.map(function(q){var e=errors.filter(function(x){return x.q===q.q;}).length>0;return '<div class="rrow"><span>'+(e?'❌':'✅')+'</span><span>'+q.q+'</span><span class="rmech">'+(ML[q.t]||q.t)+'</span></div>';}).join('');
  buildQStatsTab();
  el('tab-errors').innerHTML=errors.length===0?'<div style="text-align:center;padding:24px;font-family:\'Press Start 2P\',monospace;font-size:10px;color:#00a85a">PARFAIT !</div>':errors.map(function(e){return '<div class="ecard"><div class="eq2">'+e.q+'</div><div class="ey">&#10007; '+e.yours+'</div><div class="ec">&#10003; '+e.correct+'</div><div class="ex">'+e.x+'</div></div>';}).join('');
}

function switchTab(tab,ev){
  document.querySelectorAll('.rtab').forEach(function(t){t.classList.remove('active');});
  document.querySelectorAll('.tbody').forEach(function(t){t.classList.remove('active');});
  ev.target.classList.add('active');el('tab-'+tab).classList.add('active');
}


// ===================== FLASHCARDS =====================
var flashDeck=[], flashIdx=0, flashFlipped=false, flashSelCat='reseau', flashSelDiff='all';
var flashBad=[], flashOk=[], flashGood=[];
var flashCurQ=null;

function buildFlashDeck(cat,diff){
  var pool=CATS[cat].qs;
  if(diff!=='all') pool=pool.filter(function(q){return q.d===parseInt(diff);});
  if(pool.length===0) pool=CATS[cat].qs;
  return freshShuffle(pool);
}

function getFlashAnswer(q){
  if(q.t==='qcm'||q.t==='debug') return q.opts[q.a];
  if(q.t==='tf') return q.a===true?'VRAI ✅':'FAUX ❌';
  if(q.t==='fill') return q.opts[q.a];
  if(q.t==='calc') return q.opts[q.a].v;
  if(q.t==='order') return q.items.join(' → ');
  if(q.t==='word') return q.correct.join(', ');
  return String(q.a);
}

function startFlash(){
  flashSelCat=selCat; flashSelDiff=selDiff;
  var count=selQCount===9999?9999:selQCount;
  flashDeck=buildFlashDeck(flashSelCat,flashSelDiff).slice(0,Math.min(count,9999));
  flashIdx=0; flashFlipped=false; flashBad=[]; flashOk=[]; flashGood=[];
  applyBody();
  showScreen('flash');
  showFlashCard();
}

function showFlashCard(){
  if(flashIdx>=flashDeck.length){endFlash();return;}
  var q=flashDeck[flashIdx];
  var catLabel=(q._cat||CATS[flashSelCat].label).toUpperCase();
  var card=document.getElementById('flash-card');
  flashFlipped=false;
  card.classList.remove('revealed');
  document.getElementById('flash-q').innerHTML=q.q;
  document.getElementById('flash-cat').textContent=catLabel;
  document.getElementById('flash-cat-b').textContent=catLabel;
  document.getElementById('flash-ans').textContent=getFlashAnswer(q);
  document.getElementById('flash-exp').textContent=q.x||'';
  document.getElementById('flash-prog').textContent=(flashIdx+1)+' / '+flashDeck.length;
  var pct=Math.round(flashIdx/flashDeck.length*100);
  document.getElementById('flash-pfill').style.width=pct+'%';
  document.getElementById('flash-counter').textContent='Clic sur la carte pour voir la réponse';
  document.getElementById('flash-btns').style.display='none';
  document.getElementById('fs-bad').textContent=flashBad.length;
  document.getElementById('fs-ok').textContent=flashOk.length;
  document.getElementById('fs-good').textContent=flashGood.length;
  var front=card.querySelector('.flash-front-side');
  if(front){front.style.animation='none';front.offsetHeight;front.style.animation='';}
}

function flipCard(){
  var card=document.getElementById('flash-card');
  if(!flashFlipped){
    card.classList.add('revealed');
    flashFlipped=true;
    document.getElementById('flash-counter').textContent='Tu le savais ?';
    document.getElementById('flash-btns').style.display='flex';
  }
}

function rateFlash(rating){
  if(!flashFlipped) return;
  if(rating===0) flashBad.push(flashCurQ);
  else if(rating===1) flashOk.push(flashCurQ);
  else flashGood.push(flashCurQ);
  flashIdx++;
  showFlashCard();
}

function startFlashRetry(){
  if(flashBad.length+flashOk.length===0){goMenu();return;}
  flashDeck=shuffle(flashBad.concat(flashOk));
  flashIdx=0; flashFlipped=false; flashBad=[]; flashOk=[]; flashGood=[];
  showScreen('flash');
  showFlashCard();
}

function endFlash(){
  showScreen('flash-result');
  document.getElementById('fr-good').textContent=flashGood.length;
  document.getElementById('fr-ok').textContent=flashOk.length;
  document.getElementById('fr-bad').textContent=flashBad.length;
}

// keyboard for flashcards
document.addEventListener('keydown',function(e){
  if(!document.getElementById('screen-flash').classList.contains('active')) return;
  if(e.key===' '||e.key==='Enter'){e.preventDefault();
    if(!flashFlipped) flipCard();
  }
  if(e.key==='1'&&flashFlipped) rateFlash(0);
  if(e.key==='2'&&flashFlipped) rateFlash(1);
  if(e.key==='3'&&flashFlipped) rateFlash(2);
});



// =====================================================
// DUEL MODE — TOUR PAR TOUR
// =====================================================
var duelNames=['Joueur 1','Joueur 2'];
var duelScores=[0,0];
var duelTarget=5;
var duelTurn=0;
var duelAnswered=false;
var duelQIdx=0;
var duelCurQ=null; // track current question clearly

function pickDuelTarget(btn){
  document.querySelectorAll('.duel-tbtn').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  duelTarget=parseInt(btn.getAttribute('data-t'));
}

function launchDuel(){
  duelNames[0]=(document.getElementById('duel-name-1').value||'Joueur 1').trim();
  duelNames[1]=(document.getElementById('duel-name-2').value||'Joueur 2').trim();
  duelScores=[0,0]; duelTurn=0; duelAnswered=false; duelQIdx=0; duelCurQ=null;

  var cat=CATS[selCat], pool=cat.qs;
  // Duel: only use qcm and debug questions (both have opts array)
  pool=pool.filter(function(q){return q.t==='qcm'||q.t==='debug';});
  if(selDiff!=='all') pool=pool.filter(function(q){return q.d===parseInt(selDiff);});
  if(!pool.length) pool=cat.qs.filter(function(q){return q.t==='qcm'||q.t==='debug';});
  if(!pool.length) pool=cat.qs; // ultimate fallback
  session=freshShuffle(pool).slice(0,50);
  markShown(session);

  applyBody();
  el('gbadge').textContent='⚔️ DUEL · '+duelNames[0]+' vs '+duelNames[1];
  var jr=el('jokers-row'); if(jr) jr.style.display='none';
  var sh=el('score-hud'); if(sh) sh.style.display='none';
  buildDots();
  showScreen('game');
  showDuelQ();
}

function showDuelQ(){
  // Guard
  if(duelQIdx>=session.length) duelQIdx=0;
  duelCurQ=session[duelQIdx];
  // Skip questions without opts (word/order/calc/fill)
  var safetyGuard=0;
  while(duelCurQ&&!duelCurQ.opts&&safetyGuard<session.length){
    duelQIdx=(duelQIdx+1)%session.length;
    duelCurQ=session[duelQIdx];
    safetyGuard++;
  }
  duelAnswered=false;

  var q=duelCurQ;
  var p=duelTurn;
  var area=el('question-area');
  area.innerHTML='';

  // Turn banner
  var col=p===0?'#38bdf8':'#f472b6';
  var cls=p===0?'turn-p1':'turn-p2';
  var banner=document.createElement('div');
  banner.className='duel-turn-banner '+cls;
  banner.innerHTML='<span class="duel-turn-icon">'+(p===0?'🔵':'🩷')+'</span>&nbsp;Tour de <strong>'+duelNames[p]+'</strong>';
  area.appendChild(banner);

  // Scoreboard
  var pct0=Math.min(100,Math.round(duelScores[0]/duelTarget*100));
  var pct1=Math.min(100,Math.round(duelScores[1]/duelTarget*100));
  var sb=document.createElement('div'); sb.className='duel-scoreboard';
  sb.innerHTML=
    '<div class="dsp'+(p===0?' p1-active':'')+'">'+
      '<span class="dsp-name" style="color:#38bdf8">'+duelNames[0]+'</span>'+
      '<span class="dsp-score" style="color:#38bdf8">'+duelScores[0]+'</span>'+
      '<div class="dsp-bar"><div class="dsp-fill" style="width:'+pct0+'%;background:#38bdf8"></div></div>'+
    '</div>'+
    '<div class="duel-vs-mid">/ '+duelTarget+'</div>'+
    '<div class="dsp'+(p===1?' p2-active':'')+'">'+
      '<span class="dsp-name" style="color:#f472b6">'+duelNames[1]+'</span>'+
      '<span class="dsp-score" style="color:#f472b6">'+duelScores[1]+'</span>'+
      '<div class="dsp-bar"><div class="dsp-fill" style="width:'+pct1+'%;background:#f472b6"></div></div>'+
    '</div>';
  area.appendChild(sb);

  // Card
  var card=document.createElement('div'); card.className='qcard'; card.id='qcard';
  card.style.cssText='--acc:'+col+';';
  // add diff color to qdiff span after render
  setTimeout(function(){var qd=card.querySelector('.qdiff');if(qd){qd.style.color=DS_COLORS[q.d]||'var(--dim)';qd.style.fontSize='9px';}},0);
  card.innerHTML='<span class="qdiff">'+DS[q.d]+'</span><div class="qnum">Question '+(duelQIdx+1)+'</div><div class="qtext">'+q.q+(q._cat?'<span class="qcat-tag">['+q._cat+']</span>':'')+'</div>';
  area.appendChild(card);

  // Options — shuffle and store mapping
  var shuffled=shuffle(q.opts.map(function(t,i){return{t:t,i:i};}));
  var keys=p===0?['Q','W','E','R']:['U','I','O','P'];
  var wrap=document.createElement('div'); wrap.className='opts'; wrap.id='duel-opts';

  for(var ki=0;ki<Math.min(4,shuffled.length);ki++){
    (function(optData,keyLabel,keyIndex){
      var b=document.createElement('button'); b.className='opt';
      b.innerHTML='<span class="okey">'+keyLabel+'</span><span>'+optData.t+'</span>';
      b.setAttribute('data-orig',''+optData.i);
      b.setAttribute('data-key-idx',''+keyIndex);
      b.onclick=function(){
        if(!duelAnswered) pickDuelAnswer(optData.i, b, wrap);
      };
      wrap.appendChild(b);
    })(shuffled[ki], keys[ki], ki);
  }
  area.appendChild(wrap);

  // Reset feedback and next button
  el('fbk').className='fbk';
  el('nextbtn').className='next-btn';
  el('hint-txt').textContent=(p===0?duelNames[0]+' : Q·W·E·R':duelNames[1]+' : U·I·O·P');

  // Timer 20s
  clearInterval(timerInt);
  var tb=el('tbar'); tb.style.width='100%'; tb.style.background='#00d87a';
  timeLeft=20;
  timerInt=setInterval(function(){
    if(paused) return;
    timeLeft-=0.1;
    var pct=(timeLeft/20)*100;
    tb.style.width=pct+'%';
    if(pct<50) tb.style.background='#ff9800';
    if(pct<20) tb.style.background='#dc2626';
    updateTimerDrama(pct,timeLeft);
    if(timeLeft<=0){
      clearInterval(timerInt);
      if(!duelAnswered){
        duelAnswered=true;
        wrap.querySelectorAll('.opt').forEach(function(b){b.disabled=true;});
        wrap.querySelectorAll('.opt').forEach(function(b){if(+b.getAttribute('data-orig')===q.a)b.classList.add('ok');});
        var fbk=el('fbk');
        fbk.className='fbk show ferr';
        fbk.innerHTML='⏰ Temps écoulé !<span class="fans"> ✓ '+q.opts[q.a]+'</span><div class="fexp">'+q.x+'</div>';
        duelTurn=1-duelTurn;
        duelQIdx++;
        el('nextbtn').className='next-btn show';
        el('hint-txt').textContent='Espace → tour de '+duelNames[duelTurn];
      }
    }
  },100);
}

function pickDuelAnswer(origIdx, btn, wrap){
  if(duelAnswered) return;
  duelAnswered=true;
  clearInterval(timerInt);

  var q=duelCurQ;
  var p=duelTurn;
  var ok=(origIdx===q.a);

  // Disable all, mark correct
  wrap.querySelectorAll('.opt').forEach(function(b){b.disabled=true;});
  wrap.querySelectorAll('.opt').forEach(function(b){if(+b.getAttribute('data-orig')===q.a)b.classList.add('ok');});
  btn.classList.add(ok?'ok':'err');

  var fbk=el('fbk');
  if(ok){
    duelScores[p]++;
    flash('g'); playOk();
    fbk.className='fbk show fok';
    fbk.innerHTML='✅ <strong>'+duelNames[p]+'</strong> a la bonne réponse ! ('+duelScores[p]+'/'+duelTarget+')<div class="fexp">'+q.x+'</div>';
    if(duelScores[p]>=duelTarget){
      setTimeout(function(){showDuelWin(p);},800);
      return;
    }
  } else {
    flash('r'); playErr();
    fbk.className='fbk show ferr';
    fbk.innerHTML='❌ Mauvais !<span class="fans"> ✓ '+q.opts[q.a]+'</span><div class="fexp">'+q.x+'</div>';
  }

  // Switch turn and advance question
  duelTurn=1-duelTurn;
  duelQIdx++;
  el('nextbtn').className='next-btn show';
  el('hint-txt').textContent='Espace → tour de '+duelNames[duelTurn];
}

function showDuelWin(winner){
  clearInterval(timerInt);
  var win=document.getElementById('duel-win');
  var col=winner===0?'#38bdf8':'#f472b6';
  document.getElementById('dw-title').textContent=duelNames[winner]+' GAGNE ! 🏆';
  document.getElementById('dw-title').style.color=col;
  document.getElementById('dw-scores').innerHTML=
    '<div class="duel-fs"><span class="duel-fs-name" style="color:#38bdf8">'+duelNames[0]+'</span><span class="duel-fs-val" style="color:#38bdf8">'+duelScores[0]+'</span></div>'+
    '<div class="duel-fs" style="font-size:24px;color:var(--dim)"> - </div>'+
    '<div class="duel-fs"><span class="duel-fs-name" style="color:#f472b6">'+duelNames[1]+'</span><span class="duel-fs-val" style="color:#f472b6">'+duelScores[1]+'</span></div>';
  document.getElementById('dw-sub').textContent='Premier a '+duelTarget+' points !';
  win.classList.add('show');
  if(typeof playBonus==='function') playBonus();
}

// Keyboard for duel — only active player keys work
function duelKeydown(e){
  if(selMode!=='duel' || duelAnswered) return;
  var p1map={Q:0,W:1,E:2,R:3};
  var p2map={U:0,I:1,O:2,P:3};
  var k=e.key.toUpperCase();
  var map=duelTurn===0?p1map:p2map;
  if(map[k]===undefined) return;
  var opts=document.querySelectorAll('#duel-opts .opt:not(:disabled)');
  var btn=Array.from(opts).find(function(b){return +b.getAttribute('data-key-idx')===map[k];});
  if(btn) btn.click();
}

// =====================================================
// TIMER DRAMATIQUE
// =====================================================
function updateTimerDrama(pct,seconds){
  var wrap=el('tbarwrap');
  if(!wrap) return;
  if(pct<20){
    wrap.classList.add('danger');
    // Show countdown
    var cd=document.getElementById('tbar-countdown');
    if(!cd){cd=document.createElement('div');cd.id='tbar-countdown';cd.className='tbar-countdown';el('tbarwrap').parentNode.insertBefore(cd,el('tbarwrap'));}
    cd.textContent=Math.ceil(seconds)+'s';
    cd.classList.add('visible');
  } else {
    wrap.classList.remove('danger');
    var cd=document.getElementById('tbar-countdown');
    if(cd) cd.classList.remove('visible');
  }
}

// =====================================================
// STATS & PROGRESSION
// =====================================================
var historyD=lsGet('tssr5_history',[]);

function saveToHistory(cat,pct,correct,total){
  historyD.push({date:Date.now(),cat:cat,pct:pct,correct:correct,total:total});
  if(historyD.length>50) historyD=historyD.slice(-50);
  lsSet('tssr5_history',historyD);
}

function showStatsScreen(){
  showScreen('stats');
  var totalGames=historyD.length;
  var avgPct=totalGames>0?Math.round(historyD.reduce(function(a,b){return a+b.pct;},0)/totalGames):0;
  el('st-total').textContent=totalGames;
  el('st-pct').textContent=avgPct+'%';
  el('st-streak').textContent=streakD.current+'j';

  // Draw progress graph
  drawProgressGraph();
  drawMastery();
  // Show weak cats button only if enough data
  var hasData=Object.keys(stD).some(function(k){return stD[k]&&stD[k].played>0;});
  var btn=document.getElementById('btn-weak-cats');
  if(btn) btn.style.display=hasData?'inline-block':'none';
}

function drawProgressGraph(){
  var canvas=el('prog-canvas');
  if(!canvas) return;
  canvas.width=canvas.offsetWidth||600;
  var ctx=canvas.getContext('2d');
  var W=canvas.width, H=canvas.height||120;
  ctx.clearRect(0,0,W,H);
  var data=historyD.slice(-20);
  if(data.length<2){
    ctx.fillStyle=getComputedStyle(document.body).getPropertyValue('--text2').trim();
    ctx.font='12px DM Mono,monospace'; ctx.textAlign='center';
    ctx.fillText('Pas encore assez de données — joue d abord !',W/2,H/2);
    return;
  }
  var st=getComputedStyle(document.body);
  var cBorder=st.getPropertyValue('--border').trim();
  var cAcc=st.getPropertyValue('--acc').trim();
  var cText2=st.getPropertyValue('--text2').trim();
  var padL=30,padR=10,padT=10,padB=20;
  var gW=W-padL-padR, gH=H-padT-padB;
  // Grid lines
  [0,25,50,75,100].forEach(function(v){
    var y=padT+gH*(1-v/100);
    ctx.strokeStyle=cBorder; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(padL,y); ctx.lineTo(W-padR,y); ctx.stroke();
    ctx.fillStyle=cText2; ctx.font='8px DM Mono,monospace'; ctx.textAlign='right';
    ctx.fillText(v+'%',padL-4,y+3);
  });
  // Line
  ctx.beginPath(); ctx.strokeStyle=cAcc; ctx.lineWidth=2.5;
  data.forEach(function(d,i){
    var x=padL+gW*i/(data.length-1);
    var y=padT+gH*(1-d.pct/100);
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  });
  ctx.stroke();
  // Area fill
  ctx.beginPath();
  data.forEach(function(d,i){
    var x=padL+gW*i/(data.length-1);
    var y=padT+gH*(1-d.pct/100);
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  });
  ctx.lineTo(padL+gW,padT+gH); ctx.lineTo(padL,padT+gH); ctx.closePath();
  ctx.fillStyle='rgba('+hexToRgb(cAcc)+',0.08)'; ctx.fill();
  // Dots
  data.forEach(function(d,i){
    var x=padL+gW*i/(data.length-1);
    var y=padT+gH*(1-d.pct/100);
    ctx.beginPath(); ctx.arc(x,y,3.5,0,Math.PI*2);
    ctx.fillStyle=d.pct>=75?'#00a85a':d.pct>=50?'#ff9800':'#dc2626';
    ctx.fill();
  });
}

function hexToRgb(hex){
  // Handle var() css vars — return fallback
  if(hex.startsWith('var')) return '56,189,248';
  var r=parseInt(hex.slice(1,3),16)||56;
  var g=parseInt(hex.slice(3,5),16)||189;
  var b=parseInt(hex.slice(5,7),16)||248;
  return r+','+g+','+b;
}

function startWeakCats(){
  // Find the 3 categories with lowest mastery (min 5 questions played)
  var cats=Object.keys(CATS).filter(function(k){return k!=='mix';});
  var ranked=cats.map(function(k){
    var st=stD[k]||{played:0,correct:0};
    var pct=st.played>0?Math.round(st.correct/st.played*100):0;
    return {k:k,pct:pct,played:st.played};
  }).filter(function(x){return x.played>0;}).sort(function(a,b){return a.pct-b.pct;});
  if(!ranked.length){alert("Joue dabord quelques parties !");return;}
  // Build pool from the 3 weakest
  var pool=[];
  ranked.slice(0,3).forEach(function(r){
    CATS[r.k].qs.forEach(function(q){pool.push(Object.assign({},q,{_cat:CATS[r.k].label}));});
  });
  if(!pool.length) return;
  selMode='chill';
  session=freshShuffle(pool).slice(0,Math.min(selQCount,pool.length));
  markShown(session);
  correct=0;combo=1;maxCombo=1;errors=[];idx=0;paused=false;bonusStreak=0;lives=5;
  jokers=3;
  sStats={cat:'mix',mode:'chill',maxCombo:0,mechs:new Set(),streak:streakD.current};
  el('gbadge').textContent='🎯 CATÉGORIES FAIBLES';
  var sh=el('score-hud');if(sh)sh.style.display='grid';
  el('htotal').textContent=session.length;
  buildDots();
  showScreen('game');
  showQ();
}

function drawMastery(){
  var list=el('mastery-list');
  if(!list) return;
  list.innerHTML='';
  var catKeys=Object.keys(CATS).filter(function(k){return k!=='mix';});
  catKeys.forEach(function(catId){
    var st=stD[catId]||{played:0,correct:0};
    var pct=st.played>0?Math.round(st.correct/st.played*100):0;
    var col=pct>=80?'#00a85a':pct>=60?'#ff9800':pct>=40?'#fbbf24':'#dc2626';
    var level=pct>=80?'Expert':pct>=60?'Avancé':pct>=40?'Intermédiaire':st.played>0?'Débutant':'Non commencé';
    var row=document.createElement('div'); row.className='mastery-row';
    row.innerHTML=
      '<div class="mastery-top">'+
        '<span class="mastery-cat">'+CATS[catId].icon+' '+CATS[catId].label+'</span>'+
        '<span class="mastery-pct" style="color:'+col+'">'+pct+'%</span>'+
      '</div>'+
      '<div class="mastery-bar"><div class="mastery-fill" style="width:0%;background:'+col+'" data-pct="'+pct+'"></div></div>'+
      '<div class="mastery-detail">'+level+' · '+st.played+' questions jouées</div>';
    list.appendChild(row);
  });
  // Animate bars after render
  setTimeout(function(){
    list.querySelectorAll('.mastery-fill').forEach(function(bar){
      bar.style.width=bar.getAttribute('data-pct')+'%';
    });
  },100);
}

// =====================================================
// EASTER EGG — 15 bonnes réponses d'affilée
// =====================================================
var easterActive=false;
function checkEasterEgg(streak){
  if(streak>=15&&!easterActive){
    easterActive=true;
    var ov=document.getElementById('easter-overlay');
    var messages=["UNSTOPPABLE !","LEGENDAIRE !","T ES CHAUD BOUILLANT !","PERSONNE PEUT TE STOP !"];
    document.getElementById('easter-text').textContent=messages[Math.floor(Math.random()*messages.length)];
    ov.classList.add('show');
    // Rainbow mode for 3s
    document.body.classList.add('rainbow-mode');
    setTimeout(function(){
      ov.classList.remove('show');
      document.body.classList.remove('rainbow-mode');
      easterActive=false;
    },3000);
  }
}


// =====================================================
// CONFETTIS (rang S)
// =====================================================
function launchConfetti(){
  var colors=['#38bdf8','#f472b6','#4ade80','#fbbf24','#f87171','#a78bfa'];
  for(var i=0;i<60;i++){
    (function(delay){
      setTimeout(function(){
        var c=document.createElement('div');
        c.className='confetti-piece';
        c.style.left=Math.random()*100+'vw';
        c.style.background=colors[Math.floor(Math.random()*colors.length)];
        c.style.animationDuration=(1.5+Math.random()*2)+'s';
        c.style.animationDelay='0s';
        document.body.appendChild(c);
        setTimeout(function(){c.remove();},4000);
      },delay);
    })(i*40);
  }
}

// =====================================================
// DÉFI QUOTIDIEN
// =====================================================
var dailyData=lsGet('tssr5_daily',{});

function getDailyQuestion(){
  // Deterministic question based on date (same question for everyone on same day)
  var today=new Date().toDateString();
  var dayNum=Math.floor(Date.now()/86400000);
  // Pick from hard questions
  var hardQs=[];
  Object.keys(CATS).forEach(function(k){
    if(k==='mix') return;
    CATS[k].qs.filter(function(q){return q.d===3&&(q.t==='qcm'||q.t==='debug');}).forEach(function(q){
      hardQs.push(Object.assign({},q,{_cat:CATS[k].label}));
    });
  });
  if(!hardQs.length) return null;
  return hardQs[dayNum % hardQs.length];
}

function buildDailyWidget(){
  var widget=document.getElementById('daily-widget');
  if(!widget) return;
  var today=new Date().toDateString();
  var q=getDailyQuestion();
  if(!q){widget.innerHTML='';return;}
  var done=dailyData[today];

  if(done){
    widget.innerHTML='<div class="daily-card"><div class="daily-header"><span class="daily-icon">📅</span><span class="daily-title">DÉFI DU JOUR</span><span class="daily-date">'+new Date().toLocaleDateString('fr-FR')+'</span></div><div class="daily-done">'+(done.ok?'✅ Réussi !':'❌ Raté — mais tu le sauras demain !')+'<div class="daily-streak" style="margin-top:8px;font-size:9px;color:var(--text2);">'+q.x+'</div></div></div>';
    return;
  }

  widget.innerHTML='<div class="daily-card" id="daily-q-card"><div class="daily-header"><span class="daily-icon">📅</span><span class="daily-title">DÉFI DU JOUR</span><span class="daily-date">'+new Date().toLocaleDateString('fr-FR')+'</span></div><div class="daily-body"><div class="daily-q">'+q.q+'</div><div id="daily-opts" class="opts"></div></div></div>';

  var shuffled=shuffle(q.opts.map(function(t,i){return{t:t,i:i};}));
  var optsDiv=document.getElementById('daily-opts');
  ['A','B','C','D'].forEach(function(k,i){
    if(!shuffled[i]) return;
    var b=document.createElement('button'); b.className='opt';
    b.innerHTML='<span class="okey">'+k+'</span><span>'+shuffled[i].t+'</span>';
    b.onclick=(function(opt){return function(){
      // Disable all
      optsDiv.querySelectorAll('.opt').forEach(function(x){x.disabled=true;});
      optsDiv.querySelectorAll('.opt').forEach(function(x){if(+x.getAttribute('data-orig')===q.a)x.classList.add('ok');});
      var ok=opt.i===q.a;
      b.classList.add(ok?'ok':'err');
      dailyData[today]={ok:ok};lsSet('tssr5_daily',dailyData);
      if(ok){beep(784,.15,'sine',.2);}else{beep(200,.1,'sawtooth',.15);}
      // Show explanation
      var exp=document.createElement('div');
      exp.style.cssText='font-size:11px;color:var(--text2);margin-top:10px;padding-top:8px;border-top:1px solid var(--border);line-height:1.7;';
      exp.textContent=q.x;
      document.querySelector('.daily-body').appendChild(exp);
    };})(shuffled[i]);
    b.setAttribute('data-orig',shuffled[i].i);
    optsDiv.appendChild(b);
  });
}

// =====================================================
// SCORE PARTAGEABLE
// =====================================================
function toggleShare(){
  var box=document.getElementById('share-box');
  if(!box) return;
  if(box.style.display!=='none'){
    box.style.display='none';
    var cb=document.getElementById('copy-share-btn');if(cb)cb.style.display='none';
    return;
  }
  var pct=Math.round(correct/session.length*100);
  var rank=pct>=90?'S':pct>=75?'A':pct>=60?'B':pct>=40?'C':'D';
  var bars='';
  Object.keys(CATS).filter(function(k){return k!=='mix';}).slice(0,6).forEach(function(k){
    var st=stD[k]||{played:0,correct:0};
    var p=st.played>0?Math.round(st.correct/st.played*100):0;
    var bar=Math.round(p/10);
    bars+='  '+CATS[k].icon+' '+CATS[k].label.substring(0,12).padEnd(12)+' '+'█'.repeat(bar)+'░'.repeat(10-bar)+' '+p+'%\n';
  });
  var text='📚 TSSR QUIZ — Résultats\n'+'═'.repeat(30)+'\n'+'🏆 Rang : '+rank+'   Score : '+correct+'/'+session.length+' ('+pct+'%)\n'+'⚡ Combo max : x'+maxCombo+'\n'+'═'.repeat(30)+'\n'+bars+'\n'+'🔥 Streak : '+streakD.current+' jours';
  box.textContent=text;
  box.style.display='block';
  var cb=document.getElementById('copy-share-btn');if(cb)cb.style.display='inline-block';
}

function copyShare(){
  var box=document.getElementById('share-box');
  if(!box) return;
  navigator.clipboard.writeText(box.textContent).then(function(){
    var t=document.getElementById('copied-toast');
    if(t){t.style.display='block';setTimeout(function(){t.style.display='none';},2000);}
  }).catch(function(){
    // fallback
    var ta=document.createElement('textarea');
    ta.value=box.textContent;
    document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();
  });
}

// =====================================================
// BLIND MODE — question révélée mot par mot
// =====================================================
function revealBlind(qtext){
  var el=document.getElementById('qtext');
  if(!el||selMode!=='blind') return;
  var text=qtext;
  var words=text.split(' ');
  el.innerHTML=words.map(function(w){return '<span class="blind-reveal">'+w+'</span>';}).join(' ');
  var spans=el.querySelectorAll('.blind-reveal');
  spans.forEach(function(s,i){setTimeout(function(){s.classList.add('shown');},i*80);});
}


// =====================================================
// MODE DISCUSSION — PROJO / CLASSE
// =====================================================
var discTimer=30, discN=10;
var discSession=[], discIdx=0, discRevealed=false;
var discTimerInt=null, discTimeLeft=0;
var discGroupScores=[]; // 1=found, 0=not found, null=not rated

function pickDiscTimer(btn){
  document.querySelectorAll('.disc-tbtn[data-t]').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  discTimer=parseInt(btn.getAttribute('data-t'));
}
function pickDiscN(btn){
  document.querySelectorAll('.disc-tbtn[data-n]').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  discN=parseInt(btn.getAttribute('data-n'));
}

function startDiscussion(){
  // Build pool — prefer qcm questions (cleaner for group discussion)
  var pool=CATS[selCat].qs;
  if(selDiff!=='all') pool=pool.filter(function(q){return q.d===parseInt(selDiff);});
  if(!pool.length) pool=CATS[selCat].qs;
  discSession=freshShuffle(pool).slice(0,Math.min(discN===9999?9999:discN,pool.length));
  discIdx=0; discRevealed=false; discGroupScores=[];
  discSession.forEach(function(){discGroupScores.push(null);});

  // Show game, hide setup/results
  document.getElementById('disc-setup').style.display='none';
  document.getElementById('disc-results').style.display='none';
  var game=document.getElementById('disc-game');
  game.style.display='flex'; game.style.flexDirection='column';

  applyBody();
  showScreen('discussion');
  showDiscQ();
}

function showDiscQ(){
  if(discIdx>=discSession.length){showDiscResults();return;}
  discRevealed=false;
  clearInterval(discTimerInt);

  var q=discSession[discIdx];
  var catLabel=(q._cat||CATS[selCat].label).toUpperCase();

  // Populate
  document.getElementById('disc-cat-pill').textContent=catLabel;
  document.getElementById('disc-qnum').textContent='QUESTION '+(discIdx+1)+' / '+discSession.length;
  document.getElementById('disc-q').innerHTML=q.q;
  // Answer
  var ans='';
  if(q.t==='qcm'||q.t==='debug') ans=q.opts[q.a];
  else if(q.t==='tf') ans=q.a===true?'VRAI ✅':'FAUX ❌';
  else if(q.t==='fill') ans=q.opts[q.a];
  else if(q.t==='calc') ans=q.opts[q.a].v;
  else if(q.t==='order') ans=q.items.join(' → ');
  else if(q.t==='word') ans=q.correct.join(', ');
  document.getElementById('disc-ans').textContent=ans;
  document.getElementById('disc-exp').textContent=q.x||'';

  // Hide reveal
  var rev=document.getElementById('disc-reveal');
  rev.classList.remove('show'); rev.style.display='none';

  // Buttons
  var revBtn=document.getElementById('disc-reveal-btn');
  revBtn.textContent='👁 RÉVÉLER'; revBtn.classList.remove('revealed');
  document.getElementById('disc-next-btn').style.display='none';
  document.getElementById('disc-score-row').style.display='none';
  document.getElementById('disc-hint').style.display='block';
  document.getElementById('disc-prog').textContent=(discIdx+1)+' / '+discSession.length;

  // Timer
  var timerWrap=document.getElementById('disc-timer-wrap');
  if(discTimer>0){
    timerWrap.style.display='flex';
    discTimeLeft=discTimer;
    timerWrap.classList.remove('danger');
    document.getElementById('disc-timer-num').textContent=discTimeLeft;
    document.getElementById('disc-timer-fill').style.width='100%';
    document.getElementById('disc-timer-fill').style.background='var(--acc)';

    discTimerInt=setInterval(function(){
      discTimeLeft--;
      var pct=(discTimeLeft/discTimer)*100;
      document.getElementById('disc-timer-num').textContent=discTimeLeft;
      document.getElementById('disc-timer-fill').style.width=pct+'%';
      if(pct<33){
        timerWrap.classList.add('danger');
        document.getElementById('disc-timer-fill').style.background='#dc2626';
      }
      if(discTimeLeft<=0){
        clearInterval(discTimerInt);
        if(!discRevealed) discReveal(); // auto-révèle à 0
      }
    },1000);
  } else {
    timerWrap.style.display='none';
  }
}

function discReveal(){
  if(discRevealed) return;
  discRevealed=true;
  clearInterval(discTimerInt);

  var rev=document.getElementById('disc-reveal');
  rev.style.display='block';
  setTimeout(function(){rev.classList.add('show');},10);

  document.getElementById('disc-hint').style.display='none';
  var revBtn=document.getElementById('disc-reveal-btn');
  revBtn.textContent='✅ RÉVÉLÉ'; revBtn.classList.add('revealed');
  document.getElementById('disc-next-btn').style.display='inline-block';
  document.getElementById('disc-score-row').style.display='flex';
}

function discClickReveal(){
  if(!discRevealed) discReveal();
}

function discScore(val){
  discGroupScores[discIdx]=val;
  discNext();
}

function discNext(){
  discIdx++;
  if(discIdx>=discSession.length) showDiscResults();
  else showDiscQ();
}

function showDiscResults(){
  clearInterval(discTimerInt);
  document.getElementById('disc-game').style.display='none';
  var res=document.getElementById('disc-results');
  res.style.display='block';

  var found=discGroupScores.filter(function(s){return s===1;}).length;
  var rated=discGroupScores.filter(function(s){return s!==null;}).length;
  document.getElementById('disc-res-score').textContent=found+' / '+rated;
  document.getElementById('disc-res-sub').textContent='Le groupe a trouvé '+found+' question'+(found>1?'s':'')+' sur '+rated+' notées';

  // List
  var list=document.getElementById('disc-res-list');
  list.innerHTML=discSession.map(function(q,i){
    var sc=discGroupScores[i];
    var icon=sc===1?'✅':sc===0?'❌':'—';
    var ans=q.t==='qcm'||q.t==='debug'?q.opts[q.a]:q.t==='tf'?(q.a?'VRAI':'FAUX'):q.t==='fill'?q.opts[q.a]:'...';
    return '<div class="disc-res-row"><span style="flex-shrink:0">'+icon+'</span><span style="flex:1">'+q.q+'</span><span style="color:#00a85a;font-size:11px;flex-shrink:0;margin-left:8px;">'+ans+'</span></div>';
  }).join('');
}

function discQuit(){
  clearInterval(discTimerInt);
  // Reset layout
  document.getElementById('disc-setup').style.display='block';
  document.getElementById('disc-game').style.display='none';
  document.getElementById('disc-results').style.display='none';
  goMenu();
}

// Route startGame to discussion setup



// =====================================================
// MODE BOSS
// =====================================================
function initBoss(pool){
  var easy=shuffle(pool.filter(function(q){return q.d===1;})).slice(0,3);
  var med=shuffle(pool.filter(function(q){return q.d===2;})).slice(0,4);
  var hard=shuffle(pool.filter(function(q){return q.d===3;})).slice(0,3);
  var result=easy.concat(med).concat(hard);
  if(result.length<5) result=shuffle(pool).slice(0,10);
  return result;
}
function updateBossBar(){
  var fill=document.getElementById('boss-fill');
  if(!fill) return;
  var pct=Math.round(((idx||0)/Math.max(session.length,1))*100);
  fill.style.width=pct+'%';
  var lbl=document.getElementById('boss-label');
  if(lbl) lbl.textContent='BOSS PHASE '+(Math.floor((idx||0)/3)+1)+'/4';
}
// =====================================================
// MUSIQUE LO-FI
// =====================================================
var lofiCtx=null,lofiNodes=[],lofiOn=false;
function toggleLofi(){
  lofiOn?stopLofi():startLofi();
  lofiOn=!lofiOn;
  ['lofi-btn','lofi-btn-menu'].forEach(function(id){
    var btn=document.getElementById(id);
    if(btn){btn.textContent=lofiOn?'🎵 ON':'🎵';btn.style.borderColor=lofiOn?'var(--acc)':'var(--border2)';btn.style.color=lofiOn?'var(--acc)':'var(--text2)';}
  });
}
function startLofi(){
  try{
    if(!lofiCtx)lofiCtx=new(window.AudioContext||window.webkitAudioContext)();
    var master=lofiCtx.createGain();master.gain.value=0.07;master.connect(lofiCtx.destination);
    var drone=lofiCtx.createOscillator();drone.type='sine';drone.frequency.value=55;
    var dg=lofiCtx.createGain();dg.gain.value=0.5;drone.connect(dg);dg.connect(master);drone.start();
    var chords=[[131,165,196],[110,138,165],[87,110,131],[98,123,147]];
    var ci=0;
    function chord(){
      chords[ci%4].forEach(function(f){
        var o=lofiCtx.createOscillator();o.type='triangle';o.frequency.value=f;
        var g=lofiCtx.createGain();
        g.gain.setValueAtTime(0,lofiCtx.currentTime);
        g.gain.linearRampToValueAtTime(0.12,lofiCtx.currentTime+0.4);
        g.gain.linearRampToValueAtTime(0,lofiCtx.currentTime+3.8);
        o.connect(g);g.connect(master);o.start();o.stop(lofiCtx.currentTime+4);
      });ci++;
    }
    chord();
    var lint=setInterval(chord,4000);
    lofiNodes=[drone,master,lint];
  }catch(e){}
}
function stopLofi(){
  try{if(lofiNodes[0])lofiNodes[0].stop();}catch(e){}
  if(lofiNodes[2])clearInterval(lofiNodes[2]);
  lofiNodes=[];
}

// =====================================================
// MÉCANIQUE MATCH (associer colonnes)
// =====================================================
var matchSelLeft=null, matchMatched=[];

function renderMatch(q,area){
  matchSelLeft=null; matchMatched=[];
  var pairs=q.pairs;
  var shuffledL=shuffle(pairs.map(function(p,i){return{text:p.l,idx:i};}));
  var shuffledR=shuffle(pairs.map(function(p,i){return{text:p.r,idx:i};}));

  var wrap=document.createElement('div'); wrap.className='match-wrap'; wrap.id='match-wrap';
  var colL=document.createElement('div'); colL.className='match-col';
  var colR=document.createElement('div'); colR.className='match-col';
  var lblL=document.createElement('div'); lblL.className='match-col-lbl'; lblL.textContent='TERME';
  var lblR=document.createElement('div'); lblR.className='match-col-lbl'; lblR.textContent='DÉFINITION';
  colL.appendChild(lblL); colR.appendChild(lblR);

  shuffledL.forEach(function(item){
    var d=document.createElement('div'); d.className='match-item';
    d.textContent=item.text; d.setAttribute('data-idx',''+item.idx); d.setAttribute('data-side','L');
    (function(el,i){el.onclick=function(){if(!answered)selectMatchItem(el,'L',i,pairs,wrap);};})(d,item.idx);
    colL.appendChild(d);
  });
  shuffledR.forEach(function(item){
    var d=document.createElement('div'); d.className='match-item';
    d.textContent=item.text; d.setAttribute('data-idx',''+item.idx); d.setAttribute('data-side','R');
    (function(el,i){el.onclick=function(){if(!answered)selectMatchItem(el,'R',i,pairs,wrap);};})(d,item.idx);
    colR.appendChild(d);
  });

  wrap.appendChild(colL); wrap.appendChild(colR);
  area.appendChild(wrap);
}

function selectMatchItem(el,side,itemIdx,pairs,wrap){
  // itemIdx renommé — évite conflit avec la variable globale idx (question courante)
  if(el.classList.contains('matched-ok')||el.classList.contains('matched-err')) return;
  if(side==='L'){
    wrap.querySelectorAll('.match-item[data-side="L"]').forEach(function(x){x.classList.remove('selected');});
    el.classList.add('selected');
    matchSelLeft=itemIdx;
  } else if(side==='R'&&matchSelLeft!==null){
    var ok=(matchSelLeft===itemIdx);
    var leftEl=wrap.querySelector('.match-item[data-side="L"][data-idx="'+matchSelLeft+'"]');
    if(leftEl){leftEl.classList.remove('selected');leftEl.classList.add(ok?'matched-ok':'matched-err');}
    el.classList.add(ok?'matched-ok':'matched-err');
    if(!ok){
      var correctR=wrap.querySelector('.match-item[data-side="R"][data-idx="'+matchSelLeft+'"]');
      if(correctR&&!correctR.classList.contains('matched-ok'))correctR.classList.add('matched-ok');
    }
    matchMatched.push({l:matchSelLeft,r:itemIdx,ok:ok});
    matchSelLeft=null;
    var done=wrap.querySelectorAll('.matched-ok,.matched-err').length;
    if(done>=pairs.length*2){
      var allOk=matchMatched.every(function(m){return m.ok;});
      var curQ=session[idx]; // idx global = question courante
      if(!allOk)errors.push({q:curQ?curQ.q:'match',yours:'Associations incorrectes',correct:pairs.map(function(p){return p.l+' → '+p.r;}).join(' | '),x:curQ?curQ.x||'':'',orig:curQ,mech:'match'});
      resolveCommon(allOk,curQ||{q:'',x:'',t:'match'});
    }
  }
}

// =====================================================
// MODE INVERSÉ
// =====================================================
function renderInverse(q,area){
  var ans='';
  if(q.t==='qcm'||q.t==='debug') ans=q.opts[q.a];
  else if(q.t==='tf') ans=q.a===true?'VRAI':'FAUX';
  else if(q.t==='fill') ans=q.opts[q.a];
  else ans=String(q.a);
  var box=document.createElement('div'); box.className='inv-answer-box';
  box.innerHTML='<span class="inv-answer-label">A QUELLE QUESTION CORRESPOND CETTE REPONSE ?</span><div class="inv-answer-val">'+ans+'</div>';
  area.appendChild(box);
  var realQ=q.q;
  var pool=session.filter(function(x){return x.q!==realQ;});
  var fakes=shuffle(pool).slice(0,3).map(function(x){return x.q;});
  while(fakes.length<3) fakes.push('Aucune de ces propositions');
  var allOpts=shuffle([realQ].concat(fakes));
  var wrap=document.createElement('div'); wrap.className='opts';
  ['A','B','C','D'].forEach(function(k,ii){
    if(ii>=allOpts.length) return;
    var b=document.createElement('button'); b.className='opt';
    b.innerHTML='<span class="okey">'+k+'</span><span>'+allOpts[ii]+'</span>';
    (function(btn,optText,isOk){
      btn.onclick=function(){
        if(answered) return;
        clearInterval(timerInt); answered=true;
        wrap.querySelectorAll('.opt').forEach(function(x){x.disabled=true;});
        wrap.querySelectorAll('.opt').forEach(function(x){
          var sp=x.querySelectorAll('span')[1];
          if(sp&&sp.textContent===realQ) x.classList.add('ok');
        });
        btn.classList.add(isOk?'ok':'err');
        if(!isOk) errors.push({q:'[INVERSE] '+ans,yours:optText,correct:realQ,x:q.x,orig:q,mech:'inverse'});
        resolveCommon(isOk,q);
      };
    })(b,allOpts[ii],allOpts[ii]===realQ);
    wrap.appendChild(b);
  });
  area.appendChild(wrap);
}

// =====================================================
// MODE SPEEDRUN
// =====================================================
var srStartTime=0, srElapsed=0, srInt2=null;
function initSpeedrun(){
  srStartTime=Date.now(); srElapsed=0;
  clearInterval(srInt2);
  var hud=document.getElementById('speedrun-hud');
  if(hud) hud.style.display='flex';
  srInt2=setInterval(function(){
    srElapsed=(Date.now()-srStartTime)/1000;
    var te=document.getElementById('sr-time');
    if(te) te.textContent=srElapsed.toFixed(1)+'s';
  },100);
}
function stopSpeedrun(){
  clearInterval(srInt2);
  var best=lsGet('tssr5_sr_best',{});
  var key=selCat||'mix';
  var prev=best[key]||9999;
  if(correct>=session.length&&srElapsed<prev){
    best[key]=Math.round(srElapsed*10)/10;
    lsSet('tssr5_sr_best',best);
    return true;
  }
  return false;
}

// =====================================================
// MODULE : SYSTÈME DE SEED (rejouabilité)
// =====================================================
var currentSeed='';

function seededRNG(seed){
  // Simple LCG seeded random — même seed = même séquence
  var s=0;
  for(var i=0;i<seed.length;i++) s=(s*31+seed.charCodeAt(i))&0x7fffffff;
  return function(){s=(s*1103515245+12345)&0x7fffffff;return s/0x7fffffff;};
}

function seededShuffle(arr,rng){
  var b=arr.slice();
  for(var i=b.length-1;i>0;i--){var j=Math.floor(rng()*(i+1));var t=b[i];b[i]=b[j];b[j]=t;}
  return b;
}

function genSeed(){
  var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var s='';for(var i=0;i<6;i++) s+=chars[Math.floor(Math.random()*chars.length)];
  var inp=document.getElementById('seed-input');
  if(inp) inp.value=s;
  currentSeed=s;
}

function copySeed(){
  var inp=document.getElementById('seed-input');
  if(!inp) return;
  currentSeed=inp.value.trim().toUpperCase();
  if(!currentSeed){genSeed();currentSeed=document.getElementById('seed-input').value;}
  navigator.clipboard&&navigator.clipboard.writeText(currentSeed);
  inp.style.borderColor='#00a85a';
  setTimeout(function(){if(inp)inp.style.borderColor='';},1200);
}

function applyCurrentSeed(){
  var inp=document.getElementById('seed-input');
  if(inp) currentSeed=inp.value.trim().toUpperCase();
}

// =====================================================
// MODULE : FEEDBACK TEMPS DE RÉPONSE
// =====================================================
var qStartTime=0, qTimes=[], betActive=false, rpgPoints=0;

function startQTimer(){qStartTime=Date.now();}

function getQTime(){
  if(!qStartTime) return 0;
  var t=Math.round((Date.now()-qStartTime)/10)/100;
  qTimes.push(t);
  qStartTime=0; // reset pour éviter double-comptage
  return t;
}

function getTimeBadge(t){
  if(t<5) return '<span class="time-badge time-fast">⚡ '+t.toFixed(1)+'s RAPIDE</span>';
  if(t<12) return '<span class="time-badge time-ok">⏱ '+t.toFixed(1)+'s OK</span>';
  return '<span class="time-badge time-slow">🐢 '+t.toFixed(1)+'s LENT</span>';
}

function showTimeSummary(){
  var ts=document.getElementById('time-summary');
  if(!ts) return;
  if(!qTimes||!qTimes.length){ts.style.display='none';return;}
  var avg=qTimes.reduce(function(a,b){return a+b;},0)/qTimes.length;
  var best=Math.min.apply(null,qTimes);
  var pct=session.length>0?Math.round(correct/session.length*100):0;
  ts.style.display='flex';
  var tsAvg=document.getElementById('ts-avg');if(tsAvg)tsAvg.textContent=avg.toFixed(1)+'s';
  var tsBest=document.getElementById('ts-best');if(tsBest)tsBest.textContent=best.toFixed(1)+'s';
  var tsAcc=document.getElementById('ts-acc');if(tsAcc)tsAcc.textContent=pct+'%';
}

// =====================================================
// MODULE : ANIMATIONS BONNE/MAUVAISE RÉPONSE
// =====================================================
function animCorrect(){
  var card=document.getElementById('qcard');
  if(!card) return;
  card.classList.remove('anim-wrong');
  void card.offsetWidth;
  card.classList.add('anim-correct');
  setTimeout(function(){card&&card.classList.remove('anim-correct');},500);
}
function animWrong(){
  var card=document.getElementById('qcard');
  if(!card) return;
  card.classList.remove('anim-correct');
  void card.offsetWidth;
  card.classList.add('anim-wrong');
  setTimeout(function(){card&&card.classList.remove('anim-wrong');},400);
}

// =====================================================
// MODULE : SYSTÈME DE PARI
// =====================================================
var BET_CHANCE=0.25; // 25% de chance de pari proposé
var betOn=false;

function maybeShowBet(){
  betOn=false;
  var bar=document.getElementById('bet-bar');
  if(!bar) return;
  if(selMode==='chill'||selMode==='speed'||selMode==='survie'){
    if(Math.random()<BET_CHANCE&&idx>0){
      bar.style.display='flex';
    } else {
      bar.style.display='none';
    }
  } else {
    bar.style.display='none';
  }
}

function activateBet(){
  betOn=true;
  var bar=document.getElementById('bet-bar');
  if(bar){
    bar.innerHTML='<span class="bet-active">💰 PARI ACTIF — x2 si bon, -1 vie si faux</span>';
  }
}

function resolveBet(ok){
  if(!betOn) return;
  betOn=false;
  var bar=document.getElementById('bet-bar');
  if(ok){
    correct++; // bonus point
    showRPGPoints('+2x',ok);
  } else {
    if(lives!==99) lives--;
    updLives();
  }
  if(bar) bar.style.display='none';
}

// =====================================================
// MODULE : ÉVÉNEMENTS ALÉATOIRES
// =====================================================
var EVENT_CHANCE=0.12; // 12% par question
var activeEvent=null;
var eventTimerMult=1;

var EVENTS=[
  {id:'panne',cls:'panne',icon:'📡',text:'PANNE RÉSEAU — Timer x2 !',effect:function(){eventTimerMult=2;},clear:function(){eventTimerMult=1;}},
  {id:'maintenance',cls:'maintenance',icon:'🔧',text:'MAINTENANCE — Question gratuite !',effect:function(){if(!answered){answered=true;var qm=session[idx];if(qm)resolveCommon(true,qm);}},clear:function(){}},
  {id:'bonus',cls:'maintenance',icon:'⭐',text:'BOOST — Combo x3 !',effect:function(){combo=Math.max(combo,3);},clear:function(){}},
  {id:'joker_event',cls:'maintenance',icon:'💡',text:'CHANCE — Joker offert !',effect:function(){jokers=Math.min(jokers+1,5);var jc=document.getElementById('jcount');if(jc)jc.textContent=jokers;},clear:function(){}},
];

function maybeFireEvent(){
  if(Math.random()>EVENT_CHANCE) return;
  if(activeEvent) return;
  var e=EVENTS[Math.floor(Math.random()*EVENTS.length)];
  activeEvent=e;
  var banner=document.getElementById('event-banner');
  if(!banner) return;
  banner.className='event-banner show '+e.cls;
  document.getElementById('event-icon').textContent=e.icon;
  document.getElementById('event-text').textContent=e.text;
  if(e.effect) e.effect();
  if(e.id!=='latence'&&e.id!=='maintenance'){
    setTimeout(dismissEvent,3500);
  }
}

function dismissEvent(){
  if(activeEvent&&activeEvent.clear) activeEvent.clear();
  activeEvent=null; eventTimerMult=1;
  var banner=document.getElementById('event-banner');
  if(banner) banner.classList.remove('show');
}

// =====================================================
// MODULE : MODE CHAOS
// =====================================================
var CHAOS_CHANCE=0.07; // 7% par question
var chaosActive=false, chaosInt=null;

function maybeChaos(){
  if(chaosActive||Math.random()>CHAOS_CHANCE) return;
  chaosActive=true;
  document.body.classList.add('chaos-mode');
  var badge=document.getElementById('chaos-badge');
  if(badge) badge.style.display='block';
  // Timer instable
  var origTimer=timeLeft;
  chaosInt=setInterval(function(){
    if(!chaosActive) return;
    timeLeft+=Math.random()<0.4?-2:1;
    timeLeft=Math.max(1,Math.min(timeLeft,30));
  },300);
  // Points bonus x2 pendant chaos
  combo=Math.max(combo,2);
  // Fin chaos après 8s ou question suivante
  setTimeout(endChaos,8000);
}

function endChaos(){
  if(!chaosActive) return;
  chaosActive=false;
  clearInterval(chaosInt);
  document.body.classList.remove('chaos-mode');
  var badge=document.getElementById('chaos-badge');
  if(badge) badge.style.display='none';
}

// =====================================================
// MODULE : MODE RPG (tickets incidents)
// =====================================================
var rpgQ=null; // question courante RPG

var RPG_TICKETS=[
  {id:'easy',cls:'easy',diff:1,label:'FACILE ★',reward:10,risk:'Pas de pénalité',mechFilter:['qcm','tf']},
  {id:'medium',cls:'medium',diff:2,label:'MOYEN ★★',reward:25,risk:'-1 vie si faux',mechFilter:['qcm','fill','debug']},
  {id:'hard',cls:'hard',diff:3,label:'DIFFICILE ★★★',reward:50,risk:'-2 vies si faux',mechFilter:['qcm','debug','calc','word']},
];

function startChaosMode(){
  // Construire le pool normal puis lancer le mode chaos
  var pool=CATS[selCat]?CATS[selCat].qs:CATS['mix'].qs;
  if(selDiff!=='all') pool=pool.filter(function(q){return q.d===parseInt(selDiff);});
  if(!pool.length) pool=CATS[selCat]?CATS[selCat].qs:CATS['mix'].qs;
  var count=Math.min(selQCount===9999?15:selQCount,pool.length);
  session=freshShuffle(pool).slice(0,count);
  markShown(session);
  correct=0;combo=1;maxCombo=1;errors=[];idx=0;paused=false;
  bonusStreak=0;qTimes=[];rpgPoints=0;betOn=false;
  lives=MODES['chaos'].lives;
  jokers=3;
  sStats={cat:selCat,mode:'chaos',maxCombo:0,mechs:new Set(),streak:streakD.current};
  applyBody();
  updateStreak();
  el('gbadge').textContent='🌀 CHAOS · '+( CATS[selCat]?CATS[selCat].label:'MIX');
  var sh=el('score-hud');if(sh)sh.style.display='grid';
  el('htotal').textContent=session.length;
  buildDots();
  showScreen('game');
  startChaos();
  // Premier événement
  triggerChaosEvent();
}

function startRPG(){
  rpgPoints=0; lives=5; qTimes=[]; rpgQ=null;
  var pool=CATS[selCat]&&selCat!=='_multi'?CATS[selCat].qs:session.length?session:CATS['mix'].qs;
  if(selCat==='_multi'&&session.length) pool=session;
  else{
    if(selDiff!=='all') pool=pool.filter(function(q){return q.d===parseInt(selDiff);});
    if(!pool.length) pool=CATS[selCat].qs||[];
  }
  session=freshShuffle(pool).slice(0,Math.min(selQCount===9999?30:selQCount,pool.length));
  markShown(session);
  idx=0;correct=0;combo=1;errors=[];
  applyBody();
  el('gbadge').textContent='🎭 RPG · '+CATS[selCat].label.toUpperCase();
  var sh=el('score-hud');if(sh)sh.style.display='grid';
  el('htotal').textContent=session.length;
  updateStreak();
  buildDots();
  showScreen('game');
  showRPGTickets();
}

function showRPGTickets(){
  if(idx>=session.length){showResults();return;}
  var ovl=document.getElementById('rpg-overlay');
  var container=document.getElementById('rpg-tickets');
  var scoreEl=document.getElementById('rpg-score');
  if(!ovl||!container) return;
  if(scoreEl) scoreEl.textContent=rpgPoints;

  container.innerHTML='';

  var TDEFS=[
    {id:'easy',cls:'easy',diff:1,label:'P1 — FACILE',reward:10,risk:'Aucun risque',mechFilter:['qcm','tf','fill']},
    {id:'medium',cls:'medium',diff:2,label:'P2 — MOYEN',reward:25,risk:'-1 vie si faux',mechFilter:['qcm','debug','fill','calc']},
    {id:'hard',cls:'hard',diff:3,label:'P3 — DIFFICILE',reward:50,risk:'-2 vies si faux',mechFilter:['qcm','debug']},
  ];

  var remaining=session.slice(idx);

  TDEFS.forEach(function(t){
    // Chercher une question compatible — d'abord par difficulté+type, sinon par difficulté seule
    var pool=remaining.filter(function(q){return q.d===t.diff&&t.mechFilter.indexOf(q.t)>-1&&q.opts;});
    if(!pool.length) pool=remaining.filter(function(q){return q.d===t.diff&&q.opts;});
    if(!pool.length) pool=remaining.filter(function(q){return q.opts;}); // fallback any
    if(!pool.length) return; // skip if no compatible question at all
    var q=pool[Math.floor(Math.random()*pool.length)];

    var cat=q._cat||(CATS[selCat]?CATS[selCat].label:'Quiz');
    var catIcon=Object.values(CATS).find(function(c){return c.label===cat;});
    var icon=catIcon?catIcon.icon:'📋';
    var mechLabels={qcm:'QCM',tf:'Vrai/Faux',fill:'Compléter',debug:'Débug',calc:'Calcul',word:'Sélection',order:'Ordre',match:'Associer'};

    var card=document.createElement('div');
    card.className='rpg-ticket '+t.cls;
    card.innerHTML=
      '<div class="rpg-ticket-header">'+
        '<span class="rpg-ticket-priority">'+t.label+'</span>'+
        '<span class="rpg-ticket-reward-badge">+'+t.reward+' pts</span>'+
      '</div>'+
      '<div class="rpg-ticket-body">'+
        '<span class="rpg-ticket-title">'+icon+' '+cat+'</span>'+
        '<div class="rpg-ticket-meta">'+
          '<span class="rpg-ticket-tag">'+mechLabels[q.t]+'</span>'+
          '<span class="rpg-ticket-tag">'+DS[q.d]||'★'+'</span>'+
          '<span class="rpg-ticket-risk">⚠ '+t.risk+'</span>'+
        '</div>'+
      '</div>';

    (function(ticket,question){
      card.onclick=function(){
        rpgQ={ticket:ticket,q:question};
        // Ramener la question à la position courante
        var qi=session.indexOf(question);
        if(qi>idx){var tmp=session[idx];session[idx]=question;session[qi]=tmp;}
        ovl.classList.remove('show');
        showQ();
      };
    })(t,q);

    container.appendChild(card);
  });

  ovl.classList.add('show');
}

function resolveRPG(ok){
  if(!rpgQ) return;
  var t=rpgQ.ticket;
  if(ok){
    rpgPoints+=t.reward;
    showRPGPoints('+'+t.reward+' pts', true);
  } else {
    var penalty=t.diff===3?2:1;
    if(lives!==99) lives=Math.max(0,lives-penalty);
    updLives();
    showRPGPoints('-'+penalty+' ❤', false);
  }
  rpgQ=null;
}

function showRPGPoints(text,ok){
  var el2=document.createElement('div');
  el2.className='rpg-pts-popup';
  el2.textContent=text;
  el2.style.cssText='position:fixed;top:40%;left:50%;transform:translateX(-50%);color:'+(ok?'#00a85a':'#dc2626')+';text-shadow:0 0 10px '+(ok?'rgba(0,168,90,.5)':'rgba(220,38,38,.5)')+';';
  document.body.appendChild(el2);
  setTimeout(function(){el2.remove();},1300);
}

// =====================================================
// DIFFICULTÉ DYNAMIQUE
// =====================================================
var dynDiffStreak=0, dynDiffLevel=0;

function updateDynDiff(ok){
  if(selMode!=='chill'&&selMode!=='speed'&&selMode!=='survie') return;
  if(ok){
    dynDiffStreak++;
    if(dynDiffStreak===3&&dynDiffLevel<2){
      dynDiffLevel++;
      dynDiffStreak=0;
      showDynToast('↑ NIVEAU SUPÉRIEUR !','up');
    }
  } else {
    dynDiffStreak=0;
    if(dynDiffLevel>0){dynDiffLevel--;showDynToast('↓ Retour au niveau','down');}
  }
}

function showDynToast(msg,type){
  var t=document.createElement('div');
  t.className='dyn-diff-toast dyn-'+type;
  t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(function(){if(t.parentNode)t.remove();},1400);
}

// =====================================================
// UI SWITCHER
// =====================================================
var currentUI = 'ui-arcade';

function switchUI(ui){
  playThemeChange();
  currentUI = ui;
  lsSet('tssr5_ui', ui);
  applyUI();
}

function applyUI(){
  // Remove all ui classes, keep others
  document.body.classList.remove('ui-arcade','ui-paper','ui-terminal','ui-minimal');
  document.body.classList.add(currentUI||'ui-arcade');

  // Sync switcher buttons
  document.querySelectorAll('.ui-sw-btn').forEach(function(b){
    b.classList.toggle('sel', b.getAttribute('data-ui')===(currentUI||'ui-arcade'));
  });

  // Logo adaptatif
  var logo=document.getElementById('logo');
  if(logo){
    if(currentUI==='ui-terminal') logo.textContent='> TSSR_QUIZ.exe';
    else if(currentUI==='ui-paper'){
      var num=lsGet('tssr5_dossier',Math.floor(Math.random()*9000+1000));
      lsSet('tssr5_dossier',num);
      logo.textContent='DOSSIER N° '+num;
    }
    else if(currentUI==='ui-minimal') logo.textContent='TSSR Quiz';
    else logo.textContent='📚 TSSR QUIZ';
  }

  // Sub-title adaptatif
  var sub=document.getElementById('header-sub');
  if(sub){
    if(currentUI==='ui-terminal') sub.textContent='[SYSTÈME PRÊT] 282 questions chargées';
    else if(currentUI==='ui-paper') sub.textContent='FORMULAIRE DE RÉVISION — CONFIDENTIEL';
    else if(currentUI==='ui-minimal') sub.textContent='282 questions · 15 catégories';
    else sub.textContent='Basé sur ton Notion · 282 questions';
  }
}

// =====================================================
// MODE CHAOS DÉDIÉ
// =====================================================
var CHAOS_EVENTS=[
  {icon:'🌀',title:'TIMER RÉDUIT !',desc:'Tu as 8 secondes par question.',effect:function(){window._chaosTimerOverride=8;}},
  {icon:'🔀',title:'OPTIONS MÉLANGÉES !',desc:'Les choix changent de position.',effect:function(){window._chaosShuffleExtra=true;}},
  {icon:'⚡',title:'DOUBLE OU RIEN !',desc:'Bonne réponse = +2 points. Fausse = -1 vie.',effect:function(){window._chaosDouble=true;}},
  {icon:'🌑',title:'QUESTION CACHÉE !',desc:'La question apparaît en 3... 2... 1...',effect:function(){window._chaosBlind=true;}},
  {icon:'💥',title:'DERNIÈRE CHANCE !',desc:'1 vie restante. Bonne chance.',effect:function(){if(lives>1)lives=1;updLives();}},
  {icon:'🎁',title:'BONUS !',desc:'Question gratuite offerte !',effect:function(){window._chaosFree=true;}},
];

var chaosEventActive=false, chaosEventData=null;

function startChaos(){
  // Reset chaos flags
  window._chaosTimerOverride=null;
  window._chaosShuffleExtra=false;
  window._chaosDouble=false;
  window._chaosBlind=false;
  window._chaosFree=false;

  document.body.classList.add('chaos-active');
  var badge=document.getElementById('chaos-badge');
  if(badge) badge.style.display='block';

  // Show random chaos event before each question
  triggerChaosEvent();
}

function triggerChaosEvent(){
  // 60% chance dun événement
  if(Math.random()>0.6){showQ();return;}
  var ev=CHAOS_EVENTS[Math.floor(Math.random()*CHAOS_EVENTS.length)];
  chaosEventData=ev;
  var ovl=document.getElementById('chaos-event-overlay');
  if(!ovl){showQ();return;}
  document.getElementById('chaos-event-title').textContent=ev.icon+' '+ev.title;
  document.getElementById('chaos-event-desc').textContent=ev.desc;
  document.getElementById('chaos-countdown').textContent=ev.icon;
  // Reset previous flags
  window._chaosTimerOverride=null;window._chaosShuffleExtra=false;
  window._chaosDouble=false;window._chaosBlind=false;window._chaosFree=false;
  if(ev.effect) ev.effect();
  ovl.classList.add('show');
}

function dismissChaosEvent(){
  var ovl=document.getElementById('chaos-event-overlay');
  if(ovl) ovl.classList.remove('show');
  chaosEventData=null;
  // If free question, skip
  if(window._chaosFree){
    window._chaosFree=false;
    var q=session[idx];
    if(q) resolveCommon(true,q);
    return;
  }
  showQ();
}

function stopChaosMode(){
  document.body.classList.remove('chaos-active');
  var badge=document.getElementById('chaos-badge');
  if(badge) badge.style.display='none';
  window._chaosTimerOverride=null;window._chaosShuffleExtra=false;
  window._chaosDouble=false;window._chaosBlind=false;window._chaosFree=false;
}

// Override maybeChaos pour ne plus déclencher en dehors du mode chaos
function maybeChaos(){
  // Ne rien faire — chaos est maintenant un mode dédié
}
// Override maybeFireEvent pour ne plus déclencher en dehors du mode chaos
function maybeFireEvent(){
  // Événements désactivés hors mode chaos
}
// =====================================================
// MODE RPG NARRATIF — Système de tickets incidents
// =====================================================
// Architecture :
// - 8 scénarios indépendants
// - Barre de confiance (0-100, démarre à 50)
// - Chaque scénario a : situation, 4-5 actions, questions liées
// - Actions types : BONNE_PISTE, NEUTRE, MAUVAISE_PISTE
// - Fin : confiance à 100 = promu, à 0 = viré

var RPG = {

  // ---- ÉTAT ----
  state: {
    confidence: 50,       // 0-100
    ticketIdx: 0,         // scénario actif
    ticketsDone: [],      // historique
    currentActions: [],   // actions disponibles (avec état grisé)
    phase: 'actions',     // 'actions' | 'consequence' | 'question' | 'resolution'
    pendingAction: null,  // action choisie en attente de question
    ticketsPerSession: 5, // nombre de tickets par session
  },

  // ---- CONSTANTES ----
  CONF_GOOD_ACTION: 15,   // bonne piste + bonne réponse
  CONF_BAD_ANSWER: -20,   // bonne piste + mauvaise réponse
  CONF_BAD_PISTE: -10,    // mauvaise piste (avec validation)
  CONF_NEUTRAL: 0,        // action neutre

  // ---- LES 8 SCÉNARIOS ----
  scenarios: [

    // ======= 1. RSAT / WinRM =======
    {
      id: 'winrm',
      categorie: 'windows',
      title: 'TICKET #4471 — Niveau P2',
      situation: "Il est 14h32. Tu reçois un ticket urgent : un collègue ne peut pas gérer le serveur SRV-PROD depuis son poste avec RSAT. L'erreur affichée : \"Accès refusé — WinRM ne répond pas\". Le chef attend une résolution avant 17h.",
      actions: [
        {
          id: 'check_winrm',
          label: 'Vérifier si WinRM est actif sur SRV-PROD',
          type: 'BONNE_PISTE',
          consequence: "Tu ouvres une session directe sur SRV-PROD. Le service WinRM est bien démarré... mais le pare-feu bloque les connexions entrantes sur le port 5985.",
          question_id: 'winrm_port',
        },
        {
          id: 'check_trusted',
          label: 'Vérifier les TrustedHosts côté client',
          type: 'BONNE_PISTE',
          consequence: "Bonne idée. En workgroup, le client doit déclarer SRV-PROD dans ses hôtes de confiance. Tu ouvres PowerShell en admin.",
          question_id: 'winrm_trustedhosts',
        },
        {
          id: 'restart_server',
          label: 'Redémarrer le serveur pour voir',
          type: 'MAUVAISE_PISTE',
          consequence: "ERREUR. SRV-PROD est un serveur de production. Ton chef reçoit une alerte — 15 utilisateurs perdent leur connexion. La confiance baisse.",
          malus: true,
        },
        {
          id: 'check_creds',
          label: 'Vérifier les identifiants utilisés',
          type: 'NEUTRE',
          consequence: "Les identifiants sont corrects — cest bien un compte admin local. Ce n'est pas la cause du problème. Piste à écarter.",
        },
        {
          id: 'enable_psremoting',
          label: 'Lancer Enable-PSRemoting sur SRV-PROD',
          type: 'BONNE_PISTE',
          consequence: "Tu te connectes directement à SRV-PROD et tu lances la commande. Elle configure WinRM, crée les listeners et les règles de pare-feu en une seule fois.",
          question_id: 'winrm_enable',
        },
      ],
      resolution_ok: "WinRM opérationnel. Le collègue se reconnecte depuis RSAT. Ton chef : \"Bien joué, t'as géré ça vite.\"",
      resolution_fail: "Le problème WinRM dure depuis 2h. Ton chef perd patience : \"T'as essayé n'importe quoi, le serveur a même redémarré...\"",
    },

    // ======= 2. DNS ne résout plus =======
    {
      id: 'dns',
      categorie: 'dns',
      title: 'TICKET #3892 — Niveau P1',
      situation: "Alerte critique : depuis 20 minutes, aucun poste du site B ne peut accéder aux partages réseau ni à Internet. Les utilisateurs voient \"Serveur DNS introuvable\". Le DSI appelle directement.",
      actions: [
        {
          id: 'flush_dns',
          label: 'Vider le cache DNS sur les postes',
          type: 'NEUTRE',
          consequence: "Tu lances ipconfig /flushdns sur plusieurs postes. Le cache se vide, mais le problème persiste — ce n'est pas un problème de cache local.",
        },
        {
          id: 'check_service',
          label: 'Vérifier si le service DNS est démarré sur le serveur',
          type: 'BONNE_PISTE',
          consequence: "Bingo. Le service DNS sest arrêté suite à une mise à jour automatique de la nuit. Il est en état 'Stopped'.",
          question_id: 'dns_service_restart',
        },
        {
          id: 'check_zone',
          label: 'Vérifier l\'intégrité des zones DNS',
          type: 'BONNE_PISTE',
          consequence: "Tu ouvres le gestionnaire DNS. La zone primaire est là, mais un enregistrement SOA est corrompu depuis la dernière modification manuelle.",
          question_id: 'dns_soa',
        },
        {
          id: 'check_hosts',
          label: 'Regarder le fichier Hosts des postes',
          type: 'NEUTRE',
          consequence: "Les fichiers Hosts sont propres. Aucune entrée suspecte. Piste écartée — ce n'est pas la cause.",
        },
        {
          id: 'change_dns',
          label: 'Changer les DNS des postes vers 8.8.8.8',
          type: 'MAUVAISE_PISTE',
          consequence: "Mauvaise idée. Internet revient sur quelques postes mais les ressources internes (partages, AD) restent inaccessibles. Et ton chef demande pourquoi tu as touché aux DNS internes.",
          malus: true,
        },
      ],
      resolution_ok: "Service DNS redémarré, zones intactes. Les partages remontent en 2 minutes. Le DSI : \"Bien réagi, impact limité.\"",
      resolution_fail: "30 minutes de coupure. Le DSI exige un rapport d'incident. Ton chef note que tu as modifié la config DNS sans validation.",
    },

    // ======= 3. VLAN ne communique plus =======
    {
      id: 'vlan',
      categorie: 'vlan',
      title: 'TICKET #5103 — Niveau P2',
      situation: "Le département RH (VLAN 20) ne peut plus accéder au serveur de fichiers sur le VLAN 10. Les autres VLANs fonctionnent. Un responsable RH te relance toutes les 10 minutes.",
      actions: [
        {
          id: 'check_svi',
          label: 'Vérifier la SVI du VLAN 20 sur le switch L3',
          type: 'BONNE_PISTE',
          consequence: "Sur le switch L3, l'interface Vlan20 existe mais elle est en 'down/down'. Elle a probablement été désactivée manuellement.",
          question_id: 'vlan_svi',
        },
        {
          id: 'check_routing',
          label: 'Vérifier si ip routing est activé',
          type: 'BONNE_PISTE',
          consequence: "Tu tapes 'show run | include ip routing'. Rien ne s'affiche — la commande ip routing a été retirée après une maintenance la semaine dernière.",
          question_id: 'vlan_ip_routing',
        },
        {
          id: 'check_trunk',
          label: 'Vérifier la configuration du port trunk',
          type: 'BONNE_PISTE',
          consequence: "Le port trunk entre l'access switch et le L3 nautorise plus le VLAN 20. Il a été retiré de la liste lors dune 'simplification' récente.",
          question_id: 'vlan_trunk',
        },
        {
          id: 'restart_switch',
          label: 'Redémarrer le switch du département RH',
          type: 'MAUVAISE_PISTE',
          consequence: "Tous les postes RH perdent leur connexion réseau pendant 3 minutes. Le problème n'est pas résolu. Le responsable RH appelle ton chef.",
          malus: true,
        },
        {
          id: 'check_acl',
          label: 'Vérifier les ACL sur le switch',
          type: 'NEUTRE',
          consequence: "Aucune ACL suspecte détectée sur les interfaces concernées. Ce n'est pas la cause — piste à écarter.",
        },
      ],
      resolution_ok: "VLAN 20 de nouveau accessible. Les RH reprennent leur travail. Ton chef : \"Bon diagnostic, t'as trouvé la cause racine.\"",
      resolution_fail: "Le VLAN 20 reste coupé 1h. Le service RH ne peut pas travailler. Rapport d'incident demandé.",
    },

    // ======= 4. VM Hyper-V ne démarre pas =======
    {
      id: 'hyperv',
      categorie: 'hyperv',
      title: 'TICKET #2267 — Niveau P2',
      situation: "Un développeur signale que sa VM de test ne démarre plus depuis ce matin. Message d'erreur : \"Impossible de démarrer la machine virtuelle — disque non trouvé\". Il a besoin de cette VM pour une démo dans 2h.",
      actions: [
        {
          id: 'check_disk',
          label: 'Vérifier si le fichier VHDX est présent',
          type: 'BONNE_PISTE',
          consequence: "Tu navigues dans le dossier de la VM. Le fichier .vhdx principal est là... mais un disque différentiel (.avhdx) dun snapshot pointe vers un chemin qui n'existe plus.",
          question_id: 'hyperv_snapshot',
        },
        {
          id: 'check_config',
          label: 'Vérifier la configuration de la VM',
          type: 'BONNE_PISTE',
          consequence: "Dans le Gestionnaire Hyper-V, tu vois que le chemin du disque dur a été modifié après une migration — il pointe vers D:\\ alors que le VHDX est sur E:\\.",
          question_id: 'hyperv_disk_path',
        },
        {
          id: 'recreate_vm',
          label: 'Recréer la VM depuis zéro',
          type: 'MAUVAISE_PISTE',
          consequence: "Le développeur est horrifié — il avait 3 mois de travail dans cette VM. Tu réalises que tu aurais dû diagnostiquer avant d'agir.",
          malus: true,
        },
        {
          id: 'check_switch',
          label: 'Vérifier le commutateur réseau de la VM',
          type: 'NEUTRE',
          consequence: "Le commutateur virtuel est bien configuré. Le problème de démarrage n'est pas lié au réseau — piste à écarter.",
        },
        {
          id: 'export_import',
          label: 'Exporter puis réimporter la VM',
          type: 'NEUTRE',
          consequence: "L'export nécessite que la VM soit accessible. Comme elle ne démarre pas, cette action est impossible dans l'état actuel.",
        },
      ],
      resolution_ok: "VM démarrée en 15 minutes. Le développeur a sa démo. Ton chef : \"Bonne réactivité, la démo a pu avoir lieu.\"",
      resolution_fail: "La VM reste inaccessible. La démo est annulée. Le développeur porte plainte auprès de ton chef.",
    },

    // ======= 5. Partage réseau inaccessible =======
    {
      id: 'ntfs',
      categorie: 'ntfs',
      title: 'TICKET #6814 — Niveau P1',
      situation: "Urgence RH : la responsable RH ne peut plus accéder au dossier \\\\SRV-FILE\\Confidentiel-RH depuis ce matin. Elle voit \"Accès refusé\". D'autres membres RH y accèdent normalement.",
      actions: [
        {
          id: 'check_ntfs',
          label: 'Vérifier les permissions NTFS du dossier',
          type: 'BONNE_PISTE',
          consequence: "Sur SRV-FILE, tu ouvres les propriétés du dossier. La responsable RH a un Deny explicite sur sa fiche, ajouté hier par erreur lors dune réorganisation.",
          question_id: 'ntfs_deny',
        },
        {
          id: 'check_share',
          label: 'Vérifier les permissions de partage SMB',
          type: 'NEUTRE',
          consequence: "Les permissions de partage accordent un accès Everyone en lecture/écriture. Ce n'est pas le problème ici — les NTFS prennent le dessus.",
        },
        {
          id: 'check_group',
          label: 'Vérifier si elle est bien dans le groupe GRP-RH',
          type: 'BONNE_PISTE',
          consequence: "Elle est bien dans GRP-RH. Mais tu remarques qu'elle a aussi été ajoutée à un groupe GRP-STAGIAIRES par erreur lors dune réorg AD — et ce groupe a un Deny sur ce dossier.",
          question_id: 'ntfs_group_deny',
        },
        {
          id: 'reset_password',
          label: 'Réinitialiser son mot de passe',
          type: 'MAUVAISE_PISTE',
          consequence: "Son mot de passe fonctionne — elle accède à d'autres ressources normalement. La réinitialisation na rien changé et elle doit reconfigurer ses applications.",
          malus: true,
        },
        {
          id: 'check_inheritance',
          label: 'Vérifier l\'héritage des permissions',
          type: 'BONNE_PISTE',
          consequence: "L'héritage est coupé sur ce dossier et les ACL ont été reconstituées manuellement. Une entrée Deny a été ajoutée pour son compte spécifiquement.",
          question_id: 'ntfs_deny',
        },
      ],
      resolution_ok: "Accès rétabli en 10 minutes. La responsable RH peut travailler. Ton chef : \"Bien géré, la cause était subtile.\"",
      resolution_fail: "La responsable RH na pas accès de la journée. Elle escalade au DRH. Ton chef reçoit un mail peu agréable.",
    },

    // ======= 6. STP — Boucle réseau =======
    {
      id: 'stp',
      categorie: 'stp',
      title: 'TICKET #1190 — Niveau P3',
      situation: "ALERTE CRITIQUE : Le réseau du bâtiment B est en tempête de broadcast. Les switches saturent, plus personne ne peut travailler. Tu vois les indicateurs de trafic exploser. Le DSI est sur place.",
      actions: [
        {
          id: 'find_loop',
          label: 'Identifier le port qui cause la boucle avec show spanning-tree',
          type: 'BONNE_PISTE',
          consequence: "Tu te connectes au switch core. 'show spanning-tree' révèle qu'un port est en état Forwarding alors quil devrait être Blocking — un switch non autorisé a été branché.",
          question_id: 'stp_portfast',
        },
        {
          id: 'shutdown_port',
          label: 'Couper physiquement le port suspect',
          type: 'BONNE_PISTE',
          consequence: "En coupant le port incriminé, la tempête de broadcast s'arrête immédiatement. Le réseau se stabilise en quelques secondes.",
          question_id: 'stp_bpduguard',
        },
        {
          id: 'restart_switches',
          label: 'Redémarrer tous les switches',
          type: 'MAUVAISE_PISTE',
          consequence: "Redémarrer tous les switches coupe l'ensemble du réseau pendant 5 minutes. La boucle revient dès quils redémarrent car la cause n'est pas traitée.",
          malus: true,
        },
        {
          id: 'check_stp_mode',
          label: 'Vérifier si RSTP ou STP classique est utilisé',
          type: 'NEUTRE',
          consequence: "Le réseau utilise RSTP (Rapid STP). Ce n'est pas la cause de la boucle, mais cest bien de le savoir pour la suite.",
        },
        {
          id: 'check_root',
          label: 'Vérifier quel switch est le Root Bridge',
          type: 'BONNE_PISTE',
          consequence: "Le Root Bridge est correct. Mais tu remarques qu'un switch non managé a été connecté avec 2 câbles entre deux ports — créant une boucle physique.",
          question_id: 'stp_bpduguard',
        },
      ],
      resolution_ok: "Boucle stoppée en 3 minutes. Réseau stabilisé. Le DSI : \"Bonne gestion de crise, l'impact a été limité.\"",
      resolution_fail: "La boucle dure 15 minutes. Impact total sur tout le bâtiment B. Le DSI demande un rapport de post-mortem.",
    },

    // ======= 7. DHCP épuisé =======
    {
      id: 'dhcp',
      categorie: 'windows',
      title: 'TICKET #7723 — Niveau P2',
      situation: "Lundi matin, le service compta signale que 12 postes affichent une adresse 169.254.x.x et ne peuvent pas accéder au réseau. Plusieurs nouveaux stagiaires ont démarré ce matin.",
      actions: [
        {
          id: 'check_scope',
          label: 'Vérifier l\'état du scope DHCP sur le serveur',
          type: 'BONNE_PISTE',
          consequence: "Dans la console DHCP, tu vois que le pool 192.168.1.100-200 est à 100% d'utilisation. 100 baux actifs pour 100 adresses — le scope est épuisé.",
          question_id: 'dhcp_scope',
        },
        {
          id: 'check_service',
          label: 'Vérifier si le service DHCP est démarré',
          type: 'NEUTRE',
          consequence: "Le service DHCP Server est bien démarré et en cours d'exécution. Le problème vient d'ailleurs.",
        },
        {
          id: 'check_stale',
          label: 'Rechercher des baux obsolètes dans le scope',
          type: 'BONNE_PISTE',
          consequence: "Tu trouves 23 baux actifs correspondant à des MAC d'ordinateurs qui n'existent plus — des anciens postes non décommissionnés dans le DHCP.",
          question_id: 'dhcp_lease',
        },
        {
          id: 'restart_dhcp',
          label: 'Redémarrer le service DHCP',
          type: 'MAUVAISE_PISTE',
          consequence: "Le redémarrage du service ne libère aucun bail — les baux persistants en NVRAM. Les 12 postes restent sans adresse.",
          malus: true,
        },
        {
          id: 'ipconfig_renew',
          label: 'Faire un ipconfig /renew sur les postes en 169.254',
          type: 'NEUTRE',
          consequence: "Les postes tentent de renouveler mais le pool est toujours épuisé. La cause racine n'est pas traitée.",
        },
      ],
      resolution_ok: "Pool étendu et baux obsolètes supprimés. Les 12 postes obtiennent une adresse. Ton chef : \"Bien diagnostiqué, t'as vu les baux fantômes.\"",
      resolution_fail: "Les postes restent en 169.254.x.x jusqu'à 14h. Le service compta ne peut pas travailler le matin.",
    },

    // ======= 8. SSH Cisco impossible =======
    {
      id: 'cisco_ssh',
      categorie: 'cisco',
      title: 'TICKET #9001 — Niveau P2',
      situation: "Un admin réseau ne peut plus se connecter en SSH au routeur de bordure R-CORE. La connexion Telnet fonctionne encore mais le chef veut Telnet désactivé. L'admin voit : \"SSH connection refused\".",
      actions: [
        {
          id: 'check_rsa',
          label: 'Vérifier si les clés RSA sont générées',
          type: 'BONNE_PISTE',
          consequence: "Sur R-CORE, tu tapes 'show crypto key mypubkey rsa'. Aucune clé n'est affichée — elles ont été supprimées lors dune remise à zéro partielle de la config.",
          question_id: 'cisco_ssh_rsa',
        },
        {
          id: 'check_vty',
          label: 'Vérifier la configuration des lignes VTY',
          type: 'BONNE_PISTE',
          consequence: "Les lignes VTY acceptent SSH et Telnet. Mais tu remarques qu'après la ligne 'transport input ssh', un 'transport input telnet' a été ajouté dessous — écrasant le premier.",
          question_id: 'cisco_ssh_vty',
        },
        {
          id: 'check_acl',
          label: 'Vérifier si une ACL bloque le port 22',
          type: 'BONNE_PISTE',
          consequence: "Une ACL appliquée à l'interface de management bloque le port 22 entrant. Elle a été créée trop restrictive lors dun audit sécurité.",
          question_id: 'cisco_acl',
        },
        {
          id: 'check_domain',
          label: 'Vérifier le ip domain-name configuré',
          type: 'BONNE_PISTE',
          consequence: "La commande 'show run | include domain' ne retourne rien. Sans ip domain-name, impossible de générer des clés RSA pour SSH.",
          question_id: 'cisco_ssh_domain',
        },
        {
          id: 'reinstall_ios',
          label: 'Réinstaller l\'IOS du routeur',
          type: 'MAUVAISE_PISTE',
          consequence: "C'est une procédure lourde qui nécessite une fenêtre de maintenance. Ton chef est furieux — tu aurais dû diagnostiquer avant d'escalader.",
          malus: true,
        },
      ],
      resolution_ok: "SSH opérationnel sur R-CORE. Telnet désactivé. Ton chef : \"Bon travail, la sécurité est en ordre.\"",
      resolution_fail: "SSH toujours KO après 1h. L'admin doit continuer en Telnet (non chiffré). Audit sécurité compromis.",
    },

  
  // ======= 9. Active Directory — compte bloqué =======
  {
    id:'ad_locked',
    title:'TICKET #3314 — Niveau P1',
    situation:"Un employe des ventes ne peut plus se connecter ce matin. Erreur : le compte a ete desactive. Il a un rendez-vous client dans 30 minutes.",
    actions:[
      {id:'check_ad_account',label:'Verifier letat du compte dans Active Directory',type:'BONNE_PISTE',
       consequence:"Dans Utilisateurs et ordinateurs AD, le compte est bien desactive. La case Le compte est desactive est cochee.",
       question_id:'ad_enable_account'},
      {id:'check_lockout',label:'Verifier si le compte est verrouille (lockout)',type:'BONNE_PISTE',
       consequence:"Le compte est verrouille sur 2 controleurs de domaine apres 5 tentatives echouees ce matin.",
       question_id:'ad_unlock'},
      {id:'reset_pwd',label:'Reinitialiser son mot de passe directement',type:'NEUTRE',
       consequence:"La reinitialisation fonctionne mais le compte reste desactive. Il faut reactiver le compte."},
      {id:'check_gpo',label:'Verifier si une GPO a desactive le compte',type:'NEUTRE',
       consequence:"Aucune GPO ne cible ce compte. La desactivation est manuelle ou due au verrouillage."},
      {id:'reboot_dc',label:'Redemarrer le controleur de domaine',type:'MAUVAISE_PISTE',malus:true,
       consequence:"ERREUR CRITIQUE. Redemarrer un DC coupe lauthentification pour tous les utilisateurs. Ton chef recoit 12 appels."},
    ],
    resolution_ok:"Compte reactive et deverrouille. Lemploye se connecte juste a temps. Ton chef : Bien reagi, impact evite.",
    resolution_fail:"Lemploye manque son rendez-vous client. Perte commerciale. Ton chef est convoque par la direction.",
  },

  // ======= 10. GPO ne s'applique pas =======
  {
    id:'gpo',
    title:'TICKET #5521 — Niveau P2',
    situation:"Une nouvelle GPO de securite ne sapplique pas sur les postes compta. Les cles USB fonctionnent encore. Le RSSI veut une resolution avant 16h.",
    actions:[
      {id:'gpupdate',label:'Forcer un gpupdate /force sur les postes',type:'BONNE_PISTE',
       consequence:"gpupdate /force sexecute mais la GPO napparait pas dans gpresult. Le probleme est plus profond.",
       question_id:'gpo_gpresult'},
      {id:'check_link',label:'Verifier que la GPO est liee a la bonne OU',type:'BONNE_PISTE',
       consequence:"La GPO est liee a OU=Informatique et non a OU=Comptabilite. Les postes compta sont dans la mauvaise OU.",
       question_id:'gpo_link'},
      {id:'check_wmi',label:'Verifier si un filtre WMI est applique',type:'BONNE_PISTE',
       consequence:"Un filtre WMI limite la GPO aux postes Windows 11. Les postes compta sont sous Windows 10 — le filtre les exclut.",
       question_id:'gpo_wmi'},
      {id:'delete_gpo',label:'Supprimer et recreer la GPO',type:'MAUVAISE_PISTE',malus:true,
       consequence:"Tu supprimes la GPO. Maintenant elle ne sapplique nulle part. Ton chef demande une explication."},
      {id:'check_block',label:'Verifier si lheritage GPO est bloque sur lOU',type:'BONNE_PISTE',
       consequence:"LOU Comptabilite a Block Policy Inheritance active — les GPO parentes ne descendent pas.",
       question_id:'gpo_inheritance'},
    ],
    resolution_ok:"GPO appliquee correctement. Cles USB bloquees en compta. Ton chef : Bonne investigation, la cause etait subtile.",
    resolution_fail:"GPO non appliquee. Audit de securite compromis. Le RSSI demande un rapport.",
  },

  // ======= 11. Certificat SSL expiré =======
  {
    id:'ssl',
    title:'TICKET #7788 — Niveau P2',
    situation:"Le site intranet affiche CONNEXION NON SECURISEE depuis ce matin. Les navigateurs bloquent lacces. 200 employes ne peuvent plus acceder aux outils RH.",
    actions:[
      {id:'check_cert',label:'Verifier la date dexpiration du certificat SSL',type:'BONNE_PISTE',
       consequence:"Le certificat a expire hier a 23h59. Il avait ete emis il y a 2 ans sans alerte dexpiration configuree.",
       question_id:'ssl_renew'},
      {id:'check_iis',label:'Verifier la configuration IIS du site',type:'NEUTRE',
       consequence:"IIS est correctement configure. Le probleme vient du certificat, pas de IIS."},
      {id:'add_exception',label:'Demander aux utilisateurs dajouter une exception navigateur',type:'MAUVAISE_PISTE',malus:true,
       consequence:"Mauvaise pratique de securite. Ton chef et le RSSI sont mecontents."},
      {id:'check_chain',label:'Verifier la chaine de certification',type:'BONNE_PISTE',
       consequence:"La chaine est correcte. Le probleme est bien lexpiration du certificat.",
       direct_resolve:true},
      {id:'check_san',label:'Verifier les SAN du certificat',type:'NEUTRE',
       consequence:"Les SAN couvrent bien les domaines. Le probleme est lexpiration, pas la couverture."},
    ],
    resolution_ok:"Certificat renouvele et installe. Intranet accessible. Ton chef : Bien gere, configure une alerte.",
    resolution_fail:"Intranet inaccessible 4 heures. Productivite RH arretee. Rapport dincident demande.",
  },

  // ======= 12. Route manquante =======
  {
    id:'routing',
    title:'TICKET #2098 — Niveau P3',
    situation:"Le site secondaire 192.168.2.0/24 ne communique plus avec le site principal depuis une intervention hier. Les sauvegardes nocturnes ont echoue.",
    actions:[
      {id:'check_routes',label:'Verifier la table de routage sur R1',type:'BONNE_PISTE',
       consequence:"show ip route sur R1 ne montre plus de route vers 192.168.2.0/24. Elle a ete supprimee lors de lintervention dhier.",
       question_id:'routing_static'},
      {id:'ping_test',label:'Tester la connectivite avec des pings progressifs',type:'NEUTRE',
       consequence:"Le ping vers 192.168.2.1 echoue a partir de R1. Probleme de routage, pas physique."},
      {id:'check_interface',label:'Verifier letat des interfaces du routeur',type:'BONNE_PISTE',
       consequence:"Les interfaces sont toutes up/up. Le probleme est logiciel.",
       direct_resolve:true},
      {id:'check_acl_router',label:'Verifier si une ACL bloque le trafic inter-sites',type:'BONNE_PISTE',
       consequence:"Les ACL nont pas ete modifiees. Elles ne bloquent pas le trafic.",
       direct_resolve:true},
      {id:'reload_router',label:'Recharger la configuration sauvegardee du routeur',type:'MAUVAISE_PISTE',malus:true,
       consequence:"Le reload charge la startup-config sans verification prealable. Tu aurais du verifier avant."},
    ],
    resolution_ok:"Route statique ajoutee. Communication retablie. Sauvegardes repassent. Ton chef : Bien vu, rapide.",
    resolution_fail:"Communication coupee 6h supplementaires. Sauvegardes J+1 aussi compromises.",
  },

  // ======= 13. Imprimante réseau =======
  {
    id:'printer',
    title:'TICKET #4456 — Niveau P1',
    situation:"Limprimante reseau du plateau commercial HP LaserJet IP 192.168.1.50 naccessible depuis ce matin. 15 commerciaux ne peuvent pas imprimer leurs contrats.",
    actions:[
      {id:'ping_printer',label:'Pinger ladresse IP de limprimante',type:'BONNE_PISTE',
       consequence:"Le ping echoue. Limprimante ne repond pas du tout. Probleme reseau ou dadresse IP.",
       question_id:'printer_ip'},
      {id:'check_dhcp_printer',label:'Verifier si limprimante a change dadresse IP',type:'BONNE_PISTE',
       consequence:"Limprimante etait en DHCP et a obtenu une nouvelle adresse 192.168.1.87 suite au redemarrage du DHCP hier.",
       question_id:'printer_static'},
      {id:'restart_spooler',label:'Redemarrer le spouleur dimpression Windows',type:'NEUTRE',
       consequence:"Le spouleur redemmarre sur les postes. Limprimante reste inaccessible — le probleme est reseau."},
      {id:'reinstall_drivers',label:'Reinstaller les pilotes sur tous les postes',type:'MAUVAISE_PISTE',malus:true,
       consequence:"45 minutes pour reinstaller sur 15 postes. Limprimante reste inaccessible. Le probleme est son adresse IP."},
      {id:'check_switch_port',label:'Verifier le port switch de limprimante',type:'NEUTRE',
       consequence:"Le port switch est up/up. La connexion physique est correcte."},
    ],
    resolution_ok:"IP statique configuree, postes mis a jour. Impression retablie. Ton chef : Bien diagnostique.",
    resolution_fail:"Commerciaux sans imprimante 2h. Manager RH se plaint.",
  },

  // ======= 14. Espace disque NAS =======
  {
    id:'backup',
    title:'TICKET #6670 — Niveau P2',
    situation:"Alerte : sauvegarde nocturne echouee. Motif : Espace disque insuffisant sur le NAS de sauvegarde. Le volume est a 100%.",
    actions:[
      {id:'check_nas_space',label:'Analyser loccupation du volume NAS',type:'BONNE_PISTE',
       consequence:"Un dossier de sauvegarde dune ancienne VM desaffectee occupe 800 Go et na jamais ete supprime.",
       question_id:'backup_retention'},
      {id:'check_backup_policy',label:'Verifier la politique de retention des sauvegardes',type:'BONNE_PISTE',
       consequence:"La politique prevoit 30 jours mais le nettoyage est manuel. Personne ne la fait depuis 3 mois.",
       direct_resolve:true},
      {id:'add_disk',label:'Commander un disque supplementaire pour le NAS',type:'MAUVAISE_PISTE',malus:true,
       consequence:"La commande prendra 5 jours. Sauvegardes en echec pendant tout ce temps."},
      {id:'compress_backups',label:'Compresser les sauvegardes existantes',type:'NEUTRE',
       consequence:"La compression est deja activee. Pas de gain possible."},
      {id:'check_logs',label:'Consulter les logs de sauvegarde',type:'BONNE_PISTE',
       consequence:"Les logs montrent +20 Go par semaine sans nettoyage depuis 3 semaines. La VM desaffectee est la cause.",
       question_id:'backup_retention'},
    ],
    resolution_ok:"Anciennes sauvegardes supprimees, retention automatisee. NAS a 45%. Ton chef : Bien gere, maintenant cest automatique.",
    resolution_fail:"Sauvegardes en echec 3 nuits supplementaires. Audit de conformite compromis.",
  },

  // ======= 15. ExecutionPolicy PowerShell =======
  {
    id:'ps_policy',
    title:'TICKET #8823 — Niveau P2',
    situation:"Un developpeur ne peut pas executer son script PowerShell de deploiement. Erreur : Lexecution de scripts est desactivee sur ce systeme. Deploiement mensuel bloque.",
    actions:[
      {id:'check_policy',label:'Verifier lExecutionPolicy actuelle',type:'BONNE_PISTE',
       consequence:"Get-ExecutionPolicy retourne Restricted. Aucun script ne peut sexecuter dans cette configuration.",
       question_id:'ps_execution_policy'},
      {id:'check_signature',label:'Verifier si le script est signe numeriquement',type:'BONNE_PISTE',
       consequence:"Le script nest pas signe. Avec RemoteSigned, les scripts locaux non signes fonctionnent.",
       question_id:'ps_remotesigned'},
      {id:'run_as_admin',label:'Lancer PowerShell en tant quadministrateur',type:'NEUTRE',
       consequence:"Meme en admin, Restricted bloque les scripts. Droits admin et execution policy sont distincts."},
      {id:'disable_policy',label:'Mettre lExecutionPolicy a Unrestricted',type:'MAUVAISE_PISTE',malus:true,
       consequence:"Unrestricted est une mauvaise pratique. Tout script sexecute sans avertissement. Ton chef et le RSSI desapprouvent."},
      {id:'check_gpo_ps',label:'Verifier si une GPO controle lExecutionPolicy',type:'BONNE_PISTE',
       consequence:"Une GPO impose Restricted sur les postes devs depuis une mise a jour securite. Il faut signer le script ou creer une exception GPO.",
       direct_resolve:true},
    ],
    resolution_ok:"ExecutionPolicy RemoteSigned via GPO pour les developpeurs. Deploiement execute. Ton chef : Bonne approche.",
    resolution_fail:"Deploiement mensuel bloque. Applications non mises a jour. Retard projet.",
  },
], // fin scenarios

}; // fin RPG

// =====================================================
// QUESTIONS LIÉES AUX SCÉNARIOS
// =====================================================
var RPG_QUESTIONS = {

  winrm_port: {
    q: "Quel port WinRM utilise-t-il par défaut pour les connexions HTTP ?",
    opts: ["Port 443","Port 5985","Port 3389","Port 8080"],
    a: 1,
    x: "WinRM utilise le port 5985 (HTTP) et 5986 (HTTPS). Le pare-feu doit autoriser ce port pour que PowerShell Remoting fonctionne."
  },
  winrm_trustedhosts: {
    q: "Quelle commande configure les TrustedHosts WinRM sur le client ?",
    opts: [
      "Set-Item WSMan:\\\\localhost\\\\Client\\\\TrustedHosts -Value 'SRV-PROD'",
      "Add-WinRMHost -Name SRV-PROD",
      "New-PSSession -TrustHost SRV-PROD",
      "Enable-WSManCredSSP -Role Client -DelegateComputer SRV-PROD"
    ],
    a: 0,
    x: "En workgroup, le client doit déclarer les hôtes distants dans TrustedHosts. Cette commande est nécessaire car sans domaine AD, il n'y a pas de Kerberos pour l'authentification mutuelle."
  },
  winrm_enable: {
    q: "Que fait la commande Enable-PSRemoting -Force ?",
    opts: [
      "Active uniquement le service WinRM",
      "Configure WinRM, crée les listeners et les règles pare-feu",
      "Ouvre une session PowerShell distante",
      "Ajoute l'hôte dans TrustedHosts"
    ],
    a: 1,
    x: "Enable-PSRemoting fait tout en une commande : démarre WinRM, configure les listeners HTTP/HTTPS et crée les règles de pare-feu Windows nécessaires."
  },
  dns_service_restart: {
    q: "Comment redémarrer le service DNS Server en PowerShell ?",
    opts: [
      "Restart-Service DNS",
      "Start-Service -Name 'dns-server'",
      "Restart-Service -Name 'DNS'",
      "Invoke-Command {Start DNS}"
    ],
    a: 2,
    x: "Restart-Service -Name 'DNS' redémarre le service DNS Server Windows. Le nom exact du service est 'DNS'. Alternatives : net stop DNS && net start DNS, ou via la console DNS."
  },
  dns_soa: {
    q: "Que contient un enregistrement SOA (Start Of Authority) ?",
    opts: [
      "Uniquement les adresses IP des hôtes",
      "Le serveur de noms primaire, le TTL, le numéro de série et les délais de réplication",
      "Les enregistrements MX et CNAME uniquement",
      "La liste des serveurs secondaires autorisés"
    ],
    a: 1,
    x: "Le SOA contient : serveur DNS primaire, email de l'administrateur, numéro de série (incrémenté à chaque modif), TTL, durée de refresh/retry/expire. C'est la carte d'identité de la zone."
  },
  vlan_svi: {
    q: "Comment activer une SVI Vlan20 qui est en 'down' ?",
    opts: [
      "interface vlan 20 → ip address ... → shutdown",
      "vlan 20 → state active",
      "interface vlan 20 → no shutdown",
      "switchport mode access vlan 20"
    ],
    a: 2,
    x: "Une SVI désactivée se réactive avec 'no shutdown' dans le mode interface Vlan. Il faut aussi s'assurer que le VLAN existe dans la base de données VLAN (show vlan brief)."
  },
  vlan_ip_routing: {
    q: "Quelle commande active le routage inter-VLAN sur un switch L3 Cisco ?",
    opts: [
      "router ospf 1",
      "ip routing",
      "routing enable",
      "switchport mode trunk"
    ],
    a: 1,
    x: "La commande 'ip routing' en mode config global active le moteur de routage IP sur le switch L3. Sans elle, les SVIs ont des IPs mais le switch ne route pas entre elles."
  },
  vlan_trunk: {
    q: "Comment ajouter le VLAN 20 à la liste des VLANs autorisés sur un trunk ?",
    opts: [
      "switchport trunk allowed vlan add 20",
      "vlan 20 allowed trunk",
      "switchport access vlan 20",
      "trunk vlan 20 permit"
    ],
    a: 0,
    x: "La commande 'switchport trunk allowed vlan add 20' AJOUTE le VLAN 20 sans supprimer les autres. Sans le mot-clé 'add', la commande remplace toute la liste."
  },
  hyperv_snapshot: {
    q: "Que faut-il faire avec des snapshots Hyper-V corrompus ou orphelins ?",
    opts: [
      "Les supprimer directement depuis l'Explorateur Windows",
      "Les fusionner ou supprimer depuis le Gestionnaire Hyper-V",
      "Recréer la VM pour éviter les problèmes",
      "Les déplacer dans un autre dossier"
    ],
    a: 1,
    x: "Les snapshots Hyper-V (.avhdx) doivent être gérés depuis le Gestionnaire Hyper-V. La fusion (merge) intègre les changements dans le VHDX parent. Ne jamais les supprimer manuellement."
  },
  hyperv_disk_path: {
    q: "Comment modifier le chemin dun disque dur dans une VM Hyper-V ?",
    opts: [
      "Modifier directement le fichier .vmcx avec un éditeur texte",
      "Via Paramètres VM → Contrôleur SCSI → Disque dur → Modifier le chemin",
      "Set-VM -DiskPath 'nouveau chemin'",
      "Déplacer le VHDX puis redémarrer"
    ],
    a: 1,
    x: "Dans le Gestionnaire Hyper-V, Paramètres de la VM → sélectionner le disque dur → modifier le chemin. En PowerShell : Set-VMHardDiskDrive avec le paramètre -Path."
  },
  ntfs_deny: {
    q: "Dans les permissions NTFS, quelle règle s'applique en cas de conflit Allow/Deny ?",
    opts: [
      "Allow est prioritaire sur Deny",
      "La permission la plus récente gagne",
      "Deny est toujours prioritaire sur Allow",
      "L'héritage prend toujours le dessus"
    ],
    a: 2,
    x: "Deny est TOUJOURS prioritaire sur Allow dans les ACL NTFS, quelle que soit l'origine (directe ou héritée). C'est pourquoi un Deny explicite sur un compte écrase tous les Allow de ses groupes."
  },
  ntfs_group_deny: {
    q: "Un utilisateur est dans GRP-RH (Allow Lecture) et GRP-STAGIAIRES (Deny Lecture). Que se passe-t-il ?",
    opts: [
      "Il peut lire car GRP-RH lui donne Allow",
      "Il ne peut pas lire car le Deny de GRP-STAGIAIRES prime",
      "Les deux permissions s'annulent — accès bloqué par défaut",
      "Cela dépend de l'ordre des groupes dans l'AD"
    ],
    a: 1,
    x: "Deny prime toujours. Même si GRP-RH accorde Allow, le Deny de GRP-STAGIAIRES l'emporte. Solution : retirer l'utilisateur de GRP-STAGIAIRES ou supprimer le Deny explicite."
  },
  stp_portfast: {
    q: "Que fait PortFast sur un port Cisco et sur quel type de port l'utiliser ?",
    opts: [
      "Accélère STP pour les ports trunk uniquement",
      "Passe le port directement en Forwarding — à utiliser sur les ports d'extrémité (PC, serveurs)",
      "Désactive STP sur le port complètement",
      "Force le port en Root Port"
    ],
    a: 1,
    x: "PortFast fait passer le port directement en Forwarding sans passer par Listening/Learning (30s économisées). À réserver aux ports d'extrémité. Sur un port trunk vers un switch, PortFast peut causer des boucles."
  },
  stp_bpduguard: {
    q: "Que fait BPDU Guard et pourquoi l'activer avec PortFast ?",
    opts: [
      "Il bloque tous les VLANs sur le port",
      "Il désactive le port (err-disabled) si une BPDU est reçue — protège contre les switches non autorisés",
      "Il force le port à rester en Blocking",
      "Il prévient les boucles en augmentant la priorité STP"
    ],
    a: 1,
    x: "BPDU Guard passe le port en err-disabled dès qu'une BPDU est reçue. Couplé à PortFast, il protège contre la connexion dun switch non autorisé sur un port d'accès."
  },
  dhcp_scope: {
    q: "Quelle action immédiate pour résoudre un pool DHCP épuisé ?",
    opts: [
      "Redémarrer le serveur DHCP",
      "Étendre la plage d'adresses du scope ou créer un nouveau scope",
      "Supprimer tous les baux et recommencer",
      "Passer en adressage statique"
    ],
    a: 1,
    x: "Pour un pool épuisé : étendre la plage existante (si adresses disponibles), supprimer les baux obsolètes, ou créer un superscope. La suppression des baux fantômes libère aussi des adresses rapidement."
  },
  dhcp_lease: {
    q: "Comment voir les baux actifs DHCP en PowerShell ?",
    opts: [
      "Get-DHCPServerv4Lease -ScopeId 192.168.1.0",
      "Show-DHCPLeases -Scope all",
      "Get-NetIPAddress -DHCPEnabled $true",
      "ipconfig /showclassid"
    ],
    a: 0,
    x: "Get-DhcpServerv4Lease -ScopeId permet de lister tous les baux dun scope. Avec | Where-Object {$_.AddressState -eq 'ActiveReservation'} pour filtrer les baux actifs."
  },
  cisco_ssh_rsa: {
    q: "Quelle séquence est nécessaire pour générer des clés RSA pour SSH sur Cisco ?",
    opts: [
      "Juste : crypto key generate rsa",
      "hostname → ip domain-name → crypto key generate rsa modulus 2048",
      "enable secret → crypto key generate",
      "ip ssh version 2 → crypto key generate rsa"
    ],
    a: 1,
    x: "L'ordre est crucial : 1) hostname (nom unique requis), 2) ip domain-name (requis pour nommer la clé), 3) crypto key generate rsa modulus 2048 (min 768 bits pour SSHv2)."
  },
  cisco_ssh_vty: {
    q: "Comment autoriser uniquement SSH (pas Telnet) sur les lignes VTY ?",
    opts: [
      "transport input ssh only",
      "transport input ssh",
      "no transport input telnet → transport input ssh",
      "line vty 0 4 → ssh enable"
    ],
    a: 1,
    x: "La commande 'transport input ssh' sur les lignes VTY nautorise que SSH. Si une commande 'transport input telnet' vient après, elle écrase la précédente — l'ordre dans la config est important."
  },
  cisco_acl: {
    q: "Une ACL bloque le port 22. Quelle commande retire une entrée dune ACL nommée ?",
    opts: [
      "no ip access-list extended MGMT deny tcp any any eq 22",
      "ip access-list extended MGMT → no [numéro de séquence]",
      "delete acl MGMT rule 22",
      "ip access-list remove MGMT deny 22"
    ],
    a: 1,
    x: "Dans une ACL nommée, on entre dans son mode config (ip access-list extended NOM) puis on supprime l'entrée par son numéro de séquence (visible avec 'show ip access-lists'). C'est plus précis que de recréer toute l'ACL."
  },
  cisco_ssh_domain: {
    q: "Sans ip domain-name, que se passe-t-il si on essaie de générer des clés RSA ?",
    opts: [
      "Les clés sont générées avec un nom par défaut",
      "L'erreur 'You must specify a key name' apparaît",
      "SSH fonctionne quand même sans domaine",
      "Cisco utilise l'hostname comme nom de clé automatiquement"
    ],
    a: 1,
    x: "Sans ip domain-name, Cisco ne peut pas nommer les clés RSA (le nom est hostname.domaine). La commande crypto key generate rsa échoue avec une erreur. Il faut configurer ip domain-name avant."
  },
};



// =====================================================
// SCÉNARIOS RPG — Structure enrichie
// Actions types: BONNE_PISTE, NEUTRE, MAUVAISE_PISTE
// sub_actions: sous-choix après laction principale
// direct_resolve: résolution narrative sans question
// =====================================================
// =====================================================
// 15 SCÉNARIOS RPG — VERSION ENRICHIE
// Chaque action mène à des conséquences → nouvelles actions → résolution
// Structure : action → conséquence/analyse → décision → résultat
// =====================================================

var RPG_SCENARIOS_V2 = [

// ======= 1. WINRM / RSAT =======
{
  id:'winrm', title:'TICKET #4471', prio:'P2 — URGENT',
  situation:'14h32. Un collègue ne peut pas administrer SRV-PROD depuis RSAT. Erreur : "Accès refusé — WinRM ne répond pas". Il doit effectuer une maintenance dans 30 minutes.',
  actions:[
    {id:'ping',label:'Tester la connectivité réseau vers SRV-PROD',type:'BONNE_PISTE',
     consequence:'Le ping répond en 1ms. SRV-PROD est joignable. Le problème n\'est pas réseau — c\'est une configuration WinRM ou pare-feu.',
     follow_up:'Le serveur répond. Tu dois maintenant comprendre pourquoi WinRM refuse la connexion malgré la connectivité.',
     follow_up_actions:[
       {id:'check_svc',label:'Vérifier l\'état du service WinRM (Get-Service WinRM)',type:'BONNE_PISTE',
        consequence:'Le service WinRM est Stopped. Il a été désactivé lors d\'un audit sécurité la semaine dernière. Tu dois le démarrer et reconfigurer.',
        question_id:'winrm_enable'},
       {id:'check_fw',label:'Vérifier les règles de pare-feu Windows (port 5985)',type:'BONNE_PISTE',
        consequence:'La règle autorisant le port 5985 est désactivée. WinRM tourne mais le pare-feu bloque les connexions entrantes.',
        question_id:'winrm_port'},
       {id:'check_listener',label:'Lister les listeners WinRM actifs',type:'NEUTRE',
        consequence:'Aucun listener actif. Cela confirme que le service WinRM n\'est pas configuré sur SRV-PROD.'},
     ]},
    {id:'trusted',label:'Vérifier les TrustedHosts côté client',type:'BONNE_PISTE',
     consequence:'La liste TrustedHosts est vide. En workgroup (sans domaine AD), le client doit déclarer SRV-PROD pour que l\'authentification NTLM fonctionne.',
     follow_up:'TrustedHosts vide confirmé. Tu dois décider comment corriger.',
     follow_up_actions:[
       {id:'add_trusted',label:'Ajouter SRV-PROD avec Set-Item WSMan:\\localhost\\Client\\TrustedHosts',type:'BONNE_PISTE',
        consequence:'La commande s\'exécute. Après avoir ouvert une nouvelle session, RSAT se connecte. Tu demandes à ton collègue de tester.',
        question_id:'winrm_trustedhosts'},
       {id:'add_all',label:'Mettre TrustedHosts à * (tous les hôtes)',type:'MAUVAISE_PISTE',malus:true,
        consequence:'ERREUR DE SÉCURITÉ. Accepter tous les hôtes expose le poste à des connexions non vérifiées. Le RSSI te contacte.'},
     ]},
    {id:'restart',label:'Redémarrer SRV-PROD pour forcer une réinitialisation',type:'MAUVAISE_PISTE',malus:true,
     consequence:'SRV-PROD est en production. 20 utilisateurs perdent leur connexion. Le chef reçoit une alerte et t\'appelle immédiatement.'},
    {id:'creds',label:'Vérifier les identifiants utilisés par le collègue',type:'NEUTRE',
     consequence:'Les identifiants sont valides — le compte admin local existe. Ce n\'est pas la cause.'},
    {id:'psremoting',label:'Lancer Enable-PSRemoting -Force sur SRV-PROD (console locale)',type:'BONNE_PISTE',
     consequence:'Tu accèdes directement à SRV-PROD. Enable-PSRemoting reconfigure tout en une commande : service, listeners, règles pare-feu.',
     question_id:'winrm_enable'},
  ],
  resolution_ok:'WinRM opérationnel. Le collègue accède à RSAT. Ton chef : "Bien joué, la maintenance peut avoir lieu."',
  resolution_fail:'Connexion toujours impossible. La maintenance est repoussée. Ton chef est mécontent.',
},

// ======= 2. DNS — panne site B =======
{
  id:'dns', title:'TICKET #3892', prio:'P1 — CRITIQUE',
  situation:'Alerte 9h15. Tous les postes du site B ont perdu accès aux ressources réseau. Erreur : "Serveur DNS introuvable". Le DSI a appelé. 80 utilisateurs sont bloqués.',
  actions:[
    {id:'check_svc',label:'Vérifier l\'état du service DNS sur le serveur',type:'BONNE_PISTE',
     consequence:'Le service DNS est Stopped. L\'heure d\'arrêt correspond à la mise à jour Windows automatique de 3h00 ce matin.',
     follow_up:'Service arrêté identifié. Avant de le redémarrer, tu dois vérifier si les zones sont intègres.',
     follow_up_actions:[
       {id:'check_zones',label:'Vérifier l\'intégrité des zones DNS avant redémarrage',type:'BONNE_PISTE',
        consequence:'Les zones semblent intègres. L\'enregistrement SOA a un numéro de série valide. Tu peux démarrer le service.',
        question_id:'dns_service_restart'},
       {id:'start_direct',label:'Démarrer le service DNS immédiatement sans vérification',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Le service démarre mais la zone SOA est corrompue — erreur de réplication. Le DNS répond mais avec des données incorrectes.'},
       {id:'check_eventlog',label:'Consulter les journaux d\'événements DNS avant toute action',type:'BONNE_PISTE',
        consequence:'Event ID 4013 : zones AD non chargées au démarrage. La mise à jour a modifié les dépendances. Tu sais exactement quoi corriger.',
        question_id:'dns_soa'},
     ]},
    {id:'flush',label:'Vider le cache DNS sur les postes clients (ipconfig /flushdns)',type:'NEUTRE',
     consequence:'Cache vidé sur plusieurs postes. Le problème persiste — ce n\'est pas un problème de cache local.'},
    {id:'check_dc',label:'Vérifier si le contrôleur de domaine répond',type:'BONNE_PISTE',
     consequence:'Le DC répond en LDAP mais les requêtes DNS timeout. Cela confirme que c\'est le service DNS, pas l\'AD en lui-même.',
     follow_up:'DC opérationnel mais DNS mort. Le problème est isolé au service DNS.',
     follow_up_actions:[
       {id:'check_dns_dc',label:'Tester la résolution DNS depuis le DC lui-même',type:'BONNE_PISTE',
        consequence:'Même le DC ne peut pas résoudre ses propres enregistrements. Le service DNS est bien la cause racine.',
        question_id:'dns_service_restart'},
       {id:'change_dns_alt',label:'Pointer les postes vers un DNS alternatif (secondaire ou externe)',type:'NEUTRE',
        consequence:'Internet revient. Mais les ressources internes (partages, GPO) restent inaccessibles car le DNS interne n\'est pas rétabli.'},
     ]},
    {id:'pub_dns',label:'Changer les DNS des postes vers 8.8.8.8 en urgence',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Internet revient mais les ressources AD sont inaccessibles. Tu as modifié la config sans validation. Le DSI demande une explication.'},
  ],
  resolution_ok:'Service DNS redémarré, zones intègres. Réseau rétabli en 3 minutes. Le DSI : "Réaction rapide, impact limité."',
  resolution_fail:'DNS en panne 45 minutes. Rapport d\'incident exigé. Ton chef prend note.',
},

// ======= 3. VLAN 20 inaccessible =======
{
  id:'vlan', title:'TICKET #5103', prio:'P2 — MOYEN',
  situation:'Le département RH (VLAN 20) ne peut plus accéder au serveur de fichiers depuis ce matin. Les autres VLANs fonctionnent. La responsable RH te relance toutes les 10 minutes.',
  actions:[
    {id:'check_svi',label:'Vérifier l\'état de la SVI Vlan20 sur le switch L3',type:'BONNE_PISTE',
     consequence:'L\'interface Vlan20 est en "down/down". Elle a probablement été désactivée manuellement. Tu es sur la bonne piste.',
     follow_up:'SVI down trouvée. Tu dois comprendre pourquoi avant d\'agir.',
     follow_up_actions:[
       {id:'check_who',label:'Regarder l\'historique des commandes (show logging)',type:'BONNE_PISTE',
        consequence:'Les logs montrent "Vlan20 shutdown" tapé hier à 23h12 par le compte "admin-maintenance". C\'était lors d\'un test qui n\'a pas été annulé.',
        question_id:'vlan_svi'},
       {id:'no_shutdown',label:'Faire un no shutdown sur Vlan20 directement',type:'BONNE_PISTE',
        consequence:'La SVI passe en "up/up". Le VLAN 20 retrouve sa connectivité vers les autres VLANs.',
        question_id:'vlan_svi'},
       {id:'check_vlan_db',label:'Vérifier que le VLAN 20 existe bien dans la base (show vlan brief)',type:'BONNE_PISTE',
        consequence:'Le VLAN 20 est actif dans la base et assigné aux bons ports. Le problème vient bien de la SVI.'},
     ]},
    {id:'check_routing',label:'Vérifier si ip routing est activé sur le switch L3',type:'BONNE_PISTE',
     consequence:'"show run | include ip routing" ne retourne rien. La commande a été retirée lors d\'une "simplification" de config.',
     follow_up:'ip routing absent. Sans lui, les SVIs ont des IPs mais le switch ne route pas.',
     follow_up_actions:[
       {id:'add_routing',label:'Activer ip routing en mode config global',type:'BONNE_PISTE',
        consequence:'Tu tapes "ip routing". Le switch commence immédiatement à router entre les VLANs. Le VLAN 20 retrouve son accès.',
        question_id:'vlan_ip_routing'},
       {id:'check_ospf',label:'Vérifier si OSPF ou un protocole de routage était actif',type:'NEUTRE',
        consequence:'Aucun protocole de routage dynamique. Le routage était statique via ip routing. Confirme le diagnostic.'},
     ]},
    {id:'check_trunk',label:'Vérifier la configuration du port trunk inter-switches',type:'BONNE_PISTE',
     consequence:'Le VLAN 20 n\'est plus dans la liste autorisée sur le trunk. Il a été retiré lors d\'un "nettoyage" récent.',
     follow_up:'VLAN 20 absent du trunk. Tu dois le rajouter.',
     follow_up_actions:[
       {id:'add_vlan_trunk',label:'Ajouter le VLAN 20 avec switchport trunk allowed vlan add 20',type:'BONNE_PISTE',
        consequence:'Le VLAN 20 est maintenant autorisé sur le trunk. Le trafic passe. La responsable RH confirme l\'accès.',
        question_id:'vlan_trunk'},
       {id:'replace_trunk',label:'Utiliser switchport trunk allowed vlan 20 (sans add)',type:'MAUVAISE_PISTE',malus:true,
        consequence:'ERREUR. Sans le mot "add", tous les autres VLANs sont supprimés du trunk. Panne généralisée.'},
     ]},
    {id:'restart_sw',label:'Redémarrer le switch RH',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Tous les postes RH perdent la connexion pendant 3 minutes. Le problème n\'est pas résolu.'},
    {id:'check_acl',label:'Vérifier les ACL appliquées sur les interfaces VLAN',type:'NEUTRE',
     consequence:'Aucune ACL suspecte. Le problème est ailleurs.'},
  ],
  resolution_ok:'VLAN 20 opérationnel. Les RH accèdent au serveur de fichiers. Ton chef : "Bon diagnostic, cause trouvée."',
  resolution_fail:'VLAN 20 coupé 1h. Rapport d\'impact demandé.',
},

// ======= 4. HYPER-V VM ne démarre pas =======
{
  id:'hyperv', title:'TICKET #2267', prio:'P2 — URGENT',
  situation:'Un développeur ne peut plus démarrer sa VM de test. Erreur : "Disque non trouvé". Il a une démo dans 2 heures. La VM contient 3 mois de développement.',
  actions:[
    {id:'open_hv',label:'Ouvrir le Gestionnaire Hyper-V et inspecter la configuration',type:'BONNE_PISTE',
     consequence:'Dans Paramètres → Contrôleur SCSI → Disque dur, le chemin pointe vers D:\\VMs\\Dev-VM.vhdx mais ce dossier n\'existe pas.',
     follow_up:'Chemin incorrect trouvé. Tu dois comprendre ce qui s\'est passé avant de corriger.',
     follow_up_actions:[
       {id:'find_vhdx',label:'Chercher le fichier VHDX avec Explorer (tous les disques)',type:'BONNE_PISTE',
        consequence:'Le fichier est sur E:\\VMs\\Dev-VM.vhdx. Il a été déplacé lors d\'une migration de disque sans mise à jour de la config VM.',
        question_id:'hyperv_disk_path'},
       {id:'check_snapshots',label:'Vérifier la chaîne de snapshots dans le Gestionnaire',type:'BONNE_PISTE',
        consequence:'Tu vois 4 snapshots enchaînés. L\'un d\'eux (.avhdx) pointe vers un chemin différent qui n\'existe plus. C\'est la cause.',
        question_id:'hyperv_snapshot'},
       {id:'check_events',label:'Consulter les journaux d\'événements Hyper-V',type:'BONNE_PISTE',
        consequence:'Event 12220 : "Cannot open attachment [...] The system cannot find the file specified." Chemin : D:\\VMs\\Dev-VM.avhdx.'},
     ]},
    {id:'snapshot',label:'Chercher un snapshot valide et restaurer',type:'BONNE_PISTE',
     consequence:'Tu trouves un snapshot d\'hier 18h. En le restaurant, la VM retrouve un état cohérent avec tous les fichiers accessibles.',
     direct_resolve:true},
    {id:'recreate',label:'Recréer la VM depuis zéro rapidement',type:'MAUVAISE_PISTE',malus:true,
     consequence:'ERREUR CRITIQUE. 3 mois de travail perdus. Le développeur est catastrophé. Ton chef est furieux.'},
    {id:'check_switch',label:'Vérifier le commutateur réseau virtuel',type:'NEUTRE',
     consequence:'Le commutateur est bien configuré. Le problème de démarrage n\'est pas lié au réseau.'},
    {id:'export_vm',label:'Tenter un export de la VM pour récupérer les données',type:'NEUTRE',
     consequence:'L\'export nécessite que la VM soit accessible. Impossible dans l\'état actuel.'},
  ],
  resolution_ok:'VM démarrée, démo réussie. Ton chef : "Bien géré, impact minimal."',
  resolution_fail:'VM inaccessible. Démo annulée. Rapport d\'incident demandé.',
},

// ======= 5. NTFS — accès refusé =======
{
  id:'ntfs', title:'TICKET #6814', prio:'P1 — URGENT',
  situation:'La responsable RH ne peut plus accéder au dossier \\\\SRV-FILE\\Confidentiel-RH depuis ce matin. "Accès refusé". Ses collègues y accèdent normalement.',
  actions:[
    {id:'check_ntfs',label:'Inspecter les permissions NTFS du dossier (onglet Sécurité)',type:'BONNE_PISTE',
     consequence:'Tu vois une entrée "Deny - Tous les droits" sur le compte de la responsable, ajoutée hier à 22h. Un Deny explicite prime sur tous les Allow.',
     follow_up:'Deny explicite trouvé. Tu dois identifier pourquoi et décider comment corriger.',
     follow_up_actions:[
       {id:'remove_deny',label:'Supprimer l\'entrée Deny directement',type:'BONNE_PISTE',
        consequence:'L\'entrée Deny est supprimée. La responsable peut maintenant accéder au dossier. Ses droits Allow via GRP-RH s\'appliquent normalement.',
        question_id:'ntfs_deny'},
       {id:'check_inheritance',label:'Vérifier si l\'héritage NTFS est actif sur ce dossier',type:'BONNE_PISTE',
        consequence:'L\'héritage est coupé et les ACL ont été reconstruites manuellement. Le Deny a été ajouté par erreur lors de cette reconstruction.'},
       {id:'reset_permissions',label:'Réinitialiser toutes les permissions et tout reconfigurer',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Tu effaces toutes les ACL du dossier. Personne ne peut plus y accéder. Il faut tout reconfigurer depuis zéro.'},
     ]},
    {id:'check_groups',label:'Vérifier les groupes AD de la responsable',type:'BONNE_PISTE',
     consequence:'Elle est dans GRP-RH (Allow) mais aussi dans GRP-STAGIAIRES (Deny sur ce dossier). Le Deny de GRP-STAGIAIRES prime.',
     follow_up:'Appartenance erronée à GRP-STAGIAIRES trouvée.',
     follow_up_actions:[
       {id:'remove_group',label:'Retirer du groupe GRP-STAGIAIRES dans l\'AD',type:'BONNE_PISTE',
        consequence:'Après déconnexion/reconnexion, les nouveaux tokens Kerberos s\'appliquent. L\'accès est rétabli.',
        question_id:'ntfs_group_deny'},
       {id:'check_why_added',label:'Comprendre pourquoi elle a été ajoutée à GRP-STAGIAIRES',type:'NEUTRE',
        consequence:'Un script de migration a mal classé son compte lors d\'une réorganisation des OU la semaine dernière.'},
     ]},
    {id:'reset_pwd',label:'Réinitialiser son mot de passe (pour forcer une reconnexion)',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Son mot de passe change mais le problème NTFS persiste. Elle doit reconfigurer ses applications.'},
    {id:'check_share',label:'Vérifier les permissions de partage SMB',type:'NEUTRE',
     consequence:'Les permissions de partage sont "Everyone - Contrôle total". Le problème vient bien des NTFS.'},
  ],
  resolution_ok:'Accès rétabli. La responsable peut travailler. Ton chef : "Bien diagnostiqué, cause subtile."',
  resolution_fail:'Accès refusé toute la journée. Le DRH escalade.',
},

// ======= 6. STP — boucle réseau =======
{
  id:'stp', title:'TICKET #1190', prio:'P3 — CRITIQUE',
  situation:'ALERTE. Le réseau du bâtiment B sature. Tous les switches ont des indicateurs de trafic à 100%. Personne ne peut travailler. Le DSI est sur place et attend ta réponse.',
  actions:[
    {id:'show_stp',label:'Analyser l\'arbre STP (show spanning-tree) sur le switch core',type:'BONNE_PISTE',
     consequence:'show spanning-tree montre un port en Forwarding qui devrait être Blocking. Un switch non managé crée une boucle L2.',
     follow_up:'Boucle STP identifiée sur le port Gi0/2. Tu dois l\'isoler immédiatement.',
     follow_up_actions:[
       {id:'shutdown_port',label:'Couper le port incriminé (shutdown) immédiatement',type:'BONNE_PISTE',
        consequence:'Le port est coupé. La tempête de broadcast s\'arrête en 2 secondes. Le réseau se stabilise. Le DSI voit les indicateurs baisser.',
        question_id:'stp_bpduguard'},
       {id:'trace_cable',label:'Tracer le câble du port pour identifier l\'équipement non autorisé',type:'BONNE_PISTE',
        consequence:'Un stagiaire a branché un switch TP-Link personnel pour avoir plus de prises dans son bureau. C\'est lui qui a créé la boucle.'},
       {id:'restart_switches',label:'Redémarrer tous les switches du bâtiment',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Redémarrage en cascade. 5 minutes de coupure complète. La boucle revient au démarrage car la cause n\'est pas traitée.'},
     ]},
    {id:'shutdown_direct',label:'Couper le port suspect identifié visuellement (LED orange)',type:'BONNE_PISTE',
     consequence:'Tu coupes le bon port. La tempête de broadcast cesse immédiatement. Réseau stabilisé.',
     question_id:'stp_portfast'},
    {id:'check_root',label:'Identifier le Root Bridge actuel (show spanning-tree)',type:'NEUTRE',
     consequence:'Le Root Bridge est le switch core attendu. L\'arbre STP est bien construit, mais la boucle physique le court-circuite.'},
    {id:'enable_portfast',label:'Activer PortFast sur tous les ports access',type:'MAUVAISE_PISTE',malus:true,
     consequence:'PortFast sur un port trunk aggrave la situation. Des BPDUs sont ignorées et de nouvelles boucles apparaissent.'},
    {id:'check_cdp',label:'Utiliser CDP pour cartographier les connexions (show cdp neighbors)',type:'BONNE_PISTE',
     consequence:'CDP ne voit pas le switch non managé (il ne parle pas CDP). Mais tu identifies le port par élimination.',
     follow_up:'Port suspect isolé par CDP. Tu dois maintenant agir.',
     follow_up_actions:[
       {id:'shutdown_suspect',label:'Couper le port suspect identifié',type:'BONNE_PISTE',
        consequence:'Port coupé. Boucle stoppée. Réseau stabilisé en quelques secondes.',
        question_id:'stp_bpduguard'},
       {id:'check_again',label:'Relancer show spanning-tree pour confirmer',type:'NEUTRE',
        consequence:'La topologie STP est maintenant cohérente. Tous les ports sont en Forwarding ou Blocking normalement.'},
     ]},
  ],
  resolution_ok:'Boucle stoppée en 3 minutes. Réseau stabilisé. Le DSI : "Bonne réactivité en situation de crise."',
  resolution_fail:'Boucle active 15+ minutes. Rapport de post-mortem exigé. Impact total bâtiment B.',
},

// ======= 7. DHCP épuisé =======
{
  id:'dhcp', title:'TICKET #7723', prio:'P2 — URGENT',
  situation:'Lundi matin, 12 postes du service compta affichent 169.254.x.x et ne peuvent pas accéder au réseau. Plusieurs nouveaux stagiaires sont arrivés ce matin.',
  actions:[
    {id:'check_scope',label:'Vérifier l\'état du scope DHCP dans la console',type:'BONNE_PISTE',
     consequence:'Scope 192.168.1.100-200 : 100 baux sur 100 — pool épuisé. Des baux obsolètes d\'anciens postes occupent 30% de l\'espace.',
     follow_up:'Pool épuisé confirmé. Deux solutions possibles : libérer des baux ou étendre le pool.',
     follow_up_actions:[
       {id:'purge_stale',label:'Identifier et supprimer les baux obsolètes (MACs inexistants)',type:'BONNE_PISTE',
        consequence:'23 baux d\'anciens postes supprimés. 23 adresses libérées. Les 12 postes obtiennent leurs adresses en quelques secondes.',
        question_id:'dhcp_lease'},
       {id:'extend_scope',label:'Étendre le scope de /24 à plus d\'adresses',type:'BONNE_PISTE',
        consequence:'Tu étends le scope à 192.168.1.100-250. 50 adresses supplémentaires disponibles. Les postes obtiennent leurs IPs.',
        question_id:'dhcp_scope'},
       {id:'restart_dhcp',label:'Redémarrer le service DHCP pour libérer les baux',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Le redémarrage ne libère pas les baux persistants. Les 12 postes restent en 169.254.x.x.'},
     ]},
    {id:'check_svc',label:'Vérifier si le service DHCP est bien démarré',type:'NEUTRE',
     consequence:'Le service est actif et distribue. Le problème vient de l\'épuisement du pool, pas du service.'},
    {id:'ipconfig',label:'Faire un ipconfig /renew sur les postes en 169.254',type:'NEUTRE',
     consequence:'Les postes tentent de renouveler. Ils obtiennent "Impossible de contacter le serveur DHCP" — le pool est épuisé.'},
    {id:'static',label:'Configurer des IPs statiques sur les 12 postes',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Solution temporaire non documentée. Dans 2 semaines tu as 12 postes en statique et personne ne sait pourquoi.'},
    {id:'check_relay',label:'Vérifier si le relay agent fonctionne (autre sous-réseau)',type:'BONNE_PISTE',
     consequence:'Le relay agent est opérationnel. Les postes reçoivent bien les requêtes DHCP. Le problème est le pool épuisé.',
     follow_up:'Relay OK mais pool vide. Il faut libérer des adresses.',
     follow_up_actions:[
       {id:'purge_relay',label:'Supprimer les baux obsolètes pour libérer des adresses',type:'BONNE_PISTE',
        consequence:'Baux obsolètes supprimés. Adresses libérées. Les postes obtiennent leurs IPs.',
        question_id:'dhcp_lease'},
     ]},
  ],
  resolution_ok:'Pool libéré. Les 12 postes ont leur IP. Ton chef : "Bien vu, les baux fantômes."',
  resolution_fail:'Compta sans réseau jusqu\'à 14h. Rapport de cause demandé.',
},

// ======= 8. SSH Cisco =======
{
  id:'cisco_ssh', title:'TICKET #9001', prio:'P2 — MOYEN',
  situation:'L\'admin réseau ne peut plus se connecter en SSH au routeur R-CORE. La connexion Telnet fonctionne encore mais le chef veut Telnet désactivé d\'urgence pour l\'audit.',
  actions:[
    {id:'check_rsa',label:'Vérifier si les clés RSA existent (show crypto key mypubkey rsa)',type:'BONNE_PISTE',
     consequence:'Aucune clé RSA. Elles ont été supprimées lors d\'un "crypto zeroize" pendant une remise à zéro partielle.',
     follow_up:'Clés RSA absentes. Tu dois les régénérer dans le bon ordre.',
     follow_up_actions:[
       {id:'check_prereqs',label:'Vérifier le hostname et ip domain-name avant génération',type:'BONNE_PISTE',
        consequence:'"show run | include domain" ne retourne rien. Sans ip domain-name, la génération des clés échoue.',
        question_id:'cisco_ssh_domain'},
       {id:'gen_rsa_direct',label:'Lancer crypto key generate rsa modulus 2048 directement',type:'MAUVAISE_PISTE',malus:true,
        consequence:'"% You must specify a key name using the \'label\' keyword". Sans domaine configuré, Cisco ne peut pas nommer la clé.'},
       {id:'full_sequence',label:'Configurer hostname, domain-name puis générer les clés',type:'BONNE_PISTE',
        consequence:'La séquence complète réussit. Les clés RSA 2048 bits sont générées. SSH v2 peut être activé.',
        question_id:'cisco_ssh_rsa'},
     ]},
    {id:'check_vty',label:'Inspecter la configuration des lignes VTY',type:'BONNE_PISTE',
     consequence:'"transport input ssh" est bien configuré. Mais en regardant attentivement, une ligne "transport input telnet" a été ajoutée après — elle écrase la première.',
     follow_up:'VTY mal configurée. Il faut corriger.',
     follow_up_actions:[
       {id:'fix_vty',label:'Reconfigurer les VTY correctement (transport input ssh)',type:'BONNE_PISTE',
        consequence:'Les lignes VTY n\'acceptent plus que SSH. Telnet est bloqué. L\'audit peut se poursuivre.',
        question_id:'cisco_ssh_vty'},
       {id:'check_version',label:'Verifier la version SSH',type:'NEUTRE',
        consequence:'SSHv1 par defaut, moins securise. Configurer ip ssh version 2 est recommande.'},
     ]},
    {id:'check_acl',label:'Vérifier si une ACL bloque le port 22 entrant',type:'BONNE_PISTE',
     consequence:'Une ACL appliquée à l\'interface de management bloque TCP port 22. Elle a été créée trop restrictive lors de l\'audit.',
     follow_up:'ACL trop restrictive trouvée.',
     follow_up_actions:[
       {id:'fix_acl',label:'Modifier l\'ACL pour autoriser SSH depuis le réseau admin',type:'BONNE_PISTE',
        consequence:'Après modification, SSH fonctionne depuis le poste de l\'admin. Telnet est bien bloqué.',
        question_id:'cisco_acl'},
       {id:'delete_acl',label:'Supprimer complètement l\'ACL de management',type:'MAUVAISE_PISTE',malus:true,
        consequence:'SSH fonctionne mais le routeur est maintenant accessible depuis n\'importe quelle IP. Mauvaise pratique sécurité.'},
     ]},
    {id:'check_domain',label:'Vérifier ip domain-name (requis pour SSH)',type:'BONNE_PISTE',
     consequence:'"show run | include domain" ne retourne rien. Sans ip domain-name les clés RSA ne peuvent pas être générées.',
     question_id:'cisco_ssh_domain'},
    {id:'reinstall_ios',label:'Réinstaller l\'IOS du routeur',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Procédure lourde, fenêtre de maintenance requise. Ton chef demande pourquoi tu escalades sans diagnostic complet.'},
  ],
  resolution_ok:'SSH opérationnel, Telnet désactivé. Ton chef : "Parfait pour l\'audit."',
  resolution_fail:'SSH toujours KO. Telnet reste actif. Audit compromis.',
},

// ======= 9. Compte AD bloqué =======
{
  id:'ad_locked', title:'TICKET #3314', prio:'P1 — URGENT',
  situation:'Un commercial ne peut plus se connecter. "Compte désactivé ou expiré". Il a un rendez-vous client dans 20 minutes. Son manager appelle directement.',
  actions:[
    {id:'check_account',label:'Vérifier l\'état du compte dans ADUC',type:'BONNE_PISTE',
     consequence:'Le compte est désactivé ET verrouillé. Deux problèmes distincts. La désactivation est manuelle (hier 22h), le verrouillage est dû à 5 tentatives échouées ce matin.',
     follow_up:'Compte désactivé ET verrouillé. Il faut traiter les deux.',
     follow_up_actions:[
       {id:'enable_and_unlock',label:'Réactiver ET déverrouiller le compte',type:'BONNE_PISTE',
        consequence:'Enable-ADAccount + Unlock-ADAccount. Le commercial peut se connecter juste avant son rendez-vous.',
        question_id:'ad_enable_account'},
       {id:'only_unlock',label:'Déverrouiller sans réactiver',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Unlock-ADAccount exécuté mais le compte reste désactivé. Le commercial ne peut toujours pas se connecter.'},
       {id:'check_why_disabled',label:'Comprendre pourquoi il a été désactivé',type:'BONNE_PISTE',
        consequence:'Un script de départ a désactivé son compte par erreur — son nom ressemble à celui d\'un employé qui a quitté l\'entreprise.'},
     ]},
    {id:'check_lockout',label:'Vérifier les lockouts avec Account Lockout Status tool',type:'BONNE_PISTE',
     consequence:'5 tentatives échouées depuis son poste à 8h01. Le compte est verrouillé sur 2 DC. Quelqu\'un a essayé de se connecter avec le mauvais mot de passe.',
     follow_up:'Lockout identifié sur 2 DCs. Tu dois déverrouiller.',
     follow_up_actions:[
       {id:'unlock_dc',label:'Déverrouiller sur tous les DCs (Unlock-ADAccount)',type:'BONNE_PISTE',
        consequence:'Le compte est déverrouillé. Il peut maintenant se connecter si le compte est aussi réactivé.',
        question_id:'ad_unlock'},
       {id:'force_pwd',label:'Forcer un changement de mot de passe',type:'NEUTRE',
        consequence:'Utile pour la sécurité mais ne résout pas le problème immédiat. Le compte doit aussi être réactivé.'},
     ]},
    {id:'reset_pwd_ad',label:'Réinitialiser son mot de passe dans l\'AD',type:'NEUTRE',
     consequence:'Le mot de passe est changé mais le compte reste désactivé. Le problème n\'est pas résolu.'},
    {id:'restart_dc',label:'Redémarrer le contrôleur de domaine',type:'MAUVAISE_PISTE',malus:true,
     consequence:'ERREUR CRITIQUE. Redémarrer un DC coupe l\'authentification pour tout le domaine. Ton chef reçoit 30 appels.'},
  ],
  resolution_ok:'Compte réactivé et déverrouillé. Rendez-vous sauvé. Ton chef : "Réactivité parfaite."',
  resolution_fail:'Commercial bloqué. Rendez-vous client manqué. Perte commerciale signalée.',
},

// ======= 10. GPO non appliquée =======
{
  id:'gpo', title:'TICKET #5521', prio:'P2 — MOYEN',
  situation:'Une GPO de sécurité (désactivation USB) ne s\'applique pas sur les postes compta. Les clés USB fonctionnent encore. Le RSSI veut une résolution avant l\'audit de 16h.',
  actions:[
    {id:'gpupdate',label:'Forcer gpupdate /force sur les postes compta',type:'BONNE_PISTE',
     consequence:'gpupdate s\'exécute mais la GPO n\'apparaît toujours pas dans gpresult. Le problème est structurel, pas de délai.',
     follow_up:'gpupdate ne suffit pas. Tu dois identifier pourquoi la GPO ne descend pas.',
     follow_up_actions:[
       {id:'gpresult',label:'Lancer gpresult /r /scope computer pour analyser',type:'BONNE_PISTE',
        consequence:'gpresult montre que les GPO du niveau domaine s\'appliquent mais pas celles de l\'OU parent "Informatique". Les postes compta sont dans une OU différente.',
        question_id:'gpo_gpresult'},
       {id:'check_link',label:'Vérifier le lien de la GPO dans la GPMC',type:'BONNE_PISTE',
        consequence:'La GPO est liée à OU=Informatique. Les postes compta sont dans OU=Comptabilité. La GPO ne les atteint pas.',
        question_id:'gpo_link'},
     ]},
    {id:'check_link_gpo',label:'Vérifier où la GPO est liée dans la GPMC',type:'BONNE_PISTE',
     consequence:'La GPO est liée à OU=Informatique, pas à OU=Comptabilité. Erreur de configuration initiale.',
     follow_up:'Mauvais lien trouvé. Tu dois décider de la correction.',
     follow_up_actions:[
       {id:'relink',label:'Créer un nouveau lien vers OU=Comptabilité',type:'BONNE_PISTE',
        consequence:'Lien créé. Après gpupdate /force, la GPO s\'applique. Les clés USB sont bloquées.',
        question_id:'gpo_link'},
       {id:'check_inheritance',label:'Vérifier si Block Inheritance est activé sur l\'OU Compta',type:'BONNE_PISTE',
        consequence:'L\'OU Comptabilité a "Block Policy Inheritance" activé — les GPO parentes ne descendent pas même si correctement liées.',
        question_id:'gpo_inheritance'},
     ]},
    {id:'check_wmi',label:'Vérifier si un filtre WMI conditionne la GPO',type:'BONNE_PISTE',
     consequence:'Un filtre WMI limite la GPO aux postes Windows 11. Les postes compta sont sous Windows 10 — ils sont exclus.',
     follow_up:'Filtre WMI trop restrictif.',
     follow_up_actions:[
       {id:'fix_wmi',label:'Modifier ou supprimer le filtre WMI',type:'BONNE_PISTE',
        consequence:'Filtre supprimé. La GPO s\'applique maintenant à tous les systèmes Windows.',
        question_id:'gpo_wmi'},
     ]},
    {id:'delete_gpo',label:'Supprimer et recréer la GPO',type:'MAUVAISE_PISTE',malus:true,
     consequence:'La GPO est supprimée. Elle ne s\'applique plus nulle part. Le RSSI est alerté.'},
  ],
  resolution_ok:'GPO appliquée. Clés USB bloquées en compta. Le RSSI : "Juste à temps pour l\'audit."',
  resolution_fail:'GPO non appliquée. Audit de sécurité compromis.',
},

// ======= 11. Certificat SSL expiré =======
{
  id:'ssl', title:'TICKET #7788', prio:'P2 — URGENT',
  situation:'L\'intranet RH affiche "CONNEXION NON SÉCURISÉE" depuis ce matin. Les navigateurs bloquent l\'accès. 200 employés ne peuvent plus accéder aux outils RH en ligne.',
  actions:[
    {id:'check_cert',label:'Vérifier le certificat SSL dans le navigateur (F12)',type:'BONNE_PISTE',
     consequence:'Le certificat a expiré hier à 23h59. Il avait été émis il y a 2 ans. Aucune alerte d\'expiration n\'était configurée.',
     follow_up:'Expiration confirmée. Tu dois renouveler sans couper le service.',
     follow_up_actions:[
       {id:'check_ca',label:'Identifier l\'autorité de certification émettrice',type:'BONNE_PISTE',
        consequence:'C\'est un certificat Let\'s Encrypt (gratuit). Le renouvellement automatique Certbot a échoué car un port était fermé.',
        question_id:'ssl_renew'},
       {id:'check_iis_binding',label:'Vérifier les bindings HTTPS dans IIS',type:'BONNE_PISTE',
        consequence:'Le binding HTTPS pointe encore sur l\'ancien certificat expiré. Tu devras le mettre à jour après renouvellement.'},
       {id:'create_self_signed',label:'Créer un certificat auto-signé temporaire',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Les navigateurs affichent toujours un avertissement. Les utilisateurs doivent ajouter des exceptions. Mauvaise habitude de sécurité.'},
     ]},
    {id:'check_iis',label:'Vérifier la configuration IIS du site',type:'NEUTRE',
     consequence:'IIS est bien configuré, le site fonctionne. Le problème vient uniquement du certificat.'},
    {id:'exception',label:'Demander aux utilisateurs d\'ajouter des exceptions navigateur',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Mauvaise pratique. Le RSSI te contacte pour signaler que tu habitues les employés à ignorer les alertes SSL.'},
    {id:'check_chain',label:'Vérifier la chaîne de certification (CA intermédiaire)',type:'BONNE_PISTE',
     consequence:'La chaîne est complète et valide. Le problème est uniquement l\'expiration du certificat feuille.',
     direct_resolve:true},
  ],
  resolution_ok:'Certificat renouvelé et installé. Intranet accessible. Ton chef : "Configure une alerte pour la prochaine fois."',
  resolution_fail:'Intranet inaccessible 4h. Rapport d\'incident et plan de renouvellement automatique exigés.',
},

// ======= 12. Route manquante =======
{
  id:'routing', title:'TICKET #2098', prio:'P3 — CRITIQUE',
  situation:'Le site secondaire (192.168.2.0/24) ne communique plus avec le siège depuis une intervention hier soir. Les sauvegardes nocturnes ont échoué. Le DSI veut une résolution immédiate.',
  actions:[
    {id:'check_routes',label:'Vérifier la table de routage sur R1 (show ip route)',type:'BONNE_PISTE',
     consequence:'Aucune route vers 192.168.2.0/24. Elle a été supprimée lors de l\'intervention. La route vers 192.168.3.0/24 est aussi absente.',
     follow_up:'Routes manquantes identifiées. Tu dois les reconfigurer correctement.',
     follow_up_actions:[
       {id:'add_routes',label:'Ajouter les routes statiques manquantes',type:'BONNE_PISTE',
        consequence:'Les deux routes ajoutées. La communication inter-sites reprend. Les sauvegardes nocturnes de ce soir passeront.',
        question_id:'routing_static'},
       {id:'check_startup',label:'Comparer running-config et startup-config',type:'BONNE_PISTE',
        consequence:'La startup-config a les routes mais pas la running. L\'intervenant a oublié de faire "copy run start" après ses modifications.'},
       {id:'reload_config',label:'Charger la startup-config (reload)',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Le reload coupe le routeur 3 minutes et charge une startup-config incomplète. La situation empire.'},
     ]},
    {id:'ping_sites',label:'Tester la connectivité par pings progressifs (sites, routeurs)',type:'NEUTRE',
     consequence:'Ping vers 192.168.2.1 échoue depuis R1. Le problème est bien le routage sur R1, pas une panne physique.'},
    {id:'check_interfaces',label:'Vérifier l\'état des interfaces du routeur',type:'BONNE_PISTE',
     consequence:'Toutes les interfaces sont "up/up". Le problème est logiciel (table de routage), pas physique.',
     direct_resolve:true},
    {id:'check_acl_r',label:'Vérifier les ACL sur les interfaces du routeur',type:'BONNE_PISTE',
     consequence:'Les ACL n\'ont pas été modifiées. Elles ne bloquent pas le trafic inter-sites.',
     direct_resolve:true},
  ],
  resolution_ok:'Routes ajoutées. Communication rétablie. Sauvegardes OK. Ton chef : "Bien vu, rapide."',
  resolution_fail:'Communication coupée 6h supplémentaires. Sauvegardes J+1 aussi perdues.',
},

// ======= 13. Imprimante réseau =======
{
  id:'printer', title:'TICKET #4456', prio:'P1 — MOYEN',
  situation:'L\'imprimante réseau du plateau commercial (IP: 192.168.1.50) est inaccessible depuis ce matin. 15 commerciaux ne peuvent pas imprimer leurs contrats pour les rendez-vous du jour.',
  actions:[
    {id:'ping_printer',label:'Pinger l\'adresse IP de l\'imprimante',type:'BONNE_PISTE',
     consequence:'Ping timeout. L\'imprimante ne répond pas sur 192.168.1.50. Elle a soit changé d\'IP, soit est éteinte.',
     follow_up:'Pas de réponse sur l\'IP connue. Tu dois trouver la nouvelle IP ou vérifier l\'état physique.',
     follow_up_actions:[
       {id:'check_dhcp_leases',label:'Chercher le bail DHCP de l\'imprimante par son adresse MAC',type:'BONNE_PISTE',
        consequence:'Le bail DHCP montre que l\'imprimante a obtenu 192.168.1.87 suite au redémarrage du serveur DHCP hier. L\'IP a changé.',
        question_id:'printer_ip'},
       {id:'check_physical',label:'Vérifier physiquement si l\'imprimante est allumée',type:'BONNE_PISTE',
        consequence:'L\'imprimante est allumée et affiche une IP différente sur son écran : 192.168.1.87. Elle était en DHCP.'},
       {id:'scan_network',label:'Scanner le réseau pour trouver l\'imprimante (nmap ou Advanced IP Scanner)',type:'BONNE_PISTE',
        consequence:'L\'imprimante est détectée sur 192.168.1.87. Son adresse MAC confirme que c\'est bien la bonne imprimante.'},
     ]},
    {id:'check_spooler',label:'Vérifier le spouleur d\'impression sur les postes',type:'NEUTRE',
     consequence:'Le spouleur est actif. Le problème n\'est pas logiciel côté poste — c\'est l\'imprimante qui est injoignable.'},
    {id:'reinstall',label:'Réinstaller les pilotes d\'impression sur tous les postes',type:'MAUVAISE_PISTE',malus:true,
     consequence:'45 minutes sur 15 postes. L\'imprimante reste inaccessible car le vrai problème (IP changée) n\'est pas traité.'},
    {id:'check_switch_port',label:'Vérifier le port switch de l\'imprimante (show int)',type:'NEUTRE',
     consequence:'Le port switch est "up/up". La connexion physique est bonne. Le problème est l\'adresse IP.'},
    {id:'fix_ip',label:'Configurer une IP statique sur l\'imprimante',type:'BONNE_PISTE',
     consequence:'Via l\'interface web de l\'imprimante, tu configures 192.168.1.50 en statique. Tous les postes retrouvent l\'imprimante.',
     follow_up:'IP statique configurée. Il faut maintenant mettre à jour les postes.',
     follow_up_actions:[
       {id:'update_ports',label:'Mettre à jour le port d\'impression sur les postes',type:'BONNE_PISTE',
        consequence:'Les ports sont mis à jour. L\'impression fonctionne sur tous les postes.',
        question_id:'printer_static'},
       {id:'reservation',label:'Créer une réservation DHCP pour éviter le problème futur',type:'BONNE_PISTE',
        consequence:'Réservation DHCP créée. L\'imprimante aura toujours 192.168.1.50, même en DHCP.'},
     ]},
  ],
  resolution_ok:'Impression rétablie. Commerciaux opérationnels. Ton chef : "Bien diagnostiqué."',
  resolution_fail:'Sans impression pendant 2h. Contrats signés à la main. Manager RH mécontent.',
},

// ======= 14. Espace NAS saturé =======
{
  id:'backup', title:'TICKET #6670', prio:'P2 — MOYEN',
  situation:'L\'alerte supervision signale l\'échec des sauvegardes nocturnes. Motif : "Espace insuffisant sur le NAS". Le NAS affiche 100% utilisé.',
  actions:[
    {id:'check_nas',label:'Analyser l\'occupation par dossier sur le NAS',type:'BONNE_PISTE',
     consequence:'Tu identifies un dossier "VM-ARCHIVE-2023" de 800 Go qui correspond à une VM désaffectée il y a 3 mois. Jamais supprimé.',
     follow_up:'800 Go de données obsolètes identifiées. Tu dois décider comment procéder.',
     follow_up_actions:[
       {id:'confirm_obsolete',label:'Confirmer la désaffectation de la VM avec le responsable',type:'BONNE_PISTE',
        consequence:'Le DSI confirme par email que la VM peut être supprimée. Tu as le feu vert.',
        question_id:'backup_retention'},
       {id:'delete_direct',label:'Supprimer le dossier directement sans confirmation',type:'MAUVAISE_PISTE',malus:true,
        consequence:'Le dossier est supprimé. 2h plus tard, un développeur cherche des données de la VM. Elles étaient encore utilisées.'},
     ]},
    {id:'check_policy',label:'Vérifier la politique de rétention configurée',type:'BONNE_PISTE',
     consequence:'La politique dit "30 jours" mais le nettoyage automatique est désactivé. Les anciennes sauvegardes s\'accumulent sans jamais être supprimées.',
     follow_up:'Politique mal appliquée. Il faut corriger la configuration.',
     follow_up_actions:[
       {id:'enable_cleanup',label:'Activer la purge automatique dans l\'outil de sauvegarde',type:'BONNE_PISTE',
        consequence:'Purge automatique activée et lancée manuellement. 40% d\'espace libéré. Les sauvegardes peuvent reprendre.',
        direct_resolve:true},
       {id:'manual_cleanup',label:'Supprimer manuellement les sauvegardes de plus de 30 jours',type:'BONNE_PISTE',
        consequence:'350 Go libérés manuellement. Les sauvegardes ce soir passeront.',
        question_id:'backup_retention'},
     ]},
    {id:'add_disk',label:'Commander un disque supplémentaire pour le NAS',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Délai de 5 jours. Sauvegardes en échec d\'ici là. Ton chef : "T\'aurais pu libérer de l\'espace d\'abord."'},
    {id:'compress',label:'Lancer une compression des données existantes',type:'NEUTRE',
     consequence:'La compression est déjà activée. Les fichiers sont en format compressé. Pas de gain supplémentaire possible.'},
  ],
  resolution_ok:'Espace libéré. Sauvegardes reprennent. Ton chef : "Bien géré, maintenant c\'est automatique."',
  resolution_fail:'Sauvegardes en échec 3 nuits supplémentaires. Audit de conformité compromis.',
},

// ======= 15. ExecutionPolicy PowerShell =======
{
  id:'ps_policy', title:'TICKET #8823', prio:'P2 — MOYEN',
  situation:'Un développeur ne peut pas exécuter son script de déploiement mensuel. Erreur : "L\'exécution de scripts est désactivée sur ce système." Bloquer le déploiement = retard projet.',
  actions:[
    {id:'check_policy',label:'Vérifier l\'ExecutionPolicy actuelle (Get-ExecutionPolicy -List)',type:'BONNE_PISTE',
     consequence:'"MachinePolicy: Restricted" — une GPO impose cette politique. Ce n\'est pas un simple réglage local, c\'est une politique d\'entreprise.',
     follow_up:'GPO impose Restricted. Tu dois trouver un moyen d\'autoriser les scripts légitimes sans briser la politique.',
     follow_up_actions:[
       {id:'sign_script',label:'Proposer de signer le script numériquement (AllSigned)',type:'BONNE_PISTE',
        consequence:'Solution sécurisée mais longue. Il faut un certificat de signature de code et former le développeur.',
        question_id:'ps_remotesigned'},
       {id:'gpo_exception',label:'Créer une exception GPO pour le groupe Développeurs',type:'BONNE_PISTE',
        consequence:'Tu crées un filtre de sécurité sur la GPO pour exclure le groupe GRP-Devs. RemoteSigned s\'applique à leur place.',
        question_id:'ps_execution_policy'},
       {id:'bypass_local',label:'Changer localement avec Set-ExecutionPolicy Bypass',type:'MAUVAISE_PISTE',malus:true,
        consequence:'La GPO écrase le réglage local au prochain rafraîchissement. Bypass contourne toutes les protections — déconseillé.'},
     ]},
    {id:'check_gpo_ps',label:'Vérifier si une GPO contrôle l\'ExecutionPolicy',type:'BONNE_PISTE',
     consequence:'"gpresult /r" confirme qu\'une GPO "Hardening-Workstations" impose Restricted depuis la dernière mise à jour de sécurité.',
     follow_up:'GPO Hardening trouvée. Tu dois décider comment gérer l\'exception.',
     follow_up_actions:[
       {id:'scope_gpo',label:'Restreindre la portée de la GPO (exclure les devs)',type:'BONNE_PISTE',
        consequence:'La GPO n\'affecte plus les développeurs. Ils peuvent exécuter leurs scripts avec RemoteSigned.',
        direct_resolve:true},
       {id:'new_gpo',label:'Créer une GPO spécifique pour les développeurs',type:'BONNE_PISTE',
        consequence:'Nouvelle GPO liée à OU=Développeurs avec RemoteSigned. Propre et documenté.',
        question_id:'ps_execution_policy'},
     ]},
    {id:'run_admin',label:'Exécuter PowerShell en tant qu\'Administrateur',type:'NEUTRE',
     consequence:'Même en admin, la MachinePolicy Restricted bloque les scripts. Les droits admin et l\'ExecutionPolicy sont distincts.'},
    {id:'unrestricted',label:'Mettre l\'ExecutionPolicy à Unrestricted',type:'MAUVAISE_PISTE',malus:true,
     consequence:'Unrestricted exécute tous les scripts sans vérification. Le RSSI reçoit une alerte de configuration non conforme.'},
  ],
  resolution_ok:'Exception créée. Scripts de déploiement fonctionnels. Ton chef : "Bonne approche, équilibre sécurité/usage."',
  resolution_fail:'Déploiement bloqué. Applications non mises à jour. Retard projet signalé.',
},

]; // fin RPG_SCENARIOS_V2



var RPG = {
  CONF_GOOD_ACTION: 10,
  CONF_GOOD_ANSWER: 5,
  CONF_BAD_ANSWER: -5,
  CONF_BAD_PISTE: -10,
  scenarios: RPG_SCENARIOS_V2,
};

// Questions liees
var RPG_QUESTIONS = {
  winrm_port:{q:'Quel port WinRM utilise-t-il par defaut (HTTP) ?',opts:['Port 443','Port 5985','Port 3389','Port 8080'],a:1,x:'WinRM utilise le port 5985 (HTTP) ou 5986 (HTTPS). Le pare-feu doit autoriser ce port.'},
  winrm_trustedhosts:{q:'Quelle commande configure les TrustedHosts WinRM ?',opts:["Set-Item WSMan:\\localhost\\Client\\TrustedHosts -Value 'SRV-PROD'",'Add-WinRMHost -Name SRV-PROD','New-PSSession -TrustHost SRV-PROD','Enable-WSManCredSSP -Role Client'],a:0,x:'En workgroup, le client doit declarer les hotes distants dans TrustedHosts pour contourner labsence de Kerberos.'},
  winrm_enable:{q:'Que fait Enable-PSRemoting -Force ?',opts:['Active uniquement le service WinRM','Configure WinRM, cree les listeners et les regles pare-feu','Ouvre une session PowerShell distante','Ajoute lhote dans TrustedHosts'],a:1,x:'Enable-PSRemoting fait tout en une commande : WinRM, listeners HTTP/HTTPS et regles de pare-feu Windows.'},
  dns_service_restart:{q:'Comment redemarrer le service DNS Server en PowerShell ?',opts:['Restart-Service DNS','Start-Service dns-server','Restart-Service -Name DNS','Invoke-Command {Start DNS}'],a:2,x:'Restart-Service -Name DNS redémarre le service DNS Server Windows. Aliases : net stop DNS && net start DNS.'},
  dns_soa:{q:'Que contient un enregistrement SOA ?',opts:['Uniquement les adresses IP des hotes','Serveur DNS primaire, TTL, numero de serie et delais de replication','Les enregistrements MX et CNAME','La liste des serveurs secondaires'],a:1,x:'SOA = serveur DNS primaire, email admin, numero de serie (incremente a chaque modif), TTL, refresh/retry/expire.'},
  vlan_ip_routing:{q:'Quelle commande active le routage inter-VLAN sur un switch L3 Cisco ?',opts:['router ospf 1','ip routing','routing enable','switchport mode trunk'],a:1,x:"La commande 'ip routing' en mode config global active le moteur de routage IP. Sans elle, les SVIs ont des IPs mais ne routent pas."},
  vlan_svi:{q:'Comment activer une SVI Vlan20 en "down" ?',opts:['interface vlan 20 -> shutdown','vlan 20 -> state active','interface vlan 20 -> no shutdown','switchport mode access vlan 20'],a:2,x:"Une SVI desactivee se reactivee avec 'no shutdown'. Verifier aussi que le VLAN existe (show vlan brief)."},
  vlan_trunk:{q:'Comment ajouter le VLAN 20 aux VLANs autorises sur un trunk ?',opts:['switchport trunk allowed vlan add 20','vlan 20 allowed trunk','switchport access vlan 20','trunk vlan 20 permit'],a:0,x:"Le mot-cle 'add' est crucial — sans lui, la commande REMPLACE toute la liste au lieu d'ajouter."},
  hyperv_snapshot:{q:'Que faire avec des snapshots Hyper-V corrompus ?',opts:['Les supprimer depuis lExplorateur Windows','Les fusionner depuis le Gestionnaire Hyper-V','Recreer la VM','Les deplacer dans un autre dossier'],a:1,x:'Les snapshots (.avhdx) doivent etre geres depuis Hyper-V. La fusion integre les changements dans le VHDX parent.'},
  hyperv_disk_path:{q:'Comment modifier le chemin dun disque dans une VM Hyper-V ?',opts:['Modifier le fichier .vmcx','Via Parametres VM -> Disque dur -> Modifier le chemin','Set-VM -DiskPath','Deplacer le VHDX puis redemarrer'],a:1,x:'Dans Hyper-V Manager : Parametres VM -> selectionner disque -> modifier chemin. En PS : Set-VMHardDiskDrive -Path.'},
  ntfs_deny:{q:'Dans les permissions NTFS, Deny vs Allow ?',opts:['Allow est prioritaire','La plus recente gagne','Deny est toujours prioritaire sur Allow','Lheritage prend le dessus'],a:2,x:'Deny est TOUJOURS prioritaire sur Allow, quelle que soit lorigine (directe ou heritee).'},
  ntfs_group_deny:{q:'User dans GRP-RH (Allow) et GRP-STAGIAIRES (Deny). Resultat ?',opts:['Il peut lire car GRP-RH donne Allow','Il ne peut pas lire car le Deny prime','Les permissions sannulent','Depend de lordre des groupes'],a:1,x:"Deny prime toujours. Meme si GRP-RH accorde Allow, le Deny de GRP-STAGIAIRES l'emporte."},
  stp_bpduguard:{q:'Que fait BPDU Guard ?',opts:['Bloque tous les VLANs','Desactive le port (err-disabled) si une BPDU est recue','Force le port en Blocking','Augmente la priorite STP'],a:1,x:'BPDU Guard passe le port en err-disabled des quune BPDU est recue. Protege contre les switches non autorises.'},
  dhcp_scope:{q:'Action immediate pour un pool DHCP epuise ?',opts:['Redemarrer le service DHCP','Etendre la plage ou creer un nouveau scope','Supprimer tous les baux','Passer en adressage statique'],a:1,x:"Pour un pool epuise : etendre la plage, supprimer les baux obsoletes, ou creer un superscope."},
  dhcp_lease:{q:'Comment voir les baux actifs DHCP en PowerShell ?',opts:['Get-DhcpServerv4Lease -ScopeId 192.168.1.0','Show-DHCPLeases -Scope all','Get-NetIPAddress -DHCPEnabled','ipconfig /showclassid'],a:0,x:"Get-DhcpServerv4Lease -ScopeId liste les baux dun scope. Filtrer avec Where-Object pour les baux actifs."},
  cisco_ssh_rsa:{q:'Sequence pour generer des cles RSA pour SSH sur Cisco ?',opts:['Juste crypto key generate rsa','hostname -> ip domain-name -> crypto key generate rsa modulus 2048','enable secret -> crypto key','ip ssh version 2 -> crypto key'],a:1,x:"Ordre crucial : hostname (requis), ip domain-name (requis), puis crypto key generate rsa modulus 2048 (min 768 bits pour SSHv2)."},
  cisco_ssh_vty:{q:'Comment autoriser uniquement SSH sur les lignes VTY ?',opts:['transport input ssh only','transport input ssh','no transport input telnet','line vty 0 4 -> ssh enable'],a:1,x:"'transport input ssh' autorise uniquement SSH. Si 'transport input telnet' vient apres, il ecrase la regle precedente."},
  cisco_acl:{q:'Comment retirer une entree dune ACL nommee Cisco ?',opts:["no ip access-list extended MGMT deny tcp any any eq 22",'ip access-list extended MGMT -> no [numero de sequence]','delete acl MGMT rule 22','ip access-list remove MGMT deny 22'],a:1,x:"Dans une ACL nommee : entrer dans son mode config puis supprimer par numero de sequence (visible avec 'show ip access-lists')."},
  cisco_ssh_domain:{q:'Sans ip domain-name, que se passe-t-il en generant des cles RSA ?',opts:['Les cles sont generees avec un nom par defaut','Erreur : You must specify a key name','SSH fonctionne sans domaine','Cisco utilise lhostname automatiquement'],a:1,x:"Sans ip domain-name, Cisco ne peut pas nommer les cles RSA (nom = hostname.domaine). La commande echoue."},
  ad_enable_account:{q:"Comment reactiver un compte AD desactive en PowerShell ?",
    opts:["Enable-ADAccount -Identity nomutilisateur","Set-ADUser -Enabled $true","Unlock-ADAccount -Identity nomutilisateur","Start-ADAccount -Name nomutilisateur"],
    a:0,x:"Enable-ADAccount -Identity reactive un compte desactive. Unlock-ADAccount deverrouille un compte verrouille (lockout). Les deux operations sont differentes."},
  ad_unlock:{q:"Quelle commande deverrouille un compte AD verrouille apres trop de tentatives ?",
    opts:["Enable-ADAccount","Reset-ADPassword","Unlock-ADAccount -Identity nomutilisateur","Clear-ADAccountLockout"],
    a:2,x:"Unlock-ADAccount deverrouille un compte sans changer son etat active/desactive. Get-ADUser -Properties LockedOut permet de verifier letat de verrouillage."},
  gpo_gpresult:{q:"Que fait la commande gpresult /r /scope computer ?",
    opts:["Redemarre le service Group Policy","Affiche les GPO appliquees a lordinateur et a lutilisateur","Force la mise a jour des GPO","Reinitialise les parametres GPO"],
    a:1,x:"gpresult /r affiche un resume des GPO appliquees. /scope computer limite aux GPO ordinateur. gpresult /h fichier.html genere un rapport HTML complet."},
  gpo_link:{q:"Dans la GPMC, ou faut-il lier une GPO pour quelle sapplique a une OU ?",
    opts:["Au niveau du domaine uniquement","Sur lOU cible ou une OU parente si lheritage nest pas bloque","Sur le controleur de domaine","Dans les parametres de la GPO"],
    a:1,x:"Une GPO doit etre liee (Link) a lOU, au site ou au domaine cible. Si liee a une OU parente, elle descend vers les OU enfants sauf si Block Inheritance est active sur lOU enfant."},
  gpo_wmi:{q:"Un filtre WMI sur une GPO permet de :",
    opts:["Chiffrer les parametres de la GPO","Appliquer la GPO uniquement aux machines verifiant une condition WMI OS RAM etc","Deleguer ladministration de la GPO","Forcer la reapplication des parametres"],
    a:1,x:"Les filtres WMI conditionnent lapplication dune GPO a une requete WMI. Ex: SELECT * FROM Win32_OperatingSystem WHERE Version LIKE 10.0.22% cible Windows 11 uniquement."},
  gpo_inheritance:{q:"Que fait Block Policy Inheritance sur une OU ?",
    opts:["Empeche les modifications de GPO","Bloque la descente des GPO liees aux OU parentes","Desactive toutes les GPO","Protege lOU contre la suppression"],
    a:1,x:"Block Policy Inheritance empeche les GPO liees aux niveaux superieurs de sapplique a cette OU. Les GPO liees directement a lOU restent actives."},
  ssl_renew:{q:"Quelle est la duree maximale dun certificat SSL/TLS public depuis 2020 ?",
    opts:["5 ans","3 ans","2 ans soit 398 jours","1 an"],
    a:2,x:"Depuis 2020, les certificats publics sont limites a 398 jours environ 13 mois. Apple Mozilla et Google ont impose cette limite. En 2025 la tendance va vers 90 jours."},
  routing_static:{q:"Quelle commande ajoute une route statique vers 192.168.2.0/24 via 10.0.0.2 sur Cisco ?",
    opts:["route add 192.168.2.0/24 via 10.0.0.2","ip route 192.168.2.0 255.255.255.0 10.0.0.2","add route 192.168.2.0 255.255.255.0 10.0.0.2","static route 192.168.2.0/24 10.0.0.2"],
    a:1,x:"ip route reseau masque next-hop. La route par defaut : ip route 0.0.0.0 0.0.0.0 next-hop. Verifier avec show ip route."},
  printer_ip:{q:"Pourquoi une imprimante en DHCP peut-elle changer dadresse ?",
    opts:["Les imprimantes changent toujours dIP au demarrage","Le serveur DHCP peut attribuer une nouvelle adresse si le bail expire ou si le serveur redemarre","Les imprimantes ne supportent pas les adresses fixes","Le protocole SNMP modifie les adresses"],
    a:1,x:"En DHCP, le bail a une duree limitee. Si le bail expire ou si le serveur redemarre, lequipement peut obtenir une nouvelle adresse. Les imprimantes doivent avoir une IP fixe ou une reservation DHCP."},
  printer_static:{q:"Quelle est la meilleure pratique pour une imprimante reseau partagee ?",
    opts:["DHCP avec bail court","IP statique sur limprimante ou reservation DHCP","APIPA 169.254.x.x","Changer lIP chaque mois"],
    a:1,x:"Une imprimante partagee doit avoir une IP stable. Deux options : IP statique dans linterface web ou reservation DHCP meme IP toujours attribuee au meme MAC. La reservation DHCP est preferable car centralisee."},
  backup_retention:{q:"Quelle est la regle 3-2-1 pour les sauvegardes ?",
    opts:["3 copies 2 supports differents 1 copie hors site","3 sauvegardes par jour 2 par semaine 1 par mois","3 jours de retention 2 semaines 1 mois","3 disques 2 NAS 1 cloud"],
    a:0,x:"La regle 3-2-1 : 3 copies des donnees sur 2 types de supports differents disque NAS tape dont 1 copie hors site cloud ou autre batiment. Protege contre panne materie sinistre et ransomware."},
  ps_execution_policy:{q:"Quelle commande verifie lExecutionPolicy PowerShell actuelle ?",
    opts:["Show-ExecutionPolicy","Get-ExecutionPolicy -List","Check-PSPolicy","Get-PSExecutionPolicy"],
    a:1,x:"Get-ExecutionPolicy -List affiche la policy a chaque niveau MachinePolicy UserPolicy Process CurrentUser LocalMachine. La policy effective est la plus restrictive."},
  ps_remotesigned:{q:"Que fait Set-ExecutionPolicy RemoteSigned ?",
    opts:["Bloque tous les scripts","Autorise tous les scripts sans restriction","Autorise les scripts locaux non signes et exige la signature pour les scripts telecharges","Exige que tous les scripts soient signes"],
    a:2,x:"RemoteSigned : scripts locaux OK sans signature. Scripts depuis Internet signature requise. Cest le bon equilibre pour un developpeur. AllSigned exige la signature pour tous. Unrestricted autorise tout deconseille."},

};


// =====================================================
// MOTEUR RPG NARRATIF
// =====================================================
var rpgN={confidence:50,ticketIdx:0,ticketsPerSession:5,ticketOrder:[],triedActions:{},actOrder:{},stats:{ok:0,fail:0},questionAnswered:false,currentTicket:null};

function startRPGNarrative(){
  // Thème Paper automatique
  document.body.classList.remove('ui-arcade','ui-terminal','ui-minimal');
  document.body.classList.add('ui-paper','rpg-mode');
  // Init état
  rpgN.confidence=50;rpgN.ticketIdx=0;rpgN.stats={ok:0,fail:0};
  rpgN.triedActions={};rpgN.actOrder={};rpgN.questionAnswered=false;rpgN.currentTicket=null;
  rpgN.jokers=1;rpgN.questionAnswered=false;
  // Sélectionner les tickets aléatoirement
  var arr=RPG.scenarios.map(function(_,i){return i;});
  rpgN.ticketOrder=shuffle(arr).slice(0,rpgN.ticketsPerSession||5);
  // Afficher le bon écran D'ABORD
  showScreen('rpg-narrative');
  // PUIS initialiser les éléments DOM (qui existent maintenant)
  requestAnimationFrame(function(){
    rpgInitBonuses();
    rpgUpdateBar();
    rpgUpdateJokerDisplay();
    rpgShowTicket();
  });
}

function rpgStartAfterIntro(){
  showScreen('rpg-narrative');
  rpgUpdateBar();
  rpgInitBonus();
  rpgShowTicket();
}

function rpgShowTicket(){
  rpgUpdateBar(); // forcer sync barre au début de chaque ticket
  if(rpgN.ticketIdx>=rpgN.ticketOrder.length){rpgEndSession();return;}
  var sc=RPG.scenarios[rpgN.ticketOrder[rpgN.ticketIdx]];
  rpgN.currentTicket=sc;
  rpgN.questionAnswered=false;
  if(!rpgN.triedActions[sc.id]) rpgN.triedActions[sc.id]=[];
  if(!rpgN.actOrder[sc.id]) rpgN.actOrder[sc.id]=shuffle(sc.actions.map(function(_,i){return i;}));

  // Générer heure fictive et code barre
  var hh=String(Math.floor(Math.random()*4)+8).padStart(2,'0');
  var mm=String(Math.floor(Math.random()*60)).padStart(2,'0');
  var timeEl=document.getElementById('rpg-ticket-time');
  if(timeEl) timeEl.textContent=hh+':'+mm;
  var bcEl=document.getElementById('rpg-barcode');
  if(bcEl){
    // Générer un "numéro de série" visuel à partir du seed du scénario
    var bcSeed=sc.id.split('').reduce(function(a,c){return a+c.charCodeAt(0)%10;},0);
    var serial='REF-'+sc.id.toUpperCase().slice(0,3)+'-'+String(bcSeed*137+4471).slice(0,4);
    bcEl.textContent=serial+' ··· SERVICE IT ··· PRIORITÉ: '+(sc.title.split('Niveau ')[1]||'P2');
  }
  // Topbar
  var rpgProg=document.getElementById('rpg-prog');if(rpgProg)rpgProg.textContent='TICKET '+(rpgN.ticketIdx+1)+'/'+rpgN.ticketOrder.length;
  rpgUpdateBadge();
  rpgUpdateJokerDisplay();
  // Afficher bonus slot
  var bslot=document.getElementById('rpg-bonus-slot');
  if(bslot) bslot.className=rpgBonusPool&&rpgBonusPool.filter(function(b){return!b.used;}).length>0?'rpg-bonus-slot show':'rpg-bonus-slot';
  // Fermer menu bonus si ouvert
  rpgBonusMenuOpen=false;var bm=document.getElementById('rpg-bonus-menu');if(bm)bm.className='rpg-bonus-menu';

  // Narrative
  var narEl=document.getElementById('rpg-narrative-text');
  narEl.textContent='Nouveau ticket entrant...';narEl.style.color='';narEl.style.borderLeftColor='';

  // Ticket
  var rpgTNum=document.getElementById('rpg-ticket-num');if(rpgTNum)rpgTNum.textContent=sc.title.split(' — ')[0];
  var rpgTPrio=document.getElementById('rpg-ticket-prio');if(rpgTPrio)rpgTPrio.textContent=sc.title.split(' — ')[1]||'URGENT';
  var rpgTSit=document.getElementById('rpg-ticket-sit');if(rpgTSit)rpgTSit.textContent=sc.situation;

  // Switch to ticket view
  rpgShowView('ticket');
  rpgRenderActions(sc);
}

function rpgRenderActions(sc){
  var grid=document.getElementById('rpg-actions');
  if(!grid) return;
  grid.innerHTML='';
  var tried=rpgN.triedActions[sc.id]||[];
  var order=rpgN.actOrder[sc.id]||sc.actions.map(function(_,i){return i;});
  var keys=['A','B','C','D','E','F'];
  order.forEach(function(aIdx,ki){
    var action=sc.actions[aIdx];
    var isTried=tried.indexOf(action.id)>-1;
    var btn=document.createElement('button');
    btn.className='rpg-action-btn'+(isTried?' tried':'');
    btn.disabled=isTried;
    btn.innerHTML='<span class="rpg-action-key">'+keys[ki]+'</span><span>'+action.label+'</span>';
    if(!isTried){
      (function(a){btn.onclick=function(){playClickSoft();rpgPickAction(a);};})(action);
    }
    grid.appendChild(btn);
  });
}

function rpgPickAction(action, isFollowUp){
  playClick();
  var sc=rpgN.currentTicket;
  if(!isFollowUp){
    if(!rpgN.triedActions[sc.id]) rpgN.triedActions[sc.id]=[];
    rpgN.triedActions[sc.id].push(action.id);
  }

  rpgShowView('action');

  var resHeader=document.getElementById('rpg-result-header');
  var resText=document.getElementById('rpg-result-text');
  var subchoices=document.getElementById('rpg-subchoices');
  var inlineQ=document.getElementById('rpg-inline-q');
  var resolution=document.getElementById('rpg-resolution');
  var nextBtn=document.getElementById('rpg-next-btn');

  if(resHeader) resHeader.textContent='→ '+action.label;
  if(subchoices) subchoices.style.display='none';
  if(inlineQ) inlineQ.style.display='none';
  if(resolution) resolution.style.display='none';
  if(nextBtn){nextBtn.className='rpg-next-btn';nextBtn.style.background='';nextBtn.style.borderColor='';nextBtn.style.color='';}

  // ── MAUVAISE PISTE ──
  if(action.type==='MAUVAISE_PISTE'&&action.malus){
    if(resText){resText.textContent=action.consequence;resText.className='rpg-result-text bad';}
    rpgChangeConf(RPG.CONF_BAD_PISTE);
    if(nextBtn){
      nextBtn.textContent='← REVENIR AUX ACTIONS';
      nextBtn.className='rpg-next-btn show';
      nextBtn.onclick=function(){rpgShowView('ticket');rpgRenderActions(sc);};
    }

  // ── NEUTRE ──
  } else if(action.type==='NEUTRE'){
    if(resText){resText.textContent=action.consequence;resText.className='rpg-result-text neutral';}
    if(nextBtn){
      nextBtn.textContent='← REVENIR AUX ACTIONS';
      nextBtn.className='rpg-next-btn show';
      nextBtn.onclick=function(){rpgShowView('ticket');rpgRenderActions(sc);};
    }

  // ── BONNE PISTE ──
  } else if(action.type==='BONNE_PISTE'){
    if(resText){resText.textContent=action.consequence;resText.className='rpg-result-text good';}
    rpgChangeConf(RPG.CONF_GOOD_ACTION);

    // Si des sous-actions (niveau 2)
    if(action.follow_up_actions&&action.follow_up_actions.length){
      // Afficher narrative de suite
      var narEl=document.getElementById('rpg-narrative-text');
      if(narEl&&action.follow_up){narEl.textContent=action.follow_up;narEl.style.color='#4a6030';}
      // Afficher les sous-actions
      if(nextBtn){
        nextBtn.textContent='APPROFONDIR →';
        nextBtn.className='rpg-next-btn show';
        nextBtn.style.background='#3a3010';
        nextBtn.style.borderColor='#a07820';
        nextBtn.style.color='#d4a830';
        (function(subActions){
          nextBtn.onclick=function(){
            nextBtn.className='rpg-next-btn';
            nextBtn.style.background='';nextBtn.style.borderColor='';nextBtn.style.color='';
            rpgRenderFollowUpActions(subActions,sc,resolution,inlineQ,nextBtn);
          };
        })(action.follow_up_actions);
      }

    // Si direct_resolve
    } else if(action.direct_resolve){
      rpgN.stats.ok++;
      if(nextBtn){
        nextBtn.textContent='✓ VOIR LA RÉSOLUTION →';
        nextBtn.className='rpg-next-btn show';
        nextBtn.onclick=function(){
          nextBtn.className='rpg-next-btn';
          rpgShowResolutionPanel(true,sc,resolution,nextBtn);
        };
      }

    // Si question
    } else if(action.question_id){
      rpgN.stats.ok++;
      if(nextBtn){
        nextBtn.textContent='✓ VOIR LA RÉSOLUTION →';
        nextBtn.className='rpg-next-btn show';
        nextBtn.onclick=function(){
          nextBtn.className='rpg-next-btn';
          rpgShowResolutionPanel(true,sc,resolution,nextBtn,action.question_id,inlineQ);
        };
      }

    } else {
      rpgN.stats.ok++;
      if(nextBtn){
        nextBtn.textContent='✓ VOIR LA RÉSOLUTION →';
        nextBtn.className='rpg-next-btn show';
        nextBtn.onclick=function(){
          nextBtn.className='rpg-next-btn';
          rpgShowResolutionPanel(true,sc,resolution,nextBtn);
        };
      }
    }
  }
}

function rpgRenderFollowUpActions(subActions,sc,resolution,inlineQ,nextBtn){
  var subchoices=document.getElementById('rpg-subchoices');
  var grid=document.getElementById('rpg-subchoice-list');
  if(!subchoices||!grid) return;
  subchoices.style.display='flex';
  grid.innerHTML='';
  var keys=['A','B','C','D'];
  var triedSubs=[];
  subActions.forEach(function(sa,ki){
    var isTried=triedSubs.indexOf(sa.id)>-1;
    var btn=document.createElement('button');
    btn.className='rpg-action-btn'+(isTried?' tried':'');
    btn.disabled=isTried;
    btn.innerHTML='<span class="rpg-action-key">'+(keys[ki]||'?')+'</span><span>'+sa.label+'</span>';
    if(!isTried){
      (function(sub){
        btn.onclick=function(){
          triedSubs.push(sub.id);
          btn.className='rpg-action-btn tried';btn.disabled=true;
          // Ajouter la conséquence sous la liste
          var extra=document.createElement('div');
          extra.className='rpg-result-text '+(sub.type==='BONNE_PISTE'?'good':sub.type==='MAUVAISE_PISTE'?'bad':'neutral');
          extra.style.marginTop='8px';
          extra.textContent=sub.consequence;
          grid.after(extra);

          if(sub.type==='MAUVAISE_PISTE'&&sub.malus){
            rpgChangeConf(RPG.CONF_BAD_PISTE);
            // Reste sur les sous-actions
          } else if(sub.type==='BONNE_PISTE'){
            rpgChangeConf(RPG.CONF_GOOD_ACTION);
            rpgN.stats.ok++;
            // Masquer les autres sous-actions
            subchoices.style.display='none';
            // Afficher résolution
            if(nextBtn){
              nextBtn.textContent='✓ VOIR LA RÉSOLUTION →';
              nextBtn.className='rpg-next-btn show';
              nextBtn.style.background='';nextBtn.style.borderColor='';nextBtn.style.color='';
              (function(qid){
                nextBtn.onclick=function(){
                  nextBtn.className='rpg-next-btn';
                  rpgShowResolutionPanel(true,sc,resolution,nextBtn,qid,inlineQ);
                };
              })(sub.question_id);
            }
          }
        };
      })(sa);
    }
    grid.appendChild(btn);
  });
}


// Affiche la résolution du ticket, PUIS (si question_id) propose la question bonus
function rpgShowResolutionPanel(ok,sc,resolution,nextBtn,questionId,inlineQ){
  if(!resolution) return;
  resolution.style.display='block';
  resolution.className='rpg-resolution '+(ok?'ok':'fail');
  var lbl=document.getElementById('rpg-resolution-label');
  var txt=document.getElementById('rpg-resolution-text');
  if(lbl) lbl.textContent=ok?'✓ TICKET RÉSOLU':'✗ INCIDENT AGGRAVÉ';
  if(txt) txt.textContent=ok?sc.resolution_ok:sc.resolution_fail;

  // Notification barre de confiance (déjà faite dans rpgChangeConf)

  // Mettre à jour la narrative
  var narEl=document.getElementById('rpg-narrative-text');
  if(narEl){
    narEl.textContent=ok?sc.resolution_ok:sc.resolution_fail;
    narEl.style.color=ok?'#6a8a50':'#8a3020';
    narEl.style.borderLeftColor=ok?'#4a7a30':'#8b3020';
  }

  // Vérifier fin de partie
  if(rpgN.confidence<=0){setTimeout(function(){rpgEndSession(true);},1800);return;}
  if(rpgN.confidence>=100){setTimeout(function(){rpgEndSession(false,true);},1800);return;}

  // Bouton selon s'il y a une question bonus
  if(questionId&&inlineQ&&!rpgN.questionAnswered){
    if(nextBtn){
      nextBtn.textContent='🔎 QUESTION BONUS DE COMPRÉHENSION →';
      nextBtn.className='rpg-next-btn show';
      nextBtn.style.background='#4a3a10';
      nextBtn.style.borderColor='#d97706';
      nextBtn.style.color='#fbbf24';
      (function(qid){
        nextBtn.onclick=function(){
          nextBtn.className='rpg-next-btn';
          nextBtn.style.background='';nextBtn.style.borderColor='';nextBtn.style.color='';
          rpgShowInlineQuestion(qid,inlineQ,null,nextBtn,sc);
        };
      })(questionId);
    }
  } else {
    rpgShowNextTicketBtn(nextBtn);
  }
}

function rpgShowNextTicketBtn(nextBtn){
  if(!nextBtn) return;
  nextBtn.textContent=rpgN.ticketIdx+1<rpgN.ticketOrder.length?'TICKET SUIVANT ▶':'VOIR LES RÉSULTATS ▶';
  nextBtn.className='rpg-next-btn show';
  nextBtn.style.background='';nextBtn.style.borderColor='';nextBtn.style.color='';
  nextBtn.onclick=function(){
    rpgN.ticketIdx++;rpgN.questionAnswered=false;rpgN.currentTicket=null;
    var narEl=document.getElementById('rpg-narrative-text');
    if(narEl){narEl.style.color='';narEl.style.borderLeftColor='';}
    rpgShowTicket();
  };
}


function rpgShowInlineQuestion(qid,inlineQ,resolution,nextBtn,sc){
  var qdata=RPG_QUESTIONS[qid];
  if(!qdata||rpgN.questionAnswered) return;
  if(!inlineQ) return;
  inlineQ.style.display='block';
  // Label style "as-tu bien compris ?"
  var lbl=document.getElementById('rpg-inline-q-label');
  if(lbl) lbl.textContent='🎓 AS-TU BIEN COMPRIS ? (bonus confiance si correct)';
  document.getElementById('rpg-inline-q-text').textContent=qdata.q;
  // Bouton PASSER (skip la question)
  // Vider le skip btn précédent si présent
  var qbox=document.getElementById('rpg-inline-q');
  if(qbox){
    var oldSkip=qbox.querySelector('.rpg-skip-btn');
    if(oldSkip) oldSkip.remove();
    var skipBtn=document.createElement('button');
    skipBtn.className='rpg-skip-btn';
    skipBtn.textContent='PASSER →';
    skipBtn.style.cssText='float:right;background:none;border:1px dashed #8a7a5a;color:#8a7a5a;font-family:Courier New,monospace;font-size:9px;padding:3px 8px;cursor:pointer;margin-bottom:8px;';
    skipBtn.onclick=function(){
      if(inlineQ) inlineQ.style.display='none';
      rpgShowNextTicketBtn(nextBtn);
    };
    qbox.insertBefore(skipBtn,qbox.firstChild);
  }
  var expl=document.getElementById('rpg-inline-expl');
  if(expl){expl.textContent=qdata.x;expl.className='rpg-inline-expl';}
  var optsEl=document.getElementById('rpg-inline-opts');
  optsEl.innerHTML='';
  var shuffled=shuffle(qdata.opts.map(function(t,i){return{t:t,i:i};}));
  ['A','B','C','D'].forEach(function(k,i){
    if(!shuffled[i]) return;
    var b=document.createElement('button');
    b.className='rpg-inline-opt';
    b.innerHTML='<span style="font-weight:bold;margin-right:8px;">'+k+'.</span><span>'+shuffled[i].t+'</span>';
    var isOk=shuffled[i].i===qdata.a;
    (function(btn,correct){
      btn.onclick=function(){
        if(rpgN.questionAnswered) return;
        rpgN.questionAnswered=true;
        optsEl.querySelectorAll('.rpg-inline-opt').forEach(function(x,xi){
          x.disabled=true;
          if(shuffled[xi]&&shuffled[xi].i===qdata.a) x.classList.add('ok');
        });
        btn.classList.add(correct?'ok':'err');
        if(expl) expl.className='rpg-inline-expl show';
        // Question bonus : pas d'impact sur la barre
        // Si correct → +1 joker
        if(correct){
          rpgN.jokers=(rpgN.jokers||0)+1;
          rpgUpdateJokerDisplay();
          // Toast joker
          var jt=document.createElement('div');
          jt.style.cssText='position:fixed;top:60px;left:50%;transform:translateX(-50%);background:#4a7a20;color:#fef3c7;font-family:Courier New,monospace;font-size:11px;padding:8px 16px;border:2px solid #2a5a10;z-index:990;box-shadow:3px 3px 0 #1a4008;letter-spacing:1px;';
          jt.textContent='🃏 +1 JOKER GAGNÉ !';
          document.body.appendChild(jt);
          setTimeout(function(){if(jt.parentNode)jt.remove();},2000);
        }
        // Toujours afficher le bouton ticket suivant
        rpgShowNextTicketBtn(nextBtn);
      };
    })(b,isOk);
    optsEl.appendChild(b);
  });
}

function rpgShowResolution(ok,sc,resolution,nextBtn){
  if(!resolution) return;
  resolution.style.display='block';
  resolution.className='rpg-resolution '+(ok?'ok':'fail');
  var lbl=document.getElementById('rpg-resolution-label');
  var txt=document.getElementById('rpg-resolution-text');
  if(lbl) lbl.textContent=ok?'✓ TICKET RÉSOLU':'✗ INCIDENT AGGRAVÉ';
  if(txt) txt.textContent=ok?sc.resolution_ok:sc.resolution_fail;

  // Mettre à jour narrative en haut
  var narEl=document.getElementById('rpg-narrative-text');
  if(narEl){narEl.textContent=ok?sc.resolution_ok:sc.resolution_fail;narEl.style.color=ok?'#00a85a':'#dc2626';narEl.style.borderLeftColor=ok?'#00a85a':'#dc2626';}

  if(rpgN.confidence<=0){setTimeout(function(){rpgEndSession(true);},1800);return;}
  if(rpgN.confidence>=100){setTimeout(function(){rpgEndSession(false,true);},1800);return;}

  if(nextBtn){
    nextBtn.textContent=rpgN.ticketIdx+1<rpgN.ticketOrder.length?'TICKET SUIVANT ▶':'VOIR LES RÉSULTATS ▶';
    nextBtn.className='rpg-next-btn show';
    nextBtn.onclick=function(){
      rpgN.ticketIdx++;rpgN.questionAnswered=false;rpgN.currentTicket=null;
      rpgShowTicket();
    };
  }
}

function rpgGoBack(){
  // Retour vers la vue ticket depuis la vue action
  var vt=document.getElementById('rpg-view-ticket');
  var va=document.getElementById('rpg-view-action');
  if(va&&va.classList.contains('active')){
    rpgShowView('ticket');
    rpgRenderActions(rpgN.currentTicket);
  } else {
    rpgQuit();
  }
}

function rpgShowView(which){
  // S'assurer que l'écran RPG est actif avant de manipuler ses enfants
  var rpgScreen=document.getElementById('screen-rpg-narrative');
  if(!rpgScreen||!rpgScreen.classList.contains('active')) return;
  var vt=document.getElementById('rpg-view-ticket');
  var va=document.getElementById('rpg-view-action');
  var backBtn=document.getElementById('rpg-back-btn');
  if(which==='ticket'){
    if(vt) vt.classList.add('active');
    if(va) va.classList.remove('active');
    if(backBtn) backBtn.textContent='◀ QUITTER';
  } else {
    if(vt) vt.classList.remove('active');
    if(va) va.classList.add('active');
    if(backBtn) backBtn.textContent='◀ RETOUR';
  }
  if(rpgScreen) rpgScreen.scrollTop=0;
  window.scrollTo(0,0);
}

function rpgChangeConf(delta){
  rpgN.confidence=Math.max(0,Math.min(100,rpgN.confidence+delta));
  if(delta>0)playConfUp();else if(delta<0)playConfDown();
  rpgUpdateBar(delta);
}

function rpgUpdateBar(delta){
  requestAnimationFrame(function(){
    var screen=document.getElementById('screen-rpg-narrative');
    if(!screen) return; // écran pas dans le DOM
    var fill=document.getElementById('rpg-trust-fill');
    var pct=document.getElementById('rpg-trust-pct');
    if(fill) fill.style.width=Math.round(rpgN.confidence)+'%';
    if(pct) pct.textContent=Math.round(rpgN.confidence)+'%';
    if(delta&&delta!==0){
      var ind=document.getElementById('rpg-conf-delta');
      if(ind){
        ind.textContent=(delta>0?'+':'')+delta;
        ind.className='';
        void ind.offsetWidth;
        ind.className='rpg-conf-delta '+(delta>0?'show-up':'show-down');
        // sons gérés dans rpgChangeConf
        setTimeout(function(){var i2=document.getElementById('rpg-conf-delta');if(i2)i2.className='rpg-conf-delta';},1800);
      }
    }
    rpgUpdateBadge();
  });
}

function rpgUpdateJokerDisplay(){
  var jc=document.getElementById('rpg-joker-count');
  if(jc) jc.textContent='🃏 '+(rpgN.jokers||0)+' JOKER'+(rpgN.jokers>1?'S':'');
}
function rpgUpdateBadge(){
  var b=document.getElementById('rpg-badge');
  if(!b) return;
  var c=rpgN.confidence;
  if(c>=80){b.textContent='EXPERT ★';b.style.color='#fbbf24';}
  else if(c>=60){b.textContent='CONFIRMÉ';b.style.color='#00a85a';}
  else if(c>=40){b.textContent='TECHNICIEN';b.style.color='#c8bc9a';}
  else if(c>=20){b.textContent='EN DIFFICULTÉ';b.style.color='#ff9800';}
  else{b.textContent='CRITIQUE';b.style.color='#dc2626';}
}

function rpgEndSession(fired,promoted){
  document.body.classList.remove('rpg-mode');
  currentUI=lsGet('tssr5_ui','ui-arcade');
  // Afficher l'écran de fin avec fond paper forcé via CSS inline
  document.querySelectorAll('.screen').forEach(function(s){s.style.display='none';s.classList.remove('active');});
  var endScreen=document.getElementById('screen-rpg-end');
  if(endScreen){endScreen.style.display='flex';endScreen.classList.add('active');}

  var title=promoted?'PROMOTION !':fired?'LICENCIÉ...':rpgN.stats.ok>=rpgN.stats.fail?'MISSION ACCOMPLIE':'SESSION DIFFICILE';
  var col=promoted?'#8b1a1a':fired?'#8b1a1a':rpgN.stats.ok>=rpgN.stats.fail?'#2a5a10':'#6a1a08';
  var sub=promoted?'Confiance maximale. Ton chef te propose une promotion au poste de chef de projet.':
    fired?'Trop derreurs. Rends ton badge.':
    rpgN.confidence>=60?'Bon travail. Quelques points a ameliorer.':
    'Session difficile. Revois les points rates.';

  var t=document.getElementById('rpg-end-title'); if(t){t.textContent=title;t.style.color=col;}
  var s=document.getElementById('rpg-end-sub'); if(s) s.textContent=sub;
  var c=document.getElementById('rpg-end-conf'); if(c){c.textContent=rpgN.confidence+'%';c.style.color=col;}
  var ok=document.getElementById('rpg-end-ok'); if(ok) ok.textContent=rpgN.stats.ok;
  var fa=document.getElementById('rpg-end-fail'); if(fa) fa.textContent=rpgN.stats.fail;

  // Cacher les éléments RPG
  var bslot=document.getElementById('rpg-bonus-slot');if(bslot)bslot.className='rpg-bonus-slot';
  var bm=document.getElementById('rpg-bonus-menu');if(bm)bm.className='rpg-bonus-menu';
  var tb=document.getElementById('rpg-trust-bar');if(tb)tb.style.display='none';
}

function rpgQuit(){
  document.body.classList.remove('rpg-mode');
  var bb=document.getElementById('rpg-bonus-btn');if(bb) bb.style.display='none';
  var bm=document.getElementById('rpg-bonus-menu');if(bm) bm.classList.remove('show');
  var lex=document.getElementById('rpg-lexique');if(lex) lex.remove();
  goMenu();
}

function rpgNextTicket(){/* handled inline */}


// =====================================================
// =====================================================
// LAUNCH WIZARD
// =====================================================
var wizSelCats=['mix'];
var selDiff='all';

function openLaunchSheet(){
  var ovl=document.getElementById('launch-ovl');
  if(!ovl) return;
  selMode=selMode||'chill';
  // Reset to step 1
  wizShowStep(1);
  buildSheetCats();
  ovl.classList.add('open');
}

function closeLaunchSheet(e){
  if(e&&e.target!==document.getElementById('launch-ovl')) return;
  var ovl=document.getElementById('launch-ovl');
  if(ovl) ovl.classList.remove('open');
}

function wizShowStep(n){
  [1,2,3].forEach(function(i){
    var s=document.getElementById('wiz-step-'+i);
    if(s) s.style.display=(i===n)?'block':'none';
  });
}

function wizNext(step){
  if(step===2){
    if(!wizSelCats||!wizSelCats.length){wizSelCats=['mix'];}
    buildSheetModes();
  }
  wizShowStep(step);
}

function wizLaunch(){
  var ovl=document.getElementById('launch-ovl');
  if(ovl) ovl.classList.remove('open');
  // Sync seed
  var seedInp=document.getElementById('seed-input');
  if(seedInp) currentSeed=seedInp.value.trim().toUpperCase();
  // Multi-cat
  if(wizSelCats.length>1){
    selCat='mix';
    var pool=[];
    wizSelCats.forEach(function(cid){
      if(CATS[cid]) CATS[cid].qs.forEach(function(q){pool.push(Object.assign({},q,{_cat:CATS[cid].label}));});
    });
    var count=Math.min(selQCount===9999?9999:selQCount,pool.length);
    if(currentSeed){var rng=seededRNG(currentSeed);session=seededShuffle(pool,rng).slice(0,count);}
    else{session=freshShuffle(pool).slice(0,count);}
    markShown(session);
    correct=0;combo=1;maxCombo=1;errors=[];idx=0;paused=false;
    bonusStreak=0;isBonus=false;qTimes=[];rpgPoints=0;betOn=false;
    var cfg=MODES[selMode]||MODES['chill'];
    lives=cfg.lives===99?99:(cfg.lives||5);
    jokers=3;
    sStats={cat:'mix',mode:selMode,maxCombo:0,mechs:new Set(),streak:streakD.current};
    updateStreak();
    applyBody();
    el('gbadge').textContent='🎲 MIX · '+selMode.toUpperCase();
    var sh=el('score-hud');if(sh)sh.style.display=(selMode==='duel'||selMode==='flash'||selMode==='discussion')?'none':'grid';
    el('htotal').textContent=session.length;
    buildDots();
    showScreen('game');
    if(selMode==='rpg'){startRPGNarrative();return;}
    if(selMode==='chaos'){startChaosMode();return;}
    if(selMode==='flash'){startFlash();return;}
    if(selMode==='duel'){showScreen('duel-setup');return;}
    if(selMode==='discussion'){showScreen('discussion');return;}
    if(selMode==='speedrun') initSpeedrun();
    if(selMode==='boss') session=initBoss(session);
    var srHud=document.getElementById('speedrun-hud');if(srHud) srHud.style.display=selMode==='speedrun'?'flex':'none';
    var bossWrap=document.getElementById('boss-bar-wrap');if(bossWrap) bossWrap.style.display=selMode==='boss'?'block':'none';
    dynDiffStreak=0;dynDiffLevel=0;
    showQ();
  } else {
    selCat=wizSelCats[0]||'mix';
    startGame();
  }
}

function buildSheetCats(){
  var grid=document.getElementById('sheet-cat-grid');
  if(!grid) return;
  grid.innerHTML='';
  grid.style.cssText='display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:12px;';

  // Mix hero
  (function(){
    var c=CATS['mix'];
    var st=stD['mix']||{played:0,correct:0};
    var pct=st.played>0?Math.round(st.correct/st.played*100):null;
    var isSel=wizSelCats.indexOf('mix')>-1;
    var d=document.createElement('div');
    d.className='sheet-cat'+(isSel?' sel':'');
    d.setAttribute('data-cat','mix');
    d.style.gridColumn='1/-1';d.style.display='flex';d.style.alignItems='center';
    d.style.gap='14px';d.style.padding='14px 16px';
    d.style.background=isSel?'var(--a2)':'var(--panel)';
    d.style.border=isSel?'2px solid var(--acc)':'1.5px solid var(--border)';
    d.style.cursor='pointer';d.style.borderRadius='8px';
    d.innerHTML='<span style="font-size:28px">'+c.icon+'</span>'+
      '<div style="flex:1"><div style="font-weight:bold;font-size:12px;color:var(--acc);margin-bottom:3px;">MIX — TOUT EN VRAC</div>'+
      '<div style="font-size:10px;color:var(--text2);">'+c.qs.length+' questions · Toutes catégories</div></div>'+
      (pct!==null?'<span style="font-size:10px;color:var(--dim);">'+pct+'%</span>':'');
    d.onclick=function(){
      wizSelCats=['mix'];selCat='mix';
      document.querySelectorAll('.sheet-cat').forEach(function(x){
        var cid=x.getAttribute('data-cat');var sel=cid==='mix';
        x.classList.toggle('sel',sel);
        if(x.style.gridColumn==='1 / -1'){x.style.background=sel?'var(--a2)':'var(--panel)';x.style.border=sel?'2px solid var(--acc)':'1.5px solid var(--border)';}
      });
      applyBody();
    };
    grid.appendChild(d);
  })();

  // Autres cats
  Object.keys(CATS).forEach(function(id){
    if(id==='mix') return;
    var c=CATS[id];
    var st=stD[id]||{played:0,correct:0};
    var pct=st.played>0?Math.round(st.correct/st.played*100):null;
    var isSel=wizSelCats.indexOf(id)>-1;
    var d=document.createElement('div');
    d.className='sheet-cat'+(isSel?' sel':'');
    d.setAttribute('data-cat',id);
    d.innerHTML='<span class="sc-icon">'+c.icon+'</span><span class="sc-name">'+c.label+'</span>'+
      '<span class="sc-n">'+(pct!==null?pct+'%':c.qs.length+'Q')+'</span>';
    (function(catId,card){
      card.onclick=function(){
        var mixIdx=wizSelCats.indexOf('mix');
        if(mixIdx>-1) wizSelCats.splice(mixIdx,1);
        var idx2=wizSelCats.indexOf(catId);
        if(idx2>-1){if(wizSelCats.length>1)wizSelCats.splice(idx2,1);}
        else{wizSelCats.push(catId);}
        document.querySelectorAll('.sheet-cat').forEach(function(x){
          var cid=x.getAttribute('data-cat');var sel=wizSelCats.indexOf(cid)>-1;
          x.classList.toggle('sel',sel);
          if(x.style.gridColumn==='1 / -1'){x.style.background=sel?'var(--a2)':'var(--panel)';x.style.border=sel?'2px solid var(--acc)':'1.5px solid var(--border)';}
        });
        selCat=wizSelCats[0]||catId;applyBody();
      };
    })(id,d);
    grid.appendChild(d);
  });
}

function buildSheetModes(){
  var grid=document.getElementById('sheet-mode-grid');
  if(!grid) return;
  grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:12px;';
  var modes=[
    {id:'chill',icon:'😌',name:'CHILL',desc:'Pas de timer',size:'full'},
    {id:'speed',icon:'⚡',name:'SPEED',desc:'20s/q',badge:''},
    {id:'survie',icon:'💀',name:'SURVIE',desc:'3 vies',badge:'HARD'},
    {id:'blitz',icon:'🔥',name:'BLITZ',desc:'10s · 1 vie',badge:'EXTREME'},
    {id:'exam',icon:'📝',name:'EXAMEN',desc:'20Q sans feedback',badge:'EXAM'},
    {id:'erreurs',icon:'📌',name:'ERREURS',desc:'Tes ratées',badge:''},
    {id:'chrono',icon:'⏱️',name:'CHRONO',desc:'3 min max',badge:''},
    {id:'mort',icon:'☠️',name:'MORT SUB.',desc:'1 erreur = fini',badge:''},
    {id:'marathon',icon:'🏃',name:'MARATHON',desc:'Toutes les Q',badge:''},
    {id:'inverse',icon:'🔄',name:'INVERSÉ',desc:'Trouve la question',badge:''},
    {id:'speedrun',icon:'💨',name:'SPEEDRUN',desc:'Chrono perso',badge:''},
    {id:'boss',icon:'👹',name:'BOSS',desc:'10Q croissantes',badge:''},
    {id:'chaos',icon:'🌀',name:'CHAOS',desc:'Règles instables',badge:'CHAOS'},
    {id:'flash',icon:'🃏',name:'FLASHCARD',desc:'Retourne les cartes',badge:''},
    {id:'duel',icon:'⚔️',name:'DUEL',desc:'2 joueurs',badge:'2P'},
    {id:'rpg',icon:'🎭',name:'RPG NARRATIF',desc:'Tickets incidents',badge:'RPG'},
    {id:'discussion',icon:'🖥️',name:'DISCUSSION',desc:'Mode projo',badge:'PROJO'},
  ];
  grid.innerHTML='';
  modes.forEach(function(m){
    var d=document.createElement('div');
    var isSel=selMode===m.id;
    d.className='sheet-mode'+(isSel?' sel':'');
    if(m.size==='full'){
      d.style.gridColumn='1/-1';d.style.display='flex';d.style.alignItems='center';
      d.style.gap='12px';d.style.padding='14px 16px';
      d.innerHTML='<span style="font-size:22px">'+m.icon+'</span>'+
        '<div><span class="sm-name" style="font-size:9px;display:block">'+m.name+'</span>'+
        '<div class="sm-desc">'+m.desc+'</div></div>';
    } else {
      d.innerHTML='<span class="sm-icon">'+m.icon+'</span><span class="sm-name">'+m.name+'</span>'+
        '<div class="sm-desc">'+m.desc+'</div>'+(m.badge?'<span class="sm-badge">'+m.badge+'</span>':'');
    }
    (function(mId,card){card.onclick=function(){document.querySelectorAll('.sheet-mode').forEach(function(x){x.classList.remove('sel');});card.classList.add('sel');selMode=mId;};})(m.id,d);
    grid.appendChild(d);
  });
}

function sheetPickDiff(btn){
  document.querySelectorAll('.sheet-pill[data-diff]').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  selDiff=btn.getAttribute('data-diff');
}

function sheetPickN(btn){
  document.querySelectorAll('.sheet-pill[data-n]').forEach(function(b){b.classList.remove('sel');});
  btn.classList.add('sel');
  selQCount=parseInt(btn.getAttribute('data-n'))||10;
  lsSet('tssr5_qcount',selQCount);
}

function buildQuickStats(){
  var qs=document.getElementById('quick-stats');
  if(!qs) return;
  var totalQ=Object.keys(CATS).reduce(function(a,k){return a+(CATS[k]&&CATS[k].qs?CATS[k].qs.length:0);},0);
  var totalPlayed=Object.keys(stD).reduce(function(a,k){return a+(stD[k]?stD[k].played:0);},0);
  var totalCorrect=Object.keys(stD).reduce(function(a,k){return a+(stD[k]?stD[k].correct:0);},0);
  var globalPct=totalPlayed>0?Math.round(totalCorrect/totalPlayed*100):0;
  var mastered=Object.keys(CATS).filter(function(k){
    if(k==='mix') return false;
    var st=stD[k]||{played:0,correct:0};
    return st.played>=5&&Math.round(st.correct/st.played*100)>=70;
  }).length;
  var totalCats=Object.keys(CATS).length-1;
  var col=globalPct>=70?'#00a85a':globalPct>=50?'#ff9800':'#f87171';
  qs.innerHTML=
    '<div class="qs-box"><span class="qs-val" style="color:var(--acc)">'+totalQ+'</span><div class="qs-lbl">Questions</div></div>'+
    '<div class="qs-box"><span class="qs-val" style="color:'+col+'">'+globalPct+'%</span><div class="qs-lbl">Réussite</div></div>'+
    '<div class="qs-box"><span class="qs-val" style="color:#fbbf24">'+mastered+'/'+totalCats+'</span><div class="qs-lbl">Catégories</div></div>';
}

function genSeed(){
  var chars='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var s='';for(var i=0;i<6;i++) s+=chars[Math.floor(Math.random()*chars.length)];
  var inp=document.getElementById('seed-input');
  if(inp){inp.value=s;currentSeed=s;}
}

function copySeed(){
  var inp=document.getElementById('seed-input');if(!inp) return;
  currentSeed=inp.value.trim().toUpperCase();
  if(!currentSeed){genSeed();return;}
  navigator.clipboard&&navigator.clipboard.writeText(currentSeed);
  inp.style.borderColor='#00a85a';
  setTimeout(function(){if(inp)inp.style.borderColor='';},1200);
}

// =====================================================
// SYSTÈME DE BONUS RPG
// =====================================================
var RPG_BONUS_DEFS = [
  {
    id:'tech_call',icon:'📞',
    name:'Appeler un collegue',
    desc:'Un collegue elimine 2 mauvaises actions de ce ticket.',
    effect: function(){
      var sc=rpgN.currentTicket; if(!sc) return;
      var bad=sc.actions.filter(function(a){return a.type!=='BONNE_PISTE';});
      var toHide=shuffle(bad).slice(0,2);
      toHide.forEach(function(a){
        if(!rpgN.triedActions[sc.id]) rpgN.triedActions[sc.id]=[];
        if(rpgN.triedActions[sc.id].indexOf(a.id)===-1) rpgN.triedActions[sc.id].push(a.id);
      });
      rpgRenderActions(sc);
      rpgShowBonusNarrative('Un collegue a jete un oeil. Ces pistes semblent inutiles: '+toHide.map(function(a){return a.label;}).join(', '));
    }
  },
  {
    id:'lexique',icon:'📖',
    name:'Lexique technique',
    desc:'Un lexique des termes cles du ticket apparait en bas.',
    effect: function(){var sc=rpgN.currentTicket; if(!sc) return; rpgShowLexique(sc);}
  },
  {
    id:'historique',icon:'📋',
    name:'Consulter historique',
    desc:'Tu accedes aux logs — une indication sur la derniere modification.',
    effect: function(){
      var sc=rpgN.currentTicket; if(!sc) return;
      var hint=sc.history_hint||'Les logs montrent une modification de configuration recente sur ce service.';
      rpgShowBonusNarrative(hint);
    }
  },
  {
    id:'escalade',icon:'⬆️',
    name:'Escalader au chef',
    desc:'+20 confiance immediat. Le chef resout le ticket mais tu ne gagnes rien.',
    effect: function(){
      rpgChangeConf(20);
      rpgShowBonusNarrative('Ton chef prend en main le ticket. Confiance +20 mais tu passes au suivant sans apprendre.');
      setTimeout(function(){rpgN.ticketIdx++;rpgN.questionAnswered=false;rpgShowTicket();},2500);
    }
  },
  {
    id:'documentation',icon:'📄',
    name:'Consulter la doc',
    desc:'Revele quelle categorie de commande resout ce ticket.',
    effect: function(){
      var sc=rpgN.currentTicket; if(!sc) return;
      var catHints={
        winrm:'La doc WinRM: verifier les listeners et les hotes de confiance.',
        dns:'La doc DNS: verifier le statut du service avant toute modification de zone.',
        vlan:'Le guide Cisco: le routage inter-VLAN necessite les SVIs ET la commande ip routing.',
        hyperv:'La doc Hyper-V: les problemes de demarrage sont souvent lies aux snapshots.',
        ntfs:'La doc NTFS: les Deny explicites ecrasent tous les Allow.',
        stp:'Le guide STP: identifier les boucles physiques avant toute action logicielle.',
        dhcp:'La doc DHCP: verifier occupation du scope avant de modifier le service.',
        cisco_ssh:'Le guide Cisco IOS: SSH necessite hostname, domain-name et cles RSA.'
      };
      rpgShowBonusNarrative(catHints[sc.id]||'La doc recommande de proceder par ordre: service, config, permissions.');
    }
  },
];

var rpgBonusUsed = {};

function rpgInitBonus(){
  rpgBonusUsed={};
  // Afficher le bouton bonus
  var btn=document.getElementById('rpg-bonus-btn');
  if(btn) btn.style.display='flex';
  rpgUpdateBonusCount();
  rpgBuildBonusMenu();
}

function rpgUpdateBonusCount(){
  var used=Object.keys(rpgBonusUsed).filter(function(k){return rpgBonusUsed[k];}).length;
  var remaining=RPG_BONUS_DEFS.length-used;
  var cnt=document.getElementById('rpg-bonus-count');
  if(cnt) cnt.textContent=remaining;
}

function rpgBuildBonusMenu(){
  var list=document.getElementById('rpg-bonus-list');
  if(!list) return;
  list.innerHTML='';
  RPG_BONUS_DEFS.forEach(function(b){
    var used=rpgBonusUsed[b.id];
    var d=document.createElement('div');
    d.className='rpg-bonus-item'+(used?' bonus-used':'');
    d.innerHTML='<span class="rpg-bonus-item-name">'+b.icon+' '+b.name+(used?' — UTILISÉ':'')+'</span>'+
      '<div class="rpg-bonus-item-desc">'+b.desc+'</div>';
    if(!used){
      (function(bonus){
        d.onclick=function(){
          rpgBonusUsed[bonus.id]=true;
          rpgToggleBonusMenu();
          rpgUpdateBonusCount();
          rpgBuildBonusMenu();
          if(bonus.effect) bonus.effect();
        };
      })(b);
    }
    list.appendChild(d);
  });
}

function rpgToggleBonusMenu(){
  var menu=document.getElementById('rpg-bonus-menu');
  if(!menu) return;
  var isOpen=menu.classList.contains('show');
  menu.classList.toggle('show',!isOpen);
}

function rpgShowBonusNarrative(text){
  var nar=document.getElementById('rpg-narrative-text');
  if(!nar) return;
  var old=nar.textContent;
  nar.style.color='#fbbf24';
  nar.style.borderLeftColor='#d97706';
  nar.textContent='💡 '+text;
  setTimeout(function(){
    nar.style.color='';nar.style.borderLeftColor='';
    nar.textContent=old;
  },3500);
}

function rpgShowLexique(sc){
  var existing=document.getElementById('rpg-lexique');
  if(existing){existing.remove();return;}
  var lexiques={
    winrm:{terms:['WinRM: Windows Remote Management — protocole de gestion à distance','TrustedHosts: liste des hôtes autorisés côté client en workgroup','PSRemoting: technologie PowerShell basée sur WinRM','Port 5985: port HTTP par défaut de WinRM']},
    dns:{terms:['SOA: Start Of Authority — enregistrement principal dune zone DNS','Zone primaire: zone faisant autorité, modifiable directement','TTL: Time To Live — durée de vie dun enregistrement en cache','Flush DNS: vider le cache DNS local (ipconfig /flushdns)']},
    vlan:{terms:['SVI: Switch Virtual Interface — interface L3 dun VLAN','ip routing: commande activant le routage sur switch L3','Trunk: port transportant plusieurs VLANs avec tag 802.1Q','VLAN 20: identifiant du réseau virtuel du département RH']},
    ntfs:{terms:['ACL: Access Control List — liste des permissions','Deny: refus explicite — prioritaire sur Allow','Héritage: transmission des permissions du dossier parent','Groupe AD: regroupement dutilisateurs pour simplifier les droits']},
    cisco_ssh:{terms:['RSA: algorithme de chiffrement nécessaire pour SSH','ip domain-name: requis pour nommer les clés RSA','VTY: lignes virtuelles de connexion distante','transport input: définit les protocoles acceptés sur VTY']},
  };
  var lex=lexiques[sc.id];
  if(!lex) return;
  var el=document.createElement('div');
  el.id='rpg-lexique';
  el.style.cssText="position:fixed;bottom:36px;right:12px;background:#1a1208;border:2px solid #d97706;padding:12px 16px;font-family:monospace;font-size:10px;color:#c8bc9a;z-index:910;max-width:280px;line-height:1.8;box-shadow:0 4px 16px rgba(0,0,0,.4)";
  el.innerHTML='<div style="color:#d97706;font-size:9px;letter-spacing:2px;margin-bottom:8px;border-bottom:1px dashed #6a5a3a;padding-bottom:6px;">📖 LEXIQUE</div>'+
    lex.terms.map(function(t){return '<div style="margin-bottom:4px;">▸ '+t+'</div>';}).join('')+
    '<div style="margin-top:8px;text-align:right;"><button onclick="var l=document.getElementById(\'rpg-lexique\');if(l)l.remove();" style="background:none;border:1px solid #6a5a3a;color:#8a7a5a;font-size:9px;padding:3px 8px;cursor:pointer;font-family:inherit;">FERMER</button></div>';
  document.body.appendChild(el);
}

// =====================================================
// RPG INTRO + LAUNCHERS
// =====================================================
var rpgIntroTickets = 5;

function launchRPGDirect(){
  playModeStart();
  // Thème Paper pour RPG — appliquer sur le body directement sans passer par applyUI complet
  document.body.classList.remove('ui-arcade','ui-terminal','ui-minimal');
  document.body.classList.add('ui-paper','rpg-mode');
  // Mettre à jour les boutons switcher si présents
  document.querySelectorAll('.ui-sw-btn').forEach(function(b){
    b.classList.toggle('sel', b.getAttribute('data-ui')==='ui-paper');
  });
  showScreen('rpg-intro');
}

function launchFlashDirect(){
  selCat='mix';selMode='flash';
  var pool=[];
  Object.keys(CATS).forEach(function(k){
    if(CATS[k]&&CATS[k].qs) CATS[k].qs.forEach(function(q){pool.push(q);});
  });
  session=freshShuffle(pool).slice(0,30);
  startFlash();
}

function rpgSetTickets(n){
  rpgIntroTickets=n;
  if(rpgN) rpgN.ticketsPerSession=n;
  var el2=document.getElementById('rpg-intro-tickets');
  if(el2) el2.textContent=n;
  document.querySelectorAll('.rpg-intro-n-btn').forEach(function(b){
    var isSelected=parseInt(b.getAttribute('data-n'))===n;
    b.classList.toggle('sel',isSelected);
    if(isSelected){b.style.background='#8b1a1a';b.style.color='#fef3c7';b.style.borderColor='#1a1208';}
    else{b.style.background='#d4c9a8';b.style.color='#1a1208';b.style.borderColor='#8a7a5a';}
  });
}

function rpgStartFromIntro(){
  rpgN.ticketsPerSession=rpgIntroTickets||5;
  startRPGNarrative();
}

// =====================================================
// SYSTÈME DE BONUS RPG
// =====================================================
var RPG_BONUSES = [
  {
    id:'technicien',
    icon:'📞',
    name:'Appeler un technicien senior',
    desc:'Il élimine la moitié des mauvaises réponses de la prochaine question.',
    used:false,
    narrative:'Tu décroches ton téléphone. "Salut Marc, t as une minute ?" Il regarde rapidement et te dit ce qui est clairement faux.',
    effect:function(){rpgBonusHalfElim();}
  },
  {
    id:'lexique',
    icon:'📖',
    name:'Consulter le lexique',
    desc:'Tous les termes techniques de la page sont définis en bas de l écran.',
    used:false,
    narrative:'Tu ouvres ton classeur de notes. Les définitions des termes clés apparaissent.',
    effect:function(){rpgBonusLexique();}
  },
  {
    id:'log',
    icon:'🔍',
    name:'Consulter les logs système',
    desc:'Une piste supplémentaire apparaît dans le ticket.',
    used:false,
    narrative:'Tu consultes les journaux d événements. Une ligne attire ton attention...',
    effect:function(){rpgBonusLog();}
  },
  {
    id:'doc',
    icon:'📋',
    name:'Consulter la documentation',
    desc:'La bonne réponse est mise en surbrillance parmi les options.',
    used:false,
    narrative:'Tu ouvres la doc Microsoft. La commande correcte est là, en noir sur blanc.',
    effect:function(){rpgBonusDoc();}
  },
];

var rpgBonusPool = []; // bonus disponibles pour la session
var rpgBonusMenuOpen = false;

function rpgInitBonuses(){
  // 1 bonus automatique + possibilité d'en gagner d'autres
  rpgBonusPool = RPG_BONUSES.map(function(b){return Object.assign({},b,{used:false});});
  // Sélectionner 2 bonus aléatoires pour la session
  rpgBonusPool = shuffle(rpgBonusPool).slice(0,2);
  rpgRenderBonusSlot();
}

function rpgRenderBonusSlot(){
  var slot=document.getElementById('rpg-bonus-slot');
  var token=document.getElementById('rpg-bonus-token');
  if(!slot||!token) return;
  var avail=rpgBonusPool.filter(function(b){return !b.used;});
  if(avail.length>0){
    slot.className='rpg-bonus-slot show';
    token.textContent=avail[0].icon;
    token.className='rpg-bonus-token'+(avail[0].used?' used':'');
  } else {
    slot.className='rpg-bonus-slot';
  }
}

function toggleBonusMenu(){
  rpgBonusMenuOpen=!rpgBonusMenuOpen;
  var menu=document.getElementById('rpg-bonus-menu');
  if(!menu) return;
  if(rpgBonusMenuOpen){
    menu.className='rpg-bonus-menu show';
    rpgRenderBonusMenu();
  } else {
    menu.className='rpg-bonus-menu';
  }
}

function rpgRenderBonusMenu(){
  var list=document.getElementById('rpg-bonus-list');
  if(!list) return;
  list.innerHTML='';
  rpgBonusPool.forEach(function(b){
    var d=document.createElement('div');
    d.className='rpg-bonus-item'+(b.used?' used':'');
    d.innerHTML='<span class="rpg-bonus-item-name">'+b.icon+' '+b.name+(b.used?' — UTILISÉ':'')+'</span>'+
      '<span class="rpg-bonus-item-desc">'+b.desc+'</span>';
    if(!b.used){
      (function(bonus){
        d.onclick=function(){
          bonus.used=true;
          toggleBonusMenu();
          rpgRenderBonusSlot();
          // Afficher narrative du bonus
          var narEl=document.getElementById('rpg-narrative-text');
          if(narEl){narEl.textContent=bonus.narrative;narEl.style.color='#d97706';}
          setTimeout(function(){
            if(narEl){narEl.style.color='';} 
            bonus.effect();
          },1500);
        };
      })(b);
    }
    list.appendChild(d);
  });
}

// Effets des bonus
function rpgBonusHalfElim(){
  var opts=Array.from(document.querySelectorAll('.rpg-inline-opt:not(:disabled)'));
  if(opts.length<2) return;
  // Griser la moitié des options (aléatoirement, sauf la bonne)
  var correct=opts.filter(function(o){return o.classList.contains('ok');});
  var others=opts.filter(function(o){return !o.classList.contains('ok');});
  var toElim=shuffle(others).slice(0,Math.floor(others.length/2));
  toElim.forEach(function(o){o.style.opacity='.2';o.style.pointerEvents='none';o.disabled=true;});
}

function rpgBonusLexique(){
  // Ouvrir la page lexique complète
  var lex=document.getElementById('rpg-lexique-full');
  if(!lex) return;
  lex.classList.toggle('show');
  // Mettre en avant les mots présents dans le ticket actif
  var sc=rpgN.currentTicket;
  var activeWords=sc?sc.id:'';
  rpgRenderLexiqueFull(activeWords);
}

var LEXIQUE_COMPLET={
  // Windows / Réseau
  'WinRM':'Windows Remote Management. Protocole Microsoft permettant lexécution de commandes PowerShell à distance via le port 5985 (HTTP) ou 5986 (HTTPS).',
  'PSRemoting':'PowerShell Remoting. Ensemble de fonctionnalités basées sur WinRM permettant lexécution de scripts sur des machines distantes avec Enable-PSRemoting.',
  'TrustedHosts':'Liste blanche configurée côté client WinRM. En workgroup (sans domaine AD), il faut y déclarer explicitement les serveurs distants : Set-Item WSMan:\\localhost\\Client\\TrustedHosts.',
  'RSAT':'Remote Server Administration Tools. Outils dadministration Windows installables sur un poste client pour gérer des serveurs distants (AD, DNS, DHCP, etc.) sans console directe.',
  'WMI':'Windows Management Instrumentation. Infrastructure de gestion Windows permettant daccéder aux informations système et de les modifier via scripts.',
  // DNS
  'DNS':'Domain Name System. Système qui traduit les noms de domaine (ex: server.local) en adresses IP. Port 53 UDP/TCP.',
  'SOA':'Start Of Authority. Enregistrement DNS obligatoire dans chaque zone. Contient: serveur primaire, email admin, numéro de série (incrémenté à chaque modification), TTL, délais refresh/retry/expire.',
  'TTL':'Time To Live. Durée en secondes pendant laquelle un enregistrement DNS peut être mis en cache avant dêtre re-interrogé.',
  'Forwarder':'Serveur DNS externe vers lequel les requêtes non résolues localement sont transmises (ex: 8.8.8.8 pour résoudre les noms publics).',
  'Zone primaire':'Zone DNS modifiable, source faisant autorité. Les modifications se font ici puis se répliquent sur les zones secondaires.',
  'Zone secondaire':'Copie en lecture seule dune zone primaire, récupérée par transfert de zone. Sert de redondance.',
  // VLAN / Switch
  'VLAN':'Virtual Local Area Network. Segmentation logique dun réseau physique. Les machines dun VLAN ne communiquent pas directement avec celles dun autre VLAN sans routeur ou switch L3.',
  'SVI':'Switched Virtual Interface. Interface virtuelle sur un switch L3 représentant un VLAN. Elle a une adresse IP et permet le routage inter-VLAN. Commande: interface vlan [ID].',
  'Trunk':'Port switch transportant plusieurs VLANs simultanément via des tags 802.1Q. Utilisé pour les liaisons switch-switch ou switch-routeur.',
  '802.1Q':'Standard IEEE de trunking VLAN. Ajoute un tag de 4 octets dans la trame Ethernet pour identifier le VLAN dorigine.',
  'VLAN natif':'VLAN dont les trames passent sur un trunk sans tag. VLAN 1 par défaut sur Cisco. Doit être le même des deux côtés du trunk.',
  'ip routing':'Commande Cisco activant le moteur de routage IP sur un switch L3. Sans elle, les SVIs existent mais le switch ne route pas entre VLANs.',
  'Access port':'Port switch configuré pour un seul VLAN. Les trames ny sont pas taguées. Utilisé pour connecter des postes ou serveurs.',
  // STP
  'STP':'Spanning Tree Protocol (IEEE 802.1D). Prévient les boucles réseau en plaçant certains ports en état Blocking. Convergence lente (~50s).',
  'RSTP':'Rapid STP (802.1w). Version améliorée de STP avec convergence rapide (~1-2s). Compatibilité ascendante avec STP classique.',
  'Root Bridge':'Switch élu comme racine de larbre STP. Tous les autres switches calculent leurs chemins depuis lui. Élu par la priorité la plus basse (défaut: 32768).',
  'PortFast':'Optimisation STP Cisco. Passe immédiatement un port en état Forwarding sans passer par Listening/Learning. À utiliser UNIQUEMENT sur les ports dextrémité (PC, serveurs).',
  'BPDU Guard':'Sécurité STP. Désactive (err-disabled) un port si une BPDU est reçue. Protège contre la connexion dun switch non autorisé sur un port access.',
  'BPDU':'Bridge Protocol Data Unit. Trame échangée entre switches pour construire larbre STP. Contient: adresse MAC, priorité, coût de chemin, timers.',
  'Broadcast storm':'Tempête de diffusion causée par une boucle réseau. Les trames broadcast se répliquent indéfiniment, saturant le réseau.',
  // DHCP
  'DHCP':'Dynamic Host Configuration Protocol. Attribue automatiquement des adresses IP, masque, passerelle et DNS. Port 67 (serveur) / 68 (client). Processus: DORA (Discover, Offer, Request, Acknowledge).',
  'Scope DHCP':'Plage dadresses IP que le serveur DHCP peut distribuer (ex: 192.168.1.100-200). Peut inclure des exclusions et réservations.',
  'Bail DHCP':'Durée pendant laquelle une adresse IP est attribuée à un client. Après expiration, le client doit la renouveler.',
  'Relay agent':'Service ou équipement (souvent un routeur) qui relaie les requêtes DHCP entre des sous-réseaux différents. Commande Cisco: ip helper-address.',
  '169.254.x.x':'Adresse APIPA (Automatic Private IP Addressing). Attribuée automatiquement quand le client DHCP ne trouve pas de serveur. Indique un problème DHCP.',
  // Hyper-V
  'VHDX':'Format de disque virtuel Hyper-V (successeur de VHD). Supporte jusquà 64 To, résilient aux coupures, avec journal décriture.',
  'Snapshot':'Point de restauration dune VM (aussi appelé Checkpoint dans Hyper-V). Crée un fichier .avhdx différentiel. Ne remplace pas une sauvegarde complète.',
  'Commutateur virtuel':'Switch logiciel Hyper-V gérant la connectivité réseau des VMs. Types: External (accès au réseau physique), Internal (host+VMs), Private (VMs uniquement).',
  'Génération VM':'Hyper-V propose 2 générations. Gen 1: BIOS, compatibilité maximale. Gen 2: UEFI, Secure Boot, meilleures performances. Choix fait à la création, non modifiable.',
  // NTFS / Permissions
  'NTFS':'New Technology File System. Système de fichiers Windows avec gestion fine des permissions (ACL), journalisation, chiffrement (EFS), compression.',
  'ACL':'Access Control List. Liste des entrées de contrôle daccès (ACE) définissant qui peut faire quoi sur un objet (fichier, dossier, clé de registre).',
  'ACE':'Access Control Entry. Entrée individuelle dans une ACL définissant: utilisateur/groupe, permissions, Allow ou Deny.',
  'Héritage NTFS':'Mécanisme par lequel les sous-dossiers reçoivent automatiquement les permissions du dossier parent. Peut être coupé manuellement.',
  'Deny explicite':'Refus explicite daccès NTFS. Prioritaire sur tous les Allow, quelle que soit leur source (directe ou héritée).',
  'SMB':'Server Message Block. Protocole de partage de fichiers Windows. SMB3 (Windows 8/2012+) apporte le chiffrement et la compression.',
  // Cisco IOS / SSH
  'RSA':'Algorithme de chiffrement asymétrique. Utilisé par SSH pour lauthentification. Sur Cisco: crypto key generate rsa modulus 2048.',
  'SSH':'Secure Shell. Protocole de connexion distante sécurisé (port 22). Remplace Telnet. Nécessite: hostname + domain-name + clés RSA + ip ssh version 2.',
  'Telnet':'Protocole de connexion distante non chiffré (port 23). À éviter en production — remplacé par SSH.',
  'VTY':'Virtual TeletYpe. Lignes virtuelles sur un équipement Cisco permettant les connexions SSH/Telnet. Configuration: line vty 0 4.',
  'ip domain-name':'Commande Cisco définissant le nom de domaine DNS de léquipement. Requis avant la génération des clés RSA pour SSH.',
  'ACL étendue':'Access Control List Cisco filtrant le trafic sur critères source/destination IP et ports. Placée au plus près de la source.',
  // PowerShell
  'Cmdlet':'Commande PowerShell suivant la convention Verbe-Nom (ex: Get-Service, Set-ADUser). Chaque cmdlet fait une chose précise.',
  'Pipeline':'Mécanisme PowerShell transmettant les objets dune cmdlet à la suivante via le symbole |. Ex: Get-Service | Where-Object {$_.Status -eq "Running"}',
  'WMI/CIM':'Windows Management Instrumentation / Common Information Model. APIs PowerShell pour accéder aux informations système. Get-WmiObject (legacy) ou Get-CimInstance (moderne).',
};

function rpgRenderLexiqueFull(scId){
  var content=document.getElementById('rpg-lex-content');
  if(!content) return;
  
  // Mots liés au scénario actif — mis en avant
  var scWords={
    winrm:['WinRM','PSRemoting','TrustedHosts','RSAT'],
    dns:['DNS','SOA','TTL','Zone primaire','Forwarder'],
    vlan:['VLAN','SVI','Trunk','802.1Q','ip routing','VLAN natif'],
    stp:['STP','RSTP','Root Bridge','PortFast','BPDU Guard','BPDU','Broadcast storm'],
    dhcp:['DHCP','Scope DHCP','Bail DHCP','Relay agent','169.254.x.x'],
    hyperv:['VHDX','Snapshot','Commutateur virtuel','Génération VM'],
    ntfs:['NTFS','ACL','ACE','Héritage NTFS','Deny explicite','SMB'],
    cisco_ssh:['RSA','SSH','Telnet','VTY','ip domain-name','ACL étendue'],
  };
  var highlight=scId&&scWords[scId]?scWords[scId]:[];
  
  // Groupes
  var groups=[
    {label:'Windows & Administration',keys:['WinRM','PSRemoting','TrustedHosts','RSAT','WMI']},
    {label:'DNS',keys:['DNS','SOA','TTL','Zone primaire','Zone secondaire','Forwarder']},
    {label:'VLAN & Switching',keys:['VLAN','SVI','Trunk','802.1Q','VLAN natif','ip routing','Access port']},
    {label:'STP',keys:['STP','RSTP','Root Bridge','PortFast','BPDU Guard','BPDU','Broadcast storm']},
    {label:'DHCP',keys:['DHCP','Scope DHCP','Bail DHCP','Relay agent','169.254.x.x']},
    {label:'Hyper-V',keys:['VHDX','Snapshot','Commutateur virtuel','Génération VM']},
    {label:'NTFS & Permissions',keys:['NTFS','ACL','ACE','Héritage NTFS','Deny explicite','SMB']},
    {label:'Cisco IOS & SSH',keys:['RSA','SSH','Telnet','VTY','ip domain-name','ACL étendue']},
    {label:'PowerShell',keys:['Cmdlet','Pipeline','WMI/CIM']},
  ];
  
  content.innerHTML='';
  groups.forEach(function(g){
    var section=document.createElement('div');
    section.style.cssText='margin-bottom:14px;';
    var lbl=document.createElement('div');
    lbl.style.cssText='font-size:8px;letter-spacing:3px;color:#d97706;text-transform:uppercase;padding:4px 0;border-bottom:1px solid #6a5a3a;margin-bottom:6px;';
    lbl.textContent=g.label;
    section.appendChild(lbl);
    g.keys.forEach(function(k){
      if(!LEXIQUE_COMPLET[k]) return;
      var entry=document.createElement('div');
      var isHighlight=highlight.indexOf(k)>-1;
      entry.style.cssText='margin-bottom:8px;padding:6px 8px;'+(isHighlight?'background:#2a2010;border-left:2px solid #d97706;':'');
      entry.innerHTML='<div style="font-size:11px;color:'+(isHighlight?'#fbbf24':'#fef3c7')+';font-weight:bold;margin-bottom:3px;">'+k+'</div>'+
        '<div style="font-size:10px;color:#c8bc9a;line-height:1.6;">'+LEXIQUE_COMPLET[k]+'</div>';
      section.appendChild(entry);
    });
    content.appendChild(section);
  });
}

function rpgBonusDoc(){
  // Ajouter un indice discret sur la bonne réponse (fond légèrement différent)
  // On ne peut pas savoir laquelle est correcte sans le qid — on ajoute juste un toast
  var narEl=document.getElementById('rpg-narrative-text');
  if(narEl){
    narEl.textContent='📋 Documentation consultée. Cherche la réponse la plus précise et complète.';
    narEl.style.color='#d97706';
    setTimeout(function(){if(narEl){narEl.style.color='';narEl.textContent='Indice : lis bien chaque option avant de répondre.';}},4000);
  }
}

// =====================================================
// SONS UI (Web Audio — petits bruitages)
// =====================================================
var _uiAC = null;
function getUiAC(){
  if(!_uiAC) _uiAC=new(window.AudioContext||window.webkitAudioContext)();
  return _uiAC;
}

function playClick(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    var o=ac.createOscillator();
    var g=ac.createGain();
    o.connect(g);g.connect(ac.destination);
    o.type='square';
    o.frequency.setValueAtTime(800,ac.currentTime);
    o.frequency.exponentialRampToValueAtTime(400,ac.currentTime+0.04);
    g.gain.setValueAtTime(0.08,ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+0.06);
    o.start();o.stop(ac.currentTime+0.07);
  }catch(e){}
}

function playClickSoft(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    var o=ac.createOscillator();
    var g=ac.createGain();
    o.connect(g);g.connect(ac.destination);
    o.type='sine';
    o.frequency.setValueAtTime(600,ac.currentTime);
    g.gain.setValueAtTime(0.05,ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+0.08);
    o.start();o.stop(ac.currentTime+0.09);
  }catch(e){}
}

function playThemeChange(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    var freqs=[440,550,660];
    freqs.forEach(function(f,i){
      var o=ac.createOscillator();
      var g=ac.createGain();
      o.connect(g);g.connect(ac.destination);
      o.type='sine';
      o.frequency.value=f;
      g.gain.setValueAtTime(0,ac.currentTime+i*0.08);
      g.gain.linearRampToValueAtTime(0.07,ac.currentTime+i*0.08+0.04);
      g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+i*0.08+0.15);
      o.start(ac.currentTime+i*0.08);
      o.stop(ac.currentTime+i*0.08+0.16);
    });
  }catch(e){}
}

function playModeStart(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    [[330,0],[440,0.1],[550,0.2],[660,0.3]].forEach(function(pair){
      var o=ac.createOscillator();
      var g=ac.createGain();
      o.connect(g);g.connect(ac.destination);
      o.type='triangle';
      o.frequency.value=pair[0];
      g.gain.setValueAtTime(0,ac.currentTime+pair[1]);
      g.gain.linearRampToValueAtTime(0.08,ac.currentTime+pair[1]+0.05);
      g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+pair[1]+0.2);
      o.start(ac.currentTime+pair[1]);
      o.stop(ac.currentTime+pair[1]+0.21);
    });
  }catch(e){}
}

function playConfUp(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    var o=ac.createOscillator();var g=ac.createGain();
    o.connect(g);g.connect(ac.destination);
    o.type='sine';
    o.frequency.setValueAtTime(440,ac.currentTime);
    o.frequency.linearRampToValueAtTime(660,ac.currentTime+0.15);
    g.gain.setValueAtTime(0.1,ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+0.2);
    o.start();o.stop(ac.currentTime+0.21);
  }catch(e){}
}

function playConfDown(){
  if(!soundOn) return;
  try{
    var ac=getUiAC();
    var o=ac.createOscillator();var g=ac.createGain();
    o.connect(g);g.connect(ac.destination);
    o.type='sawtooth';
    o.frequency.setValueAtTime(300,ac.currentTime);
    o.frequency.linearRampToValueAtTime(150,ac.currentTime+0.2);
    g.gain.setValueAtTime(0.08,ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001,ac.currentTime+0.25);
    o.start();o.stop(ac.currentTime+0.26);
  }catch(e){}
}

// SIDE MENU
// =====================================================
function pickVTMenu(e){
  playThemeChange();
  document.querySelectorAll('.vtbtn').forEach(function(b){b.classList.remove('sel');});
  e.classList.add('sel');
  vTheme=e.getAttribute('data-vt');
  lsSet('tssr5_vt',vTheme);
  applyBody();
  // Also sync sheet
  document.querySelectorAll('.sheet-vtbtn').forEach(function(b){b.classList.toggle('sel',b.getAttribute('data-vt')===vTheme);});
}

function openSideMenu(){
  var panel=document.getElementById('side-panel');
  var ovl=document.getElementById('side-ovl');
  if(!panel||!ovl) return;
  var ctx=document.getElementById('side-context');
  var screen=document.querySelector('.screen.active');
  if(screen){
    var sid=screen.id;
    if(sid==='screen-game'){
      if(ctx) ctx.textContent=(CATS[selCat]?CATS[selCat].label:selCat)+' · '+selMode.toUpperCase()+' · Q'+(idx+1)+'/'+session.length;
      var sbRes=document.getElementById('sb-resume'); if(sbRes) sbRes.style.display='flex';
      var sbJok=document.getElementById('sb-joker'); if(sbJok) sbJok.style.display=jokersEnabled?'flex':'none';
      var sbJlbl=document.getElementById('sb-joker-lbl'); if(sbJlbl) sbJlbl.textContent='JOKER ('+jokers+' restants)';
      if(!paused&&selMode!=='exam'&&selMode!=='blitz') togglePause();
    } else if(sid==='screen-flash'){
      if(ctx) ctx.textContent='Flashcards';
      var sbRes2=document.getElementById('sb-resume'); if(sbRes2) sbRes2.style.display='flex';
      var sbJok2=document.getElementById('sb-joker'); if(sbJok2) sbJok2.style.display='none';
    } else {
      if(ctx) ctx.textContent='';
      var sbRes3=document.getElementById('sb-resume'); if(sbRes3) sbRes3.style.display='none';
      var sbJok3=document.getElementById('sb-joker'); if(sbJok3) sbJok3.style.display='none';
    }
  }
  panel.classList.add('open');
  ovl.classList.add('open');
}

function closeSideMenu(){
  var p=document.getElementById('side-panel'); if(p) p.classList.remove('open');
  var o=document.getElementById('side-ovl'); if(o) o.classList.remove('open');
}

// =====================================================
// DUEL — startDuel (alias de launchDuel pour compatibilité)
// =====================================================
function startDuel(){
  showScreen('duel-setup');
}

// KEYBOARD
document.addEventListener('keydown',function(e){
  if(paused) return;
  // Ne pas intercepter si l'input type est actif
  if(document.activeElement&&document.activeElement.id==='type-input') return;
  var q=session[idx];if(!q) return;
  if(q.t==='qcm'||q.t==='debug'){
    var map={A:0,B:1,C:2,D:3};var k=e.key.toUpperCase();
    if(map[k]!==undefined){var btns=document.querySelectorAll('.opt:not(:disabled):not(.elim)');if(btns[map[k]])btns[map[k]].click();}
  }
  if(q.t==='tf'){
    if(e.key==='ArrowLeft'){var bv=document.querySelector('.tf-true:not(:disabled)');if(bv)bv.click();}
    if(e.key==='ArrowRight'){var bf=document.querySelector('.tf-false:not(:disabled)');if(bf)bf.click();}
  }
  if((e.key==='Enter'||e.key===' ')&&el('nextbtn')&&el('nextbtn').classList.contains('show')){e.preventDefault();next();}
  if(e.key==='Escape'){
    if(document.getElementById('side-panel')&&document.getElementById('side-panel').classList.contains('open')){closeSideMenu&&closeSideMenu();return;}
    if(document.getElementById('launch-ovl')&&document.getElementById('launch-ovl').classList.contains('open')){document.getElementById('launch-ovl').classList.remove('open');return;}
    if(el('screen-game')&&el('screen-game').classList.contains('active')&&selMode!=='blitz')togglePause();
  }
  if(e.key.toLowerCase()==='j'&&!answered)useJoker();
  if(selMode==='duel') duelKeydown(e);
  // Discussion mode keyboard
  if(document.getElementById('screen-discussion')&&document.getElementById('screen-discussion').classList.contains('active')){
    if(e.key===' '||e.key==='Enter'){e.preventDefault();if(typeof discRevealed!=='undefined'&&!discRevealed)discReveal();}
    if(e.key==='ArrowRight'&&typeof discRevealed!=='undefined'&&discRevealed){discNext&&discNext();}
    if(e.key==='1'&&typeof discRevealed!=='undefined'&&discRevealed){discScore&&discScore(1);}
    if(e.key==='0'&&typeof discRevealed!=='undefined'&&discRevealed){discScore&&discScore(0);}
  }
  // Flashcard keyboard
  if(document.getElementById('screen-flash')&&document.getElementById('screen-flash').classList.contains('active')){
    if(e.key===' '||e.key==='Enter'){e.preventDefault();if(typeof flashFlipped!=='undefined'&&!flashFlipped)flipCard();else rateFlash&&rateFlash(2);}
    if(e.key==='1') rateFlash&&rateFlash(0);
    if(e.key==='2') rateFlash&&rateFlash(1);
    if(e.key==='3') rateFlash&&rateFlash(2);
  }
});

if(el('nextbtn')) el('nextbtn').addEventListener('click',next);

// INIT
// Les préférences sont chargées ici, mais l'affichage de l'écran
// est géré par Firebase onAuthStateChanged ou fbContinueWithoutAccount.
(function(){
  function doInit(){
    vTheme=lsGet('tssr5_vt','vt-dark');
    soundOn=lsGet('tssr5_sound',false);
    jokersEnabled=lsGet('tssr5_jokers',true);
    selQCount=lsGet('tssr5_qcount',10);
    applyBody(); // applique le thème sans afficher de screen
    // NE PAS appeler initMenu() ici — c'est Firebase qui décide quoi afficher
  }
  if(document.readyState==='loading'){
    window.addEventListener('DOMContentLoaded',doInit);
  } else {
    doInit();
  }
})();
